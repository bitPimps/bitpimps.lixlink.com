<?
// Add Admin Voting database field(s)
// Version 1.1.8  ErDrRon@aol.com http://www.ErDrRon.com/phpBB2/
//
// 	N.B. This script installs the necessary database field for the Admin Voting MOD.
//		This script will only work with a mySQL database.  Only use this script
//		for the initial installation of the MOD.  If you are re-installing the MOD
//		or updating the version of the MOD, DO NOT run this script!  Delete this
//		script from your webserver after successful installation of the MOD.

// Connect to phpbb database
//
	include('./config.php');
	$cnx = mysql_connect($dbhost, $dbuser, $dbpasswd)
		or die("Unable to connect to database server.");
	mysql_select_db($dbname, $cnx)
		or die("Unable to select database.");

// Add field 'vote_cast' to database table 'vote_voters'
//
	$sql = "ALTER TABLE " . $table_prefix . "vote_voters " .
		"ADD vote_cast TINYINT( 4 ) UNSIGNED " .
		"DEFAULT '0' NOT NULL";

	$result = mysql_query($sql);
	if(!$result)
		echo "Install failed<BR><BR>";
	if (mysql_error()) { echo "Error Report: <B>".mysql_error()."</B><BR><BR>"; }
	else
	{
		echo "Install complete: Admin Voting database field added successfully.<BR><BR><BR>Remember to delete this script ASAP.";
	} 
	exit;
?>