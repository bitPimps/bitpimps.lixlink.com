<?php
/***************************************************************************
*                          lang_admin_voting.php [Spanish]
*                              -------------------
*     begin                : Sun, Sept 01, 2002
*     copyright            : (C) 2002 Patricio Worthalter
*     email                : patricio@worthalter.org
*
*     $Id: lang_admin_voting.php,v 1.1.8 12/04/2003 14:14:00 erdrron Exp $
*
****************************************************************************/

/***************************************************************************
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 2 of the License, or
*   (at your option) any later version.
*
***************************************************************************/

// Admin Voting MOD
$lang['Admin_Vote_Explain'] = 'Quien voto y a que';
$lang['Admin_Vote_Title'] = 'Administracion de Encuestas';
$lang['Vote_id'] = '#';
$lang['Poll_topic'] = 'Titulo de la Encuesta';
$lang['Vote_username'] = 'Votantes';
$lang['Vote_end_date'] = 'Duracion de la encuesta';
$lang['Sort_vote_id'] = 'Numero de la encuesta';
$lang['Sort_poll_topic'] = 'Tema de la encuesta';
$lang['Sort_vote_start'] = 'Dia de comienzo';
$lang['Submit'] = 'Enviar';
$lang['Select_sort_field'] = 'Elija como ordenarlos';
$lang['Sort_order'] = 'Ordenar';
$lang['Sort_ascending'] = 'Ascendientemente';
$lang['Sort_descending'] = 'Descendientemente';

?>
