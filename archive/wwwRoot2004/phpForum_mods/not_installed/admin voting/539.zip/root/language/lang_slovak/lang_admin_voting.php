<?php
/***************************************************************************
 *                          lang_admin_voting.php [Slovak]
 *                              -------------------
 *     begin                : Sun, Sept 01, 2002
 *     copyright            : (C) 2002 ErDrRon
 *     email                : ErDrRon@aol.com
 *
 *     $Id: lang_admin_voting.php,v 1.1.8 12/04/2003 14:14:00 erdrron Exp $
 *
 *                slovak translation by Haldo --- haldo@pobox.sk
 *                 v�tam v�etky zmeny prip nov� verzie prekladu
 *									16.11.2003
 ****************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

// Admin Voting MOD
$lang['Admin_Vote_Explain'] = 'V�sledky hlasovan� (kto hlasoval a ako hlasoval).';
$lang['Admin_Vote_Title'] = 'Administr�cia hlasovan�';
$lang['Vote_id'] = '#';
$lang['Poll_topic'] = 'N�zov hlasovania';
$lang['Vote_username'] = 'Hlasovali';
$lang['Vote_end_date'] = 'D�ka hlasovania';
$lang['Sort_vote_id'] = '��slo hlasovania';
$lang['Sort_poll_topic'] = 'N�zov hlasovania';
$lang['Sort_vote_start'] = 'Za�iatok hlasovania';
$lang['Submit'] = 'Po�li';
$lang['Select_sort_field'] = 'Sp�sob zoradenia';
$lang['Sort_order'] = 'Zora�';
$lang['Sort_ascending'] = 'Vzostupne';
$lang['Sort_descending'] = 'Zostupne';

?>