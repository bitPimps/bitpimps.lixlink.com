<?php
/***************************************************************************
 *                          lang_admin_voting.php [Dutch]
 *                              -------------------
 *     begin                : Sun, Sept 01, 2002
 *     copyright            : (C) 2002 ErDrRon
 *     email                : ErDrRon@aol.com
 *
 *     $Id: lang_admin_voting.php,v 1.1.8 12/04/2003 14:14:00 erdrron Exp $
 *
 ****************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

// Admin Voting MOD 
$lang['Admin_Vote_Explain'] = 'Poll Resultaten (wie er gestemd heeft en hoe zij hebben gestemd).'; 
$lang['Admin_Vote_Title'] = 'Poll Administratie'; 
$lang['Vote_id'] = '#'; 
$lang['Poll_topic'] = 'Poll Onderwerp'; 
$lang['Vote_username'] = 'Stemmer(s)'; 
$lang['Vote_end_date'] = 'Stem Verloop'; 
$lang['Sort_vote_id'] = 'Poll Nummer'; 
$lang['Sort_poll_topic'] = 'Poll Onderwerp'; 
$lang['Sort_vote_start'] = 'Start Datum'; 
$lang['Submit'] = 'Sorteer'; 
$lang['Select_sort_field'] = 'Kies sorteer volgorde'; 
$lang['Sort_order'] = 'Sorteer'; 
$lang['Sort_ascending'] = 'Oplopend'; 
$lang['Sort_descending'] = 'Aflopend';

?>