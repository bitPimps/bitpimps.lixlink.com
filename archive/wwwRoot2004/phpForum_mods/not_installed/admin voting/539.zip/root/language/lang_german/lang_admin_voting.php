<?php 
/*************************************************************************** 
*                          lang_admin_voting.php [German] 
*                              ------------------- 
*     begin                : Sun, Sept 01, 2002 
*     copyright            : (C) 2002 ErDrRon 
*     email                : ErDrRon@aol.com 
* 
*     $Id: lang_admin_voting.php,v 1.1.8 12/04/2003 15:57 rpk Exp $ 
* 
****************************************************************************/ 

/*************************************************************************** 
* 
*   This program is free software; you can redistribute it and/or modify 
*   it under the terms of the GNU General Public License as published by 
*   the Free Software Foundation; either version 2 of the License, or 
*   (at your option) any later version. 
* 
***************************************************************************/ 

// Admin Voting MOD 
$lang['Admin_Vote_Explain'] = 'Umfrageergebnis anschauen (Wer hat abgestimmt und wer hat was gew�hlt).'; 
$lang['Admin_Vote_Title'] = 'Umfrage Administration'; 
$lang['Vote_id'] = 'Nr'; 
$lang['Poll_topic'] = 'Umfragetitel'; 
$lang['Vote_username'] = 'Wer hat abgestimmt'; 
$lang['Vote_end_date'] = 'Umfragedauer'; 
$lang['Sort_vote_id'] = 'Umfrage Nummer'; 
$lang['Sort_poll_topic'] = 'Umfragetitel'; 
$lang['Sort_vote_start'] = 'Starttag'; 
$lang['Submit'] = 'Absenden'; 
$lang['Select_sort_field'] = 'Sortierungs-Methode ausw�hlen'; 
$lang['Sort_order'] = 'Ordnung'; 
$lang['Sort_ascending'] = 'Aufsteigend'; 
$lang['Sort_descending'] = 'Absteigend'; 

?>