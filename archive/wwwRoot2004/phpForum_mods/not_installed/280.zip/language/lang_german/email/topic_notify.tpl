Subject: Benachrichtigen bei Antworten zum Thema "{TOPIC_TITLE}" im Forum "{FORUM_NAME}"
Charset: iso-8859-1

Hallo {USERNAME}!

{POSTERNAME} hat eine neue Antwort zum Thema "{TOPIC_TITLE}" im Forum "{FORUM_NAME}" auf {SITENAME} erstellt. Du kannst den folgenden Link benutzen, um direkt zum Thema zu gelanden:

{U_TOPIC}

-----------------------------------------------
Text des Beitrags:
{POST_TEXT}
-----------------------------------------------

Du erh�ltst diese E-Mail, weil du �ber Antworten im Thema "{TOPIC_TITLE}" auf {SITENAME} benachrichtigt werden wolltest. Bis du den Link besucht hast, werden keine weiteren Benachrichtigungen �ber dieses Topic an dich gesendet. Wenn du gar nicht mehr �ber Antworten in diesem Thema benachrichtigt werden m�chtest, dann klick den folgenden Link an:

{U_STOP_WATCHING_TOPIC}

{EMAIL_SIG}
