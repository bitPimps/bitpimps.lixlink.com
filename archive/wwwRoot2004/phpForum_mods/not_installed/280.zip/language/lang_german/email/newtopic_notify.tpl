Subject: Benachrichtigen bei neuen Beitr�gen im Forum "{FORUM_NAME}" - {TOPIC_TITLE}
Charset: iso-8859-1

Hallo {USERNAME}!

{POSTERNAME} hat einen neues Thema mit der Bezeichnung "{TOPIC_TITLE}" im Forum "{FORUM_NAME}" erstellt. Du kannst den folgenden Link benutzen, um direkt zum Thema zu gelanden:

{U_TOPIC}

-----------------------------------------------
Text des Beitrags:
{POST_TEXT}
-----------------------------------------------

Du erh�ltst diese E-Mail, weil du �ber neue Beitr�ge im Forum "{FORUM_NAME}" auf {SITENAME} benachrichtigt werden wolltest. Um die Benachrichtigung zu deaktivieren, benutze den folgenden Link:

{U_STOP_WATCHING_FORUM}

{EMAIL_SIG}
