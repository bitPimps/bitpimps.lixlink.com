



<table width="100%" cellspacing="2" cellpadding="2" border="0" align="center">
  <tr>
	<td align="left"><span class="nav"><a href="{U_INDEX}" class="nav">{L_INDEX}</a></span></td>
  </tr>
</table>

<table class="forumline" width="100%" cellspacing="1" cellpadding="3" border="0" align="center">
  <tr>
	<th class="thHead" height="25" nowrap="nowrap">{L_IRC_CHAT}</th>
  </tr>
  <tr>
	<td class="row1" valign="top" align="center">
<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" WIDTH="580" HEIGHT="350" id="ieirc"  ALIGN="">
<PARAM NAME="movie" VALUE="http://irc.icq.com/flash/IRCQNet.swf"><PARAM NAME="quality" VALUE="high"><PARAM NAME="bgcolor" VALUE="{T_TD_COLOR1}">
<PARAM NAME="flashvars" VALUE="addr=irc.icq.com&port=7012&defaultRoom=#{IRC_ROOM}&user_nickname={IRC_NICK}">
<EMBED src="http://irc.icq.com/flash/IRCQNet.swf" quity="high" bgcolor="{T_TD_COLOR1}" WIDTH="580" HEIGHT="350" NAME="nsirc" ALIGN=""
FLASHVARS="addr=irc.icq.com&port=7012&defaultRoom=#{IRC_ROOM}&user_nickname={IRC_NICK}"
TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer" id="nsirc">
</EMBED>
</OBJECT><br><br>

<div align="center"><span class="copyright">Use of IrCQ-Net is subject to the <a href="http://www.icq.com/legal/ircqnet.html" class="copyright">IrCQ-Net Terms of Use</a> and the <a href="http://www.icq.com/legal/">ICQ Terms of Service</a></span></div>


	</td>
  </tr>
</table>







