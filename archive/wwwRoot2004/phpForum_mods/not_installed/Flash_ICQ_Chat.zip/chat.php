<?php

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_VIEWONLINE);
init_userprefs($userdata);
//
// End session management
//

// session id check
if (!empty($HTTP_POST_VARS['sid']) || !empty($HTTP_GET_VARS['sid']))
{
	$sid = (!empty($HTTP_POST_VARS['sid'])) ? $HTTP_POST_VARS['sid'] : $HTTP_GET_VARS['sid'];
}
else
{
	$sid = '';
}



include($phpbb_root_path . 'includes/page_header.'.$phpEx);

// Set the IRC Chat room name, default is site name as appears on admin panel (just leave blank)
$irc_room = '';

$irc_room = (!empty($irc_room)) ? $irc_room : $board_config['sitename'];
$irc_nick = $userdata['username'] ;

// The IRC server blocks some unacceptable nicks. This is to bypass it using numbers instead of letters.
//You can add more words to the lists.
$unacceptable_nicks = array('admin', 'icq', 'aol','serv', 'oper');
$acceptable_nicks = array("adm1n", "1cq", 'a0l', '$erv', '0per');
$irc_nick = str_ireplace($unacceptable_nicks, $acceptable_nicks, $irc_nick);


// Changes IRC




$template->set_filenames(array(
	'body' => 'chat.tpl')
);

$template->assign_vars(array(
	'IRC_ROOM' => $irc_room,
	'IRC_NICK' => $irc_nick,
	'L_IRC_CHAT' => $lang['IRC_Chat'])
);

$template->pparse('body');

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);
?>
