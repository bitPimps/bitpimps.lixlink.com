<?php 
//////////////////////////////////////////////////////////////////////////// 
///                           ___                 
///                          /  /\                ___     
///    ###       ###        /  /::\              /  /\    
///  ##    ####     ##     /  /:/\:\            /  /:/    
/// ##    ##   ##    ##   /  /:/~/::\          /__/::\    
/// ##    ##         ##  /__/:/ /:/\:\         \__\/\:\__ 
/// ##    ##   ##    ##  \  \:\/:/__\/  /���/     \  \:\/\
///  ##    ####     ##    \  \::/                  \__\::/
///    ###       ###       \  \:\                  /__/:/ 
///                         \  \:\                 \__\/  
///                          \__\/                
//////////////////////////////////////////////////////////////////////////// 

/***************************************************************************
 *                             lang_ftr.php
 *                            --------------
 *		Version			: 1.0.1
 *		Email			: austin_inc@hotmail.com
 *		Site			: phpbb-amod.com
 *		Copyright		: aUsTiN-Inc 2003/4
 *
 ***************************************************************************/

# Commonly Used

$lang['Ftr_msg_error']					= 'Error';
$lang['Ftr_msg_success']				= 'Success';

# Buttons

$lang['Ftr_select_button']		= ' Select ';
$lang['Ftr_change_button']		= ' Change ';
$lang['Ftr_delete_button']		= ' Delete ';
$lang['Ftr_save_button']		= ' Save ';

# Admin Panel

$lang['Ftr_admin_users']			= 'Force Topic Read Admin: Users Who Have Viewed The Topic';
$lang['Ftr_total_user_error']		= 'Error Getting Total Users.';
$lang['Ftr_username']				= 'Username';
$lang['Ftr_post_date_time']			= 'Viewed Post Date &amp; Time';
$lang['Ftr_admin_user_delete']		= 'Force Topic Read Admin: Complete User Deletion';
$lang['Ftr_user_del_success']		= 'All Users Were Deleted.';
$lang['Ftr_save_config']			= 'Force Topic Read Admin: Save Configuration';
$lang['Ftr_save_config_success']	= 'Your New Config Settings Are Saved.';
$lang['Ftr_select_forum']			= 'Force Topic Read Admin: Select Forum';
$lang['Ftr_forum_choose']			= 'Choose The Forum:';
$lang['Ftr_set_config']				= 'Force Topic Read Admin: Set Configuration';
$lang['Ftr_topic_choose']			= 'Choose The Topic To Force Them To Read:';
$lang['Ftr_message']				= 'Type Your Message The User Will Receive Telling Them To View This Topic.';
$lang['Ftr_config']					= 'Force Topic Read Admin: Configuration';
$lang['Ftr_post_changed']			= 'Changed The Post &amp; Want Them To Re-Read It?';
$lang['Ftr_current_topic']			= 'Current Topic Being Used:';
$lang['Ftr_current_message']		= 'Current Message:';
$lang['Ftr_default']				= 'Choose A Forum';
$lang['Ftr_default2']				= 'Choose A Topic';

?>