<?php
// ############         Edit below         ########################################
$topic_length = '30';	// length of topic title
$topic_limit = '5';	// limit of displayed topics
$special_forums = '0';	// specify forums ('0' = no; '1' = yes)
$forum_ids = '';		// IDs of forums; separate them with a comma
$content = '300';	// length of displayed text
// ############         Edit above         ########################################

$sql_auth = "SELECT * FROM ". FORUMS_TABLE;
if( !$result_auth = $db->sql_query($sql_auth) )
{
	message_die(GENERAL_ERROR, 'could not query forums information.', '', __LINE__, __FILE__, $sql_auth);
}
$forums = array();
while( $row_auth = $db->sql_fetchrow($result_auth) )
{
	$forums[] = $row_auth;
}
$db->sql_freeresult($result_auth);

$is_auth_ary = array();
$is_auth_ary = auth(AUTH_ALL, AUTH_LIST_ALL, $userdata);

$except_forums = '\'start\'';
for( $f = 0; $f < count($forums); $f++ )
{
	if( (!$is_auth_ary[$forums[$f]['forum_id']]['auth_read']) || (!$is_auth_ary[$forums[$f]['forum_id']]['auth_view']) )
	{
		if( $except_forums == '\'start\'' )
		{
			$except_forums = $forums[$f]['forum_id'];
		}
		else
		{
			$except_forums .= ','. $forums[$f]['forum_id'];
		}
	}
}

$where_forums = ( $special_forums == '0' ) ? 't.forum_id NOT IN ('. $except_forums .')' : 't.forum_id NOT IN ('. $except_forums .') AND t.forum_id IN ('. $forum_ids .')';
$sql = "SELECT t.*, f.forum_id, f.forum_name, u.username AS first_poster, u.user_id AS first_poster_id, u2.username AS last_poster, u2.user_id AS last_poster_id, p.post_username AS first_poster_name, p2.post_username AS last_poster_name, p2.post_time, pt.*
	FROM ". TOPICS_TABLE ." t, ". FORUMS_TABLE ." f, ". USERS_TABLE ." u, ". POSTS_TABLE ." p, ". POSTS_TABLE ." p2, ". USERS_TABLE ." u2, ". POSTS_TEXT_TABLE ." pt
	WHERE $where_forums AND t.topic_poster = u.user_id AND f.forum_id = t.forum_id AND p.post_id = t.topic_first_post_id AND p2.post_id = t.topic_last_post_id AND u2.user_id = p2.poster_id AND t.topic_last_post_id = pt.post_id
	ORDER BY t.topic_last_post_id DESC LIMIT $topic_limit";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, 'could not obtain main information.', '', __LINE__, __FILE__, $sql);
}
$line = array();
while( $row = $db->sql_fetchrow($result) )
{
	$line[] = $row;
}
$db->sql_freeresult($result);
		
$orig_word = array();
$replacement_word = array();
obtain_word_list($orig_word, $replacement_word);

$tracking_topics = ( isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] .'_t']) ) ? unserialize($HTTP_COOKIE_VARS[$board_config['cookie_name'] .'_t']) : array();
$tracking_forums = ( isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] .'_f']) ) ? unserialize($HTTP_COOKIE_VARS[$board_config['cookie_name'] .'_f']) : array();
for( $i = 0; $i < count($line); $i++ )
{
	$forum_id = $line[$i]['forum_id'];
	$forum_url = append_sid("viewforum.$phpEx?". POST_FORUM_URL ."=$forum_id");
	$topic_id = $line[$i]['topic_id'];
	$topic_url = append_sid("viewtopic.$phpEx?". POST_TOPIC_URL ."=$topic_id");

	$word_censor = ( count($orig_word) ) ? preg_replace($orig_word, $replacement_word, $line[$i]['topic_title']) : $line[$i]['topic_title'];
	$topic_title = ( strlen($line[$i]['topic_title']) < $topic_length ) ? $word_censor : substr(stripslashes($word_censor), 0, $topic_length) .'...';

	$topic_type =  ( $line[$i]['topic_type'] == POST_ANNOUNCE ) ? $lang['Topic_Announcement'] .' ': '';
	$topic_type .= ( $line[$i]['topic_type'] == POST_GLOBAL_ANNOUNCE ) ? $lang['Topic_global_announcement'] .' ': '';
	$topic_type .= ( $line[$i]['topic_type'] == POST_STICKY ) ? $lang['Topic_Sticky'] .' ': '';
	$topic_type .= ( $line[$i]['topic_vote'] ) ? $lang['Topic_Poll'] .' ': '';

	$views = $line[$i]['topic_views'];
	$replies = $line[$i]['topic_replies'];
	if( ( $replies + 1 ) > $board_config['posts_per_page'] )
	{
		$total_pages = ceil( ( $replies + 1 ) / $board_config['posts_per_page'] );
		$goto_page = ' [ ';
		$times = '1';
		for( $j = 0; $j < $replies + 1; $j += $board_config['posts_per_page'] )
		{
			$goto_page .= '<a href="'. append_sid("viewtopic.$phpEx?". POST_TOPIC_URL ."=". $topic_id ."&amp;start=$j") .'">'. $times .'</a>';
			if( $times == '1' && $total_pages > '4' )
			{
				$goto_page .= ' ... ';
				$times = $total_pages - 3;
				$j += ( $total_pages - 4 ) * $board_config['posts_per_page'];
			}
			else if( $times < $total_pages )
			{
				$goto_page .= ', ';
			}
			$times++;
		}
		$goto_page .= ' ] ';
	}
	else
	{
		$goto_page = '';
	}

	if( $line[$i]['topic_status'] == TOPIC_LOCKED )
	{
		$folder = $images['folder_locked'];
		$folder_new = $images['folder_locked_new'];
	}
	else if( $line[$i]['topic_type'] == POST_ANNOUNCE )
	{
		$folder = $images['folder_announce'];
		$folder_new = $images['folder_announce_new'];
	}
	else if( $line[$i]['topic_type'] == POST_GLOBAL_ANNOUNCE )
	{
		$folder = $images['folder_global_announce'];
		$folder_new = $images['folder_global_announce_new'];
	}
	else if( $line[$i]['topic_type'] == POST_STICKY )
	{
		$folder = $images['folder_sticky'];
		$folder_new = $images['folder_sticky_new'];
	}
	else
	{
		if( $replies >= $board_config['hot_threshold'] )
		{
			$folder = $images['folder_hot'];
			$folder_new = $images['folder_hot_new'];
		}
		else
		{
			$folder = $images['folder'];
			$folder_new = $images['folder_new'];
		}
	}

	$newest_img = '';
	if( $userdata['session_logged_in'] )
	{
		if( $line[$i]['post_time'] > $userdata['user_lastvisit'] ) 
		{
			if( !empty($tracking_topics) || !empty($tracking_forums) || isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] .'_f_all']) )
			{
				$unread_topics = true;
				if( !empty($tracking_topics[$topic_id]) )
				{
					if( $tracking_topics[$topic_id] >= $line[$i]['post_time'] )
					{
						$unread_topics = false;
					}
				}
				if( !empty($tracking_forums[$forum_id]) )
				{
					if( $tracking_forums[$forum_id] >= $line[$i]['post_time'] )
					{
						$unread_topics = false;
					}
				}
				if( isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] .'_f_all']) )
				{
					if( $HTTP_COOKIE_VARS[$board_config['cookie_name'] .'_f_all'] >= $line[$i]['post_time'] )
					{
						$unread_topics = false;
					}
				}

				if( $unread_topics )
				{
					$folder_image = $folder_new;
					$folder_alt = $lang['New_posts'];
					$newest_img = '<a href="'. append_sid("viewtopic.$phpEx?". POST_TOPIC_URL ."=$topic_id&amp;view=newest") .'"><img src="'. $images['icon_newest_reply'] .'" alt="'. $lang['View_newest_post'] .'" title="'. $lang['View_newest_post'] .'" border="0" /></a> ';
				}
				else
				{
					$folder_image = $folder;
					$folder_alt = ( $line[$i]['topic_status'] == TOPIC_LOCKED ) ? $lang['Topic_locked'] : $lang['No_new_posts'];
					$newest_img = '';
				}
			}
			else
			{
				$folder_image = $folder_new;
				$folder_alt = ( $line[$i]['topic_status'] == TOPIC_LOCKED ) ? $lang['Topic_locked'] : $lang['New_posts'];
				$newest_img = '<a href="'. append_sid("viewtopic.$phpEx?". POST_TOPIC_URL ."=$topic_id&amp;view=newest") .'"><img src="'. $images['icon_newest_reply'] .'" alt="'. $lang['View_newest_post'] .'" title="'. $lang['View_newest_post'] .'" border="0" /></a> ';
			}
		}
		else 
		{
			$folder_image = $folder;
			$folder_alt = ( $line[$i]['topic_status'] == TOPIC_LOCKED ) ? $lang['Topic_locked'] : $lang['No_new_posts'];
			$newest_img = '';
		}
	}
	else
	{
		$folder_image = $folder;
		$folder_alt = ( $line[$i]['topic_status'] == TOPIC_LOCKED ) ? $lang['Topic_locked'] : $lang['No_new_posts'];
		$newest_img = '';
	}
				
	$first_time = create_date($board_config['default_dateformat'], $line[$i]['topic_time'], $board_config['board_timezone']);
	$first_author = ( $line[$i]['first_poster_id'] != ANONYMOUS ) ? '<a href="'. append_sid("profile.$phpEx?mode=viewprofile&amp;". POST_USERS_URL .'='. $line[$i]['first_poster_id']) .'">'. $line[$i]['first_poster'] .'</a>' : ( ($line[$i]['first_poster_name'] != '' ) ? $line[$i]['first_poster_name'] : $lang['Guest'] );
	$last_time = create_date($board_config['default_dateformat'], $line[$i]['post_time'], $board_config['board_timezone']);
	$last_author = ( $line[$i]['last_poster_id'] != ANONYMOUS ) ? '<a href="'. append_sid("profile.$phpEx?mode=viewprofile&amp;". POST_USERS_URL .'='. $line[$i]['last_poster_id']) .'">'. $line[$i]['last_poster'] .'</a>' : ( ($line[$i]['last_poster_name'] != '' ) ? $line[$i]['last_poster_name'] : $lang['Guest'] );
	$last_url = '<a href="'. append_sid("viewtopic.$phpEx?". POST_POST_URL .'='. $line[$i]['topic_last_post_id']) .'#'. $line[$i]['topic_last_post_id'] .'"><img src="'. $images['icon_latest_reply'] .'" alt="'. $lang['View_latest_post'] .'" title="'. $lang['View_latest_post'] .'" border="0" /></a>';

	include_once($phpbb_root_path . 'includes/bbcode.'.$phpEx);
	$post_text = preg_replace('/\:[0-9a-z\:]+\]/si', ']', $post_text);
	$post_text = $line[$i]['post_text'];
	$word_censor = ( count($orig_word) ) ? preg_replace($orig_word, $replacement_word, $post_text) : $post_text;
	$post_text = ( strlen($post_text) < $content ) ? $word_censor : substr(stripslashes($word_censor), 0, $content) .'...';
	$post_text = preg_replace('#(<)([\/]?.*?)(>)#is', '', $post_text);
	$pattern = array ('/\[quote:=\'/', '/\'\]/', '/\[quote:\]/', '/\[\/quote:\]/', '/\[code:(.*?)\]/', '/\[\/code:\]/', '/\[(.*?)\]/si');
	$replace = array ('', '<b>', '</b>:: ', '<b>Zitat: </b>', '</br>', '<b>Code: </b>', '</br>', '');
	$post_text = preg_replace($pattern, $replace, $post_text);
	$post_text = ( $include == '1' ) ? $post_text : smilies_pass($post_text);
	$post_text = str_replace("\n", "\n<br />\n", $post_text);
	$post_text = make_clickable($post_text); 

	$template->assign_block_vars('recent', array(
		'ROW_CLASS' => ( !($i % 2) ) ? $theme['td_class1'] : $theme['td_class2'],
		'POST_TEXT' => $post_text, 
		'TOPIC_TITLE' => $topic_title,
		'TOPIC_TYPE' => $topic_type,
		'GOTO_PAGE' => $goto_page,
		'L_VIEWS' => $lang['Views'],
		'VIEWS' => $views,
		'L_REPLIES' => $lang['Replies'],
		'REPLIES' => $replies,
		'NEWEST_IMG' => $newest_img,
		'TOPIC_FOLDER_IMG' => $folder_image,
		'TOPIC_FOLDER_ALT' => $folder_alt,
		'FIRST_TIME' => sprintf($lang['Recent_first'], $first_time),
		'FIRST_AUTHOR' => sprintf($lang['Recent_first_poster'], $first_author),
		'LAST_TIME' => $last_time,
		'LAST_AUTHOR' => $last_author,
		'LAST_URL' => $last_url,
		'FORUM_NAME' => $line[$i]['forum_name'],
		'U_VIEW_FORUM' => $forum_url,
		'U_VIEW_TOPIC' => $topic_url,
	));
}

$template->assign_vars(array(
	'L_RECENT_TITLE' => $topic_limit .' '. $lang['Recent_topics'],
	'L_RECENT_BY' => $lang['Recent_first_poster'],
	'L_RECENT_STARTED' => $lang['Recent_first'],
));

?>