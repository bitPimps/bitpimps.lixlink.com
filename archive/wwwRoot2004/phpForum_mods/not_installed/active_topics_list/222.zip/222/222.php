<?php
///////////////////////////////////////////////////////////////////////////////
//                            ACTIVE_TOPICS.PHP
///////////////////////////////////////////////////////////////////////////////
// Copyright:   (C) 2002 Matthijs van de Water <matthijs@beryllium.net>
// Version:     1.1
// Date:        03/02/2002
///////////////////////////////////////////////////////////////////////////////
// Show phpBB 2.0 Active Topics List
// Output format can be any HTML or XML
// This script must be able to access vital phpBB 2.0 configuration scripts
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// CUSTOM SETTINGS
///////////////////////////////////////////////////////////////////////////////

// Amount of active topics to show
define("TOPIC_COUNT", 10);

// Path to the phpBB 2.0 root directory
define("PHPBB_PATH", "../phpBB2/");

// URL to the phpBB 2.0 installation
define("PHPBB_LOCATION", "http://www.yourhost.com/phpBB2/");

// Time format to output the date/time (for format see PHP manual)
define("TIME_FORMAT", "H:i");

///////////////////////////////////////////////////////////////////////////////

// Includes of phpBB scripts
$phpbb_root_path = PHPBB_PATH;
if ( !defined('IN_PHPBB') ) 
{
  define('IN_PHPBB', true);
  include(PHPBB_PATH . 'extension.inc');
  include(PHPBB_PATH . 'config.'.$phpEx);
  include(PHPBB_PATH . 'includes/constants.'.$phpEx);
  include(PHPBB_PATH . 'includes/db.'.$phpEx);
}

///////////////////////////////////////////////////////////////////////////////
// HTML header start
///////////////////////////////////////////////////////////////////////////////
?>
<table border="0" cellpadding="3" cellspacing="1">
  <th>
    <td align="center" colspan="2">Currently Active Topics</td>
  </th>

<?php
///////////////////////////////////////////////////////////////////////////////
// HTML header end
///////////////////////////////////////////////////////////////////////////////

// sql statement to fetch active topics of public forums
$sql = "SELECT DISTINCT t.topic_title, t.topic_last_post_id, p.post_time, f.forum_name 
  FROM " . TOPICS_TABLE . " AS t, " . POSTS_TABLE . " AS p, " . FORUMS_TABLE . " AS f 
  WHERE 
    t.forum_id = f.forum_id 
      AND f.auth_view = " . AUTH_ALL . " 
      AND p.topic_id = t.topic_id 
      AND p.post_id = t.topic_last_post_id
  ORDER BY p.post_time DESC LIMIT " . TOPIC_COUNT;
$nt_result = $db->sql_query($sql);

if(!$nt_result)
{
    die("Failed obtaining list of active topics".mysql_error());
}
else
{
    $nt_data = $db->sql_fetchrowset($af_result);
}
    
if ( count($nt_data) == 0 )
{
    die("No topics found");
}
else
{
  // $nt_data contains all interesting data
  for ($i = 0; $i < count($nt_data); $i++)
  {
    $title = $nt_data[$i]['topic_title'];
    $url = PHPBB_LOCATION . 'viewtopic.' . $phpEx . "?" . POST_POST_URL . "=" . $nt_data[$i]['topic_last_post_id'] . "#" . $nt_data[$i]['topic_last_post_id'];
    $on_forum = 'On the ' . $nt_data[$i]['forum_name'] . ' forum';
    $post_time = date(TIME_FORMAT, $nt_data[$i]['post_time']);
    
    // As of now you can actually do anything with the data
    // I chose to output in XML

///////////////////////////////////////////////////////////////////////////////
// Item HTML start
///////////////////////////////////////////////////////////////////////////////
?>
  <tr>
    <td><?php echo $post_time; ?></td>
    <td><a href="<?php echo $url; ?>" title="<?php echo $on_forum; ?>"><?php echo $title; ?></a></td>
  </tr>
<?php
///////////////////////////////////////////////////////////////////////////////
// Item HTML end
///////////////////////////////////////////////////////////////////////////////

  }
}

///////////////////////////////////////////////////////////////////////////////
// Footer HTML start
///////////////////////////////////////////////////////////////////////////////
?>
</table>
<?php
///////////////////////////////////////////////////////////////////////////////
// Footer HTML end
///////////////////////////////////////////////////////////////////////////////

// EOF
?>