<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0; url=../index.php">
<title>Coppermine Photo Gallery - Albums Folder</title>
<link rel="stylesheet" href="../css/installer.css" type="text/css" />
<link rel="shortcut icon" href="../favicon.ico" />
<!--
  SVN version info:
  Coppermine version: 1.5.16
  $HeadURL: https://coppermine.svn.sourceforge.net/svnroot/coppermine/trunk/cpg1.5.x/albums/index.php $
  $Revision: 8243 $
  $LastChangedBy: gaugau $
  $Date: 2011-09-01 14:43:07 +0200 (Do, 01 Sep 2011) $
-->
</head>
<body>
<img src="../images/coppermine-logo.png" width="260" height="60" border="0" alt="" title="Coppermine Photo Gallery" />
<h1>Coppermine Photo Gallery - Albums Folder</h1>
<p align="center">The contents of this folder aren't meant to be browsed. Visit the Coppermine Photo Gallery instead - you'll be redirected.
If you don't want to wait (or your browser doesn't support redirect), click <a href="../index.php">here</a>.</p>
</body>
</html>