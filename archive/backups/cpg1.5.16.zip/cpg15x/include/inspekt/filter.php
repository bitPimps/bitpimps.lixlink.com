<?php
/*************************
  Coppermine Photo Gallery
  ************************
  Copyright (c) 2003-2011 Coppermine Dev Team
  v1.0 originally written by Gregory Demar

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License version 3
  as published by the Free Software Foundation.

  ********************************************
  Coppermine version: 1.5.16
  $HeadURL: https://coppermine.svn.sourceforge.net/svnroot/coppermine/trunk/cpg1.5.x/include/inspekt/filter.php $
  $Revision: 8243 $
**********************************************/

/**
 * We're not using this at all yet
 * @package Inspekt
 * @todo expand the filters to use class, inherit junk, other OOP crap
 */

/**
 * @package Inspekt
 */
class Inspekt_Filter {

	function Inspekt_Filter() {


	}


}

