# phpMyAdmin MySQL-Dump
# version 2.2.4
# http://phpwizard.net/phpMyAdmin/
# http://phpmyadmin.sourceforge.net/ (download page)
#
# Host: localhost
# Generation Time: Nov 16, 2003 at 04:13 PM
# Server version: 3.23.37
# PHP Version: 4.3.3
# Database : `lixlink`
# --------------------------------------------------------

#
# Table structure for table `Categories`
#

DROP TABLE IF EXISTS Categories;
CREATE TABLE Categories (
  ID int(11) NOT NULL auto_increment,
  Name varchar(100) default NULL,
  PRIMARY KEY  (ID)
) TYPE=MyISAM;

#
# Dumping data for table `Categories`
#

INSERT INTO Categories (ID, Name) VALUES (1, 'Action'),
(2, 'Adventure'),
(3, 'Animation'),
(4, 'Comedy'),
(5, 'Crime'),
(6, 'Documentary'),
(7, 'Drama'),
(8, 'Family'),
(9, 'Fantasy'),
(10, 'Horror'),
(11, 'Musical'),
(12, 'Mystery'),
(13, 'Romance'),
(14, 'Sci-Fi'),
(15, 'Thriller'),
(16, 'War'),
(17, 'Western'),
(18, 'Action');
# --------------------------------------------------------

#
# Table structure for table `Mediums`
#

DROP TABLE IF EXISTS Mediums;
CREATE TABLE Mediums (
  ID int(11) NOT NULL auto_increment,
  Name varchar(100) default NULL,
  PRIMARY KEY  (ID)
) TYPE=MyISAM;

#
# Dumping data for table `Mediums`
#

INSERT INTO Mediums (ID, Name) VALUES (1, 'DVD'),
(2, 'VHS');
# --------------------------------------------------------

#
# Table structure for table `MovieLookup`
#

DROP TABLE IF EXISTS MovieLookup;
CREATE TABLE MovieLookup (
  JID int(11) NOT NULL default '0',
  CID int(11) NOT NULL default '0',
  PRIMARY KEY  (JID,CID)
) TYPE=MyISAM;

#
# Dumping data for table `MovieLookup`
#

# --------------------------------------------------------

#
# Table structure for table `Projects`
#

DROP TABLE IF EXISTS Projects;
CREATE TABLE Projects (
  id int(11) NOT NULL auto_increment,
  orderId int(11) NOT NULL default '0',
  title text NOT NULL,
  url text NOT NULL,
  shortDesc text NOT NULL,
  image1 text NOT NULL,
  image2 text NOT NULL,
  image3 text NOT NULL,
  active int(4) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table `Projects`
#

INSERT INTO Projects (id, orderId, title, url, shortDesc, image1, image2, image3, active) VALUES (1, 1, 'ZeaVision', 'www.zeavision.com', 'ZeaVision LLC is a company that patented a dietary supplement, called zeaxanthin, that helps maintain vision health and brings hope to those with macular degeneration.<br /><br />\r\nMy role was programming the designs for the web while complying with ADA / 508 / WAI basic guidelines. Another feature added is the ability to increase or decrease the text size on the site to make it easier to read while still maintaining a visual appeal. I also created several Flash pieces for the site that act as information guides and attention grabbers. Other features include: Tell a Friend, Shopping Cart, Flash detection, dynamic content, administration screens, and more.<br /><br />\r\nI also helped implement voice recognition software that allowed ZeaVision to use any telephone to get the latest information about sales, stock, and more.', 'zeavision_1.jpg', 'zeavision_2.jpg', 'zeavision_3.jpg', 1),
(3, 3, 'BitPimps Custom Modifications', 'bitpimps.lixlink.com', 'BitPimps Custom Modifications is a widely popular community designed, programmed, and maintained entirely by myself.<br /><br />\r\nThe site itself boasts a large community forum with many contributing members, articles, news, video and graphic galleries, and more!<br /><br />\r\nI built in custom administration interfaces to help me in updating and maintaining the web site. The goal was to have a tool that would take little time and effort to keep the site fresh and running smoothly. Most of the content is dynamic and data drive, like most all the sites I develop.', 'bitpimps_1.jpg', 'bitpimps_2.jpg', 'bitpimps_3.jpg', 1),
(4, 2, 'Wear-Dated', 'www.wear-dated.com', 'A <a href="http://www.solutia.com" target="_blank">Solutia, Inc.</a> company, Wear-Dated Carpet Fiber and Wear-Dated Upholstery required a complete solution from the ground up, built from scratch.<br /><br />\r\nMy role was to program the designs in to a fully functioning site while meeting Solutia, Inc. IT teams strict standards and compliance initiatives. Key features include Flash detection, Find a Retailer search, Find Carpet search, survey\'s, registration and contact forms, and much more.<br /><br />\r\nThis site also has administration screens accessabile through the web browser that allows for easy and automatic updates to the site.', 'weardated_1.jpg', 'weardated_2.jpg', 'weardated_3.jpg', 1),
(5, 4, 'AXS Technologies', 'www.axs-tech.com', 'AXS Technologies is a world leader in developing software technologies that help speed the delivery of data, such as hi-res imaging, data mining, signal correlation, storage, and more.<br /><br />\r\nMy role was to program the designs in to functioning web pages, and integrating the companies \\"EyeSpy\\" technology in to the web site itself. Some features include EyeSpy image demo\\\'s, Tell a Friend and Contact forms, dynamically generated pages, Press Releases maintained by administration screens, and more.', 'axstech_1.jpg', 'axstech_2.jpg', 'axstech_3.jpg', 1),
(6, 5, 'IconProcess', 'www.iconprocess.com', 'IconProcess is a site based around e-development processes for web and software developers. The site itself, the name, branding, architecture, design, programming, etc. was all built from nothing but an idea.<br /><br />\r\nMy role was to program the entire site including most of the back-end functionality. Features like subscribing, news and press releases, tell a friend, download requests, contact forms, etc. are all maintained via an administration portal provided through an interface identical to that of the public site.', 'iconprocess_1.jpg', 'iconprocess_2.jpg', 'iconprocess_3.jpg', 1),
(7, 6, 'IAHP', 'www.iahp.com', 'International Alliance of Health-care Practitioners (IAHP) offers both patients and practiitioners a chance to enhance their knowledge and network with others. The site provides information and offers subscribed users a chance to build their own micro-site from several templating systems. All of this information is stored in a database and the content on the page is dynamically driven, user friendly and usable.<br /><br />\r\nMy main role was to program the entire front end of the web site, as well as support the project by coming up with new ideas to achieve certain goals such as attracting potential customers and providing current customers the ability to create and manage their own micro-site through an administration interface provided to members of the web site.', 'iahp_1.jpg', 'iahp_2.jpg', 'iahp_3.jpg', 1),
(8, 7, 'IconMedialab Advanced Technology Group', 'www.iconmedialabatg.com', 'The company I currently work for as a developer in many areas with the main focus being web development. This site was a collaborative effort between our San Francisco office and myself here at the St. Louis office.<br /><br />\r\nMy main role has been to complete the templating system and behind the scene\\\'s functionality. I\\\'ve also been responsible for updates, maintenance, data entry, audio / video embedding, and more. Administration screens provide an easy to use interface to help in updating and maintaining the site. The site also track\\\'s information about downloads, logins, etc. and has several subscription services.', 'iconatg_1.jpg', 'iconatg_2.jpg', 'iconatg_3.jpg', 1),
(9, 8, 'IconTraining', 'training.iconmedialab.us', 'IconTraining advertises and offers custom training solutions to businesses and individuals. The site announces the latest in training methods, key speakers, locations, and more. All of this information is stored in a database and the web site itself is dynamically data-driven and maintained through administration screens.<br /><br />\r\nMy main role was to program the entire front end of the web site as well as part of the back end. I\\\'ve also maintained and updated the site regularly as well as adding on new features that tie in to more data-driven content.', 'icontraining_1.jpg', 'icontraining_2.jpg', 'icontraining_3.jpg', 1),
(10, 10, 'e-Wireless #333', 'resume.lixlink.com/portfolio.php?id=10', 'e-Wireless (#333) was a company using cell phone technology to offer consumers connection services, advertisements, information gathering, etc.<br /><br />\r\nIn one of many roles, I helped with site architecture, some design and back-end programming. Most of my work was done on the front-end programming aspect where I translated all the designs into workable HTML pages that interfaced with back-end server technologies and applications.', '333_1.jpg', '333_2.jpg', '333_3.jpg', 1),
(11, 11, 'IconProject Site', 'www.secureinsight.com/projectsite/', 'A site for IconMedialab\\\'s client\\\'s and employees to communicate with each other. Track project status, deliverables, and much more.<br /><br />\r\nMy role was to help conceptualize, layout, design, and program the entire site / application.', 'iconprojectsite_1.jpg', 'iconprojectsite_2.jpg', 'iconprojectsite_3.jpg', 1),
(12, 12, 'IAHE', 'www.iahe.com', 'IAHE (International Alliance of Healthcare Educators is a site dedicated to the presentation of high-quality educational programs for interested healthcare professionals from all disciplines.<br /><br />\r\nMy roles were to help program some of the front-end elements in to the site as well as help maintain and update the site per the client\'s requests.', 'iahe_1.jpg', 'iahe_2.jpg', 'iahe_3.jpg', 1),
(13, 13, 'O\'Fallon Jaycees', 'www.ofallonjc.org', 'O\'Fallon Jaycee\'s is a chapter in a non-profit organization that helps communities in several aspects.<br /><br />\r\nSince it\'s formation in March of 1984, the O\'Fallon Jaycees have been steeped in a tradition of community service and leadership. The Chapter is not only a civic leader in the city of O\'Fallon but also in the state of Missouri, being named the "Outstanding Chapter of the Year" in 1994 and 1998. The O\'Fallon Jaycees efforts have affected all ages, from small children to senior citizens.<br /><br />\r\nMy role was to design and program the entire front-end of the website.', 'jaycees_1.jpg', 'jaycees_2.jpg', 'jaycees_3.jpg', 1),
(14, 14, 'The Upledger Institute Inc.', 'www.upledger.com', 'A health resource center run by doctors in the industry that span across several professions, provides healthcare information, education and more for patients, doctors, and everyone else.<br /><br />\r\nMy role was to help program a few small pieces of the web site as well as some maintenance and updates.', 'upledger_1.jpg', 'upledger_2.jpg', 'upledger_3.jpg', 1),
(15, 15, 'Acrilan Fiber', 'www.acrilan.com', 'A subsidiary of Solutia, Inc., Acrilan Fiber provides information, facts, samples and more - to consumers.<br /><br />\r\nMy role was to program the entire web site to meet Solutia\'s IT departments strict standards, which I did.', 'acrilan_1.jpg', 'acrilan_2.jpg', 'acrilan_3.jpg', 1),
(16, 16, 'Scott D. Lix (v. 1.0)', 'www.lixlink.com', 'My first online portfolio / personalized site. I designed and programmed the entire site - front end to back end. The site itself has some neat features like "Tell a Friend", "Increase or Decrease Font Size", and more. The site utilizes a template based structure system, data driven content and has administration screens to help maintain all aspects of the web site.', 'lixlink_1.jpg', 'lixlink_2.jpg', 'lixlink_3.jpg', 1),
(17, 17, 'IconCampaign Tracker', 'www.secureinsight.com/tracker/', 'The IconCampaign Tracker allows sales staff from all the IconMedialab offices to keep track of the email campaigns they have sent out, the list of people they sent it to, the links clicked on, etc.<br /><br />\r\nMy role was to complete the marketing tool in a day, have it function and usable.', 'iconcampaigntracker_1.jpg', 'iconcampaigntracker_2.jpg', 'iconcampaigntracker_3.jpg', 1),
(18, 18, 'IconConsulting', 'consulting.iconmedialab.com', 'IconConsulting is a marketing portal for IconMedialab Consultants and potential clients. Offering information on the in\'s and out\'s of IconConsulting.<br /><br />\r\nMy role was to program the entire public site as well as administration screens to help administer the site. The site itself also ties in to IconTraining.', 'iconconsulting_1.jpg', 'iconconsulting_2.jpg', 'iconconsulting_3.jpg', 1),
(19, 19, 'IconConsultant Database', 'www.secureinsight.com/consultantsAdminPorthole/', 'This application allows users with the correct permissions to administer all Consultants for the St. Louis and DC offices.<br /><br />\r\nMy role was to design and program the front end as well as some of the back end of the website.', 'iconconsultantdb_1.jpg', 'iconconsultantdb_2.jpg', 'iconconsultantdb_3.jpg', 1),
(20, 20, 'La Chata Mexican Restaurant', 'lachata.lixlink.com', 'La Chata Mexican Restaurant is an authentic Mexican restaurant that offers drinks, food, specials, and authentic Mexican crafts and art pieces. La Chata needed more advertisement and a way to introduce themselves and their information to more people - so they got this website.<br /><br />\r\nI designed and programmed the entire site and help maintain and update the site as well as host the site.', 'lachata_1.jpg', 'lachata_2.jpg', 'lachata_3.jpg', 1),
(21, 9, 'TruSecure', 'www.trusecure.com', 'TruSecure is a leading provider of intelligent risk management products and services. TruSecure claims to dramatically improve security and reduce risk by helping organizations make better security decisions and maximize the effectiveness of their existing security people, processes, and products.<br /><br />\r\nMy role was to program the entire front-end of the website, meeting cross-browser, cross-platform, and usability standards. The site is also very heavily integrated with a content management system that was previously used, but needed to be completely re-done to accomidate the new features on the site. Coding, making graphics, scripting, and de-bugging were the major roles I played in this project.<br /><br />\r\nThe project itself was a daunting task as time, tools, and learning curves all play significant roles in the project life cycle and timeline. With all the obsticles in our path, essentially a 2 man team was able to met the project deadline and deliver the best possible solution with the project requirements and constraints.', 'trusecure_1.jpg', 'trusecure_2.jpg', 'trusecure_3.jpg', 1),
(22, -1, 'My DVD Movies', 'movies.lixlink.com', 'As a huge movie fan, the wife and I have hundreds of DVDs, it\\\'s near impossible to keep track just in your head so while we re-organized with a new entertainment stand, we re-organized and documented our collection of DVD movies in an online database. It gives our family and friends access to our movie listings to see what we do and don\\\'t have. It also helps us not only to keep track of those DVDs, but helps us pick out something to watch as we sort through the listing by genre.', '', '', '', 0),
(23, 21, 'My DVD Movies', 'movies.lixlink.com', 'Being huge movie fans, the wife and I decided it was time to get organized. And what a better time to start the effort than when you\\\'re getting a new entertainment stand? Well that was our thoughts exactly so that is what we did.<br /><br />\r\nI built an interface to visually display all the DVD movies we own in a list. I also built another interface to interact with the online database so we could easily add or edit an entry.<br /><br />\r\nThe list not only helps us keep track of the movies we do and don\\\'t have, but it allows friends and family access to our movie listings for whatever purposes they may have. The list also helps us to pick out a movie to watch when we\\\'re not too sure what kind of mood we\\\'re in. With the sorting functions, it\\\'s easy to narrow down the listings to a small group of movies.', 'mymovies_1.jpg', 'mymovies_2.jpg', 'mymovies_3.jpg', 1);
# --------------------------------------------------------

#
# Table structure for table `Resume`
#

DROP TABLE IF EXISTS Resume;
CREATE TABLE Resume (
  id int(11) NOT NULL auto_increment,
  summary text NOT NULL,
  skillsLang text NOT NULL,
  skillsSoft text NOT NULL,
  expPosition text NOT NULL,
  expCompany text NOT NULL,
  expTimeHeld text NOT NULL,
  expResponsibilities text NOT NULL,
  active int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table `Resume`
#

# --------------------------------------------------------

#
# Table structure for table `blogentries`
#

DROP TABLE IF EXISTS blogentries;
CREATE TABLE blogentries (
  blogEntryID int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  headline text NOT NULL,
  blogEntryDate datetime NOT NULL default '0000-00-00 00:00:00',
  leadPhrase text NOT NULL,
  bodyCopy mediumtext NOT NULL,
  PRIMARY KEY  (blogEntryID)
) TYPE=MyISAM;

#
# Dumping data for table `blogentries`
#

INSERT INTO blogentries (blogEntryID, publishFlag, headline, blogEntryDate, leadPhrase, bodyCopy) VALUES (1, 1, 'Blame It On The Environment', '2002-02-25 00:00:00', '', '<p><br />No not the one in which we live, but the one in which I develop on personal time. There\\\'s a huge story behind this whole fiasco that I might reveal some other time, but for now I\\\'ll give you the gist of what is causing me grief now.</p>\r\n<p>For several reasons, I can never choose on a design for my personal site long enough to actually build and implement it, so I\\\'ve finally forced myself to stick with the current design/layout you see now. I\\\'m fine with that part of it, what is killing me now is that I haven\\\'t taken the time and hair-loss to setup my development environment properly, now it has come back to haunt me. I\\\'ve worked around it successfully now for quite sometime, but I can no longer run and hide from the cold hard facts, I must change OSs. There\\\'s another huge story behind that as well, which again, I\\\'ll probably itterate on in the future...</p>\r\n<p>So what\\\'s the outcome of all this garbage? I\\\'ve given pre-mature birth to my site, right now it has many conditions:</p>\r\n<p>- it looks like shit<br />\r\n- it works like shit<br />\r\n- it\\\'s organized like shit<br />\r\n- it\\\'s live online</p>\r\n<p>I really hate that fact, but if I want to test, I have no choice unless I want to end up changing paths for the rest of my life or go back to trying to find a properly compatible OS (which will decrease my life span due to stress and the frustrations of device drivers).</p>'),
(2, 1, 'Controversy Is Supposed To Be Entertaining', '2002-03-01 00:00:00', '', '<p><br />\r\nThe Olympics have caused me to re-evaluate my standards on controversy. Nothing is shocking after all the judging scandals and physical enhancement substances, both past and present. It�s now commonplace and expected to have political scandals as well as other scandals in just about everything in life.</p>\r\n<p>Nothing surprises anyone now days. Every night our local news informs us of some 9 year-old drug lord with a 37 year-old �mistress� (undoubtedly his teacher, who in turn is married to the local priest) and 3 surrogate children, who just stabbed the lunch lady with a No. 2 pencil because she was wearing the color of eye-shadow of a rival gang.</p><p>\r\nThat�s why NASCAR exists, nobody watches because the cars drive around in a mind-numbing circle all day long, they watch because inevitably there is going to be a huge crash consisting of flames, debris flying, rubber marks leaving evidence, etc. We all like the �glory story� where the good guy wins and evil falls at the hands of good, but even more so, most of us like to see a little �doom and gloom� enter some unexpecting victims lives, it makes the kick in the chops life gives just a tad easier to take. So with that in mind, what sporting event compares to the Olympics, yet is full of trials, tribulations and such poor performance, it makes you look and feel like a gold medal triathelete? The Special Olympics!</p>\r\n<p>Consider what could happen here if the Special Olympics were held in such a high regard and was just as marketable. People would not only get the satisfaction of competition, but they would also get the empowering feeling of superiority to the physically/mentally challenged athlete.</p>\r\n<p>You would see total blowouts. One slobbering fool absolutely creaming his competition because they�re all back at the starting line fingering the fecal matter secreting from their �sports striped� shorts with matching socks (pulled past the calf of course). Think about what the �popular� events would be, just like snowboarding in the Winter Olympics or the 500 meter dash in the Summer Olympics, Roman Greco Wrestling in the Special Olympics would be even more entertaining. Just imaging two �Special Olympiads� would engage each other in physical combat, and as well all know, �special� people don�t like their ears being touched! Well that�s the thing that gets touched the most in any wrestling, that�s why wrestlers get cauliflower ear. It would be like a scene out of the movie �There�s Something About Mary� when �Warren� (the retard) gets his ear muffs pulled off, Warren goes ballistic and starts madly flailing about. I can see this happening in the Special Olympics too, you know the ref would have to try and step in and stop the insanity, but retards don�t know any better, they�ll turn cannibalistic on the ref and by that point we have a Japanese TV game show on our hands!</p>'),
(3, 1, 'It\\\'s The American Way!', '2002-03-10 00:00:00', '', '<p><br />I recently found out that my wife and I both made a mistake while filling out our <A HREF=\\"http://www.irs.gov/pub/irs-pdf/fw4_02.pdf\\" TARGET=\\"_blank\\">W-4 forms</A>. Due to that minor mistake, we now owe just over $4,000.00 (US)! Additionally, we just bought a house and had to pay through the nose to break our lease at the apartment complex we were living in. Here\\\'s a little insight into that whole fiasco</p>\r\n<P>My wife and I thought we would be saving money when we signed a 1 year lease at the apartment complex we decided to live at. First off, the place was brand new, units were still being constructed as a matter of fact. Since it was new, it looked great, there was no time for anything to be run down or go without maintenance. To move in, it\\\'s required you sign a lease, either 6 months or 1 year. If you choose a 6 month lease, they charge you an extra $75.00 per month for rent (on top of the $930.00 we were paying already). To top things off, there was no assigned parking, first come, first serve! So needless to say, we quickly found out that we couldn\\\'t wait to get the hell out of that place, we immediately started looking for a house.</P><P>\r\nLooking for a house is a huge story in itself so I\\\'ll spare you the details and give you the gist. The outcome was that after many long, frustrating days and unbelievabley high prices and even higher rates on mortgages, we finally found a house, but we had to move on it in record time. We quickly got everything in line, which caused me to loose at least 7 years off my life I\\\'m sure, and signed the deal. To get out of our lease agreement with the apartment complex, we had to pay their \\"penalty fee\\" for breaking the lease, which came to around $2,300.00. Of course to buy a house we needed to come up with the closing costs, which came to around $2,000.00. So totalling it all up, we\\\'ve paid around $8,300.00 dollars in just a few short months, right around the Christmas months, that means presents, and that means, more money to be spent. Unbelievably we\\\'ve managed to keep our heads above water so far, although after finding out that I owe the government another $4,000.00 on top of the $10,000.00 I\\\'ve already given them personally for the year, makes me feel defeated.</P><P>\r\nSo, today we went to the grocery to re-stock the house and spent $300.00, my truck and both credit card payments are due, we had to buy a refridgerator, dishwasher, water-softener, and humidifier. Now that I\\\'m past the point of being totally broke, I\\\'m coming close to admitting my defeat and went out and bought a $52.00 bottle of Cabo Wabo tequilla and am making margaritas till I forget about life in general!</P>'),
(4, 1, 'I\\\'m a Programmer Who Won\\\'t Shoot You!', '2002-03-26 00:00:00', '', '<p><br />\r\nI find it funny how programmers have a general stereotype:<br />\r\n- Introverts<br />\r\n- Loaners<br />\r\n- Mentally Unstable (at best)<br />\r\n- Socially Retarded<br />\r\n- Suspicious<br />\r\n- Methodical</p>\r\n<p>Beyond that, probably voted most likely to quietly and systematically peruse from office to office painting the walls with fellow employees\\\' brain matter.|*||*|While I have each of these traits, I try to be as outgoing as possible so as to help project an approachable persona. I feel that more people would confront me if they felt that I wasn\\\'t going to go home and design a structured attack against their lives. Such is the plight of a programmer, destined to be alone and stuck in a dark corner where no one dares to venture.</p>\r\n<p>I believe the fear comes from these traits, knowing a programmer would call upon these traits to accomplish their goals in the most logical fashion. If a programmer were to go crazy and start a dastardly plan, they would use their structured and orderly thought processes to create a meticulous plan. Come to think of it, one could easily equate a programmer killing people with a programmer building an application or online system, etc., let�s examine this thought further by representing a �project plan� that seems to fit with either goal:</p>\r\n<p><b>Phase 1 � Inception / Elaboration:</b><br />Get all the requirements, basic facts, and brainstorming, coming up with ideas on how to achieve the goals set forth.</p>\r\n<p><b>Phase 2 �Design / Development:</b><br />Building and acquiring other items of consequence to getting the job done while working out details to fine tune the system.</p>\r\n<p><b>Phase 3 � Testing / Deployment:</b><br />This phase is left for building projects only, after all, how could you test if your planned killing worked correctly or not without turning into a mass-murderer.</p>\r\n<p><b>Phase 4 � Post Mortem:</b><br />\r\nTime to reflect on the project, were the goals achieved? Could they have been achieved in a more efficient manner? Get hind sight for future projects, increasing the likelihood that each project there after would get better and better with the knowledge gained.</p>\r\n<p>As you can plainly see, disciplined programmers approach tasks with carefully and precisely planned thought processes while paying attention to details. This is what makes the programmer suspicious and methodical. After programming all day and speaking very little except for the occasional threat made to a monitor (apparently only mentally unstable introverts have conversations with their monitor), anyone would look for some sort of break. Striving to communicate in a non-work related manor, the programmer seeks out a soul for conversation, unwittingly backing themselves into a corner where coherent sentences turn to stuttered fragments, making the programmer seem socially retarded.</p>\r\n<p>I suppose the fact that I could equate these two makes me mentally unstable (at best).</p>'),
(5, 1, 'Yet Another Web Site Comes To Life', '2002-03-29 00:00:00', '', '<p><br />\r\nToday we launched the <a href=\\"http://www.zeavision.com\\" target=\\"_blank\\">ZeaVision&#0153;</a> web site. The actual launch date was set for April 1, 2002, we (<a href=\\"http://www.iconmedialab.com\\" target=\\"_blank\\">IconMedialab</a>) exceeded that deadline, which was very tight to start. IconMedialab basically created the ZeaVision company through branding and marketing efforts tied into a web-enabled application for multiple users needing to accomplish multiple tasks.</p>\r\n<p>I was very impressed with this project for many reasons, which isn\\\'t uncommon for the team I work with, however I did manage to impress myself on this project, which is rare. Here are a few items that I\\\'m most proud of on this project when speaking about the results of my programming efforts:</p>\r\n<ol>\r\n<li>The site meets ADA compliance with no \\"Priority 1\\" errors. (All other errors cannot be fixed without comprimising design a great deal.)</li>\r\n<li>The site utilizes CSS technology, thereby rendering the browsers \\"Font Size\\" settings useless. The site has an \\"Increase font size\\" and \\"Decrease font size\\" tool to allow readers to set their preference, which is remembered.</li>\r\n<li>The public side of the site looks and functions exactly the same on all browsers (WebTV has a slight variation of text size) and all platforms.</li>\r\n<li>The site should be fully compliant with HTML 4.01 specifications and 95% XHTML compliant, though I haven\\\'t varified this as of yet.</li>\r\n<li>I managed to crank all this out in 45 hours.</li>\r\n</ol>'),
(6, 0, 'Nice(Uncomfortable) To Meet You', '2002-04-30 00:00:00', '', 'I could never be a salesperson. Matter of fact I can barely deal with the normal everyday interaction between the general public and myself. I\\\'ve been what I concider to be socially retarded for years now and I\\\'m used to it. However, it seems that things are changing yet again and now I can barely speak coheriently. Most of my words are starting to get jumbled and I get anxious and spit out fucked up words thrown together to form sentence fragments that make me sound like I have a similar medical condition to terrets and make no sense to the listener/s. Now throw in not knowing someone and meeting them for the first time, in a business sense. Yea, as you can imagine, there\\\'s more akward and uncomfortable silence than being an alter boy sitting alone with a pastor in a deselate church (of course dimmed lights and jesus sets the mood - the rosary beeds scare you). As my \\"condition\\" worsens, I fear one day I\\\'ll end up driving everyone away from me until I\\\'m left to myself, completely. Who will I avoid and run from then?'),
(7, 0, 'Nothing Brings People Together Like An Abscess!', '2002-05-08 00:00:00', '', '<p><br />That\\\'s right, an abscess!<br />\r\nI recently noticed yet another abscess on my tail bone. Rather than going to the doctor, which I refuse to do, I had my wife dig it out.</p>\r\n<p>Normally that\\\'s no big deal, but when your wife is digging in your ass with a needle, all shyness goes out the window. As horrible of an experience this is, it really makes me appreciate having someone around, I wouldn\\\'t even have my mother help me out of this jam!</p>\r\n<p>While I\\\'m thankful to have someone around to help me that I feel comfortable with, I am seriously sick of my ass needing to be attended to by anyone other than myself for any other reasons besides cleaning it! I feel violated.</p>'),
(8, 1, 'Describing Me, As Told By Me: Procrastinator', '2002-05-26 00:00:00', '', '<p><br />Me being a procrastinator has yet again kicked my ass, when it comes to dealing with this website in particular. The reasoning / fault here lies in my logic, not code, but of course the most flawed, human logic. In the beginning, I intended to use this site as a �playground� of sorts, a place to prove theories of mine, express some of my interests and have a little fun somewhere in amongst it all. I quickly realized that as my knowledge and potential increased, as far as building websites and web applications grew, so did my expectations and scope creep. I had become the much feared and loathed client type my industry fears, the indecisive client with no real concept of how to reach the overall goal.</p>\r\n<p>My idea was to quickly build a site with backend interfaces and logic to help assist me in the building and implementation of content and a few other gadgets. This also happened to be my weak spot, building suitable backend components that met both my standards and the standards of the server I currently use. As it turns out, my expectations have increased considerably since the inception of this project while my skills have tried to keep up in vein. The backend seems to be what is holding me and this website in a perpetual state of construction. I had anticipated some of this, however there is something else I had not thought of, and that was visitors coming before I had actually publish the site to search engines. I really didn�t think I would start getting visitors beyond the ones I had specifically sent to the site for a purpose, however, I didn�t think of the fact that those same people might tell someone else, which would start the wheel in motion, the wheel I had plans on keeping from rolling until I was good and ready.</p>\r\n<p>As I�m sure you can guess, the traffic keeps increasing, I still haven�t submitted the site to any engines or lists, due to the lack of content, design, function, and anything else that may have some sort of entertainment value or interest what so ever. Well now that the traffic has increased, I have no other choice but to use that to my advantage and try to complete this site as much as possible.</p>\r\n<p>At least that�s what I�m telling myself, but as you can plainly see from both the subject title of this rant as well as the completion of the website itself, that reality is probably a long way off. After all, I�m a procrastinator.</p>'),
(9, 1, 'Mini RC Cars - These are bitch!', '2002-07-09 00:00:00', '', '<p><br /><strong><a href=\\"http://www.tomy.com\\" target=\\"_blank\\">Bit Char-G</a></strong> (sprung from cell phone technology) are the second smallest, fully functioning R/C car in the world, 60mm long. The power source is a small nicad battery that runs for over two minutes per charge in most cases, and it only takes about 45 seconds to charge using the docking station on the remote control. There are various makes of cars as well as an array of accessories and upgrades such as tires, gears, motors, and you can even get a new body to paint. Their range is around 20 feet and come in 4 different radio frequencies, allowing multiple cars to run at once (hence racing and friends becoming enemies for the time being).</p>'),
(10, 1, 'Politically Correctness Getting Out of Hand', '2002-07-12 00:00:00', '', '<p><br />After reading headlines about <a href=\\"http://www.cnn.com/2002/SHOWBIZ/TV/07/12/sesame.street.reut/index.html\\" target=\\"_blank\\">HIV positive Muppets on Sesame Street</a>, <a href=\\"http://story.news.yahoo.com/news?tmpl=story&cid=856&ncid=856&e=1&u=/nm/20020712/od_uk_nm/oukoe_airlines_southwest_1\\" target=\\"_blank\\">Obese flyers</a> mad for having to purchase extra seats to allow their fat folds to hang from side to side, and all the other sorts of PC complaints, I\\\'ve come to the conclusion that I too should join the ranks and force my opinions upon others. Do what I like or else!</p>\r\n<p>For instance the whole obese flyers thing, what rational thinking adult would have a problem with airlines\\\' new rules? Why is it unacceptable to require obese people to purchase extra seats? I look at it like smoking. I can\\\'t smoke on an airplane or in most buildings for the main reason that non-smokers don\\\'t want to smell the smoke or be introduced to possible health risks or to have their comfort level disrupted. Why doesn\\\'t that same approach work for obese people in tiny, crammed close together seats? Most of us have flown enough to remember how cramped it was just sitting next to a normal, healthy sized adult. No elbow room, no leg room, and you\\\'re sitting close enough to count imperfections in their face. Now imagine sitting next to someone who\\\'s fat folds are falling out of the constraints of the seat and onto you! Not only are they invading on your personal space, but the pose some serious risks as well. What if something were to happen and people had to make emergency exits from the plane in a hurry. But this mammoth is trapped in their seat, blocking in the rest of the passengers. I think most of us can see the point here so I\\\'ll leave it at that.</p>'),
(11, 1, 'Not like anyone will see but...', '2002-09-06 00:00:00', '', '<p><br />I\\\'ve added yet another site to my arsenal: <a href=\\"http://www.weardated.com/\\" target=\\"_blank\\">Wear-Dated� Carpet Fiber</a> and <a href=\\"http://www.weardated.com/pages/upholstery/default.htm\\" target=\\"_blank\\">Wear-Dated� Upholstery Fabrics</a>.</p>'),
(12, 1, 'Sheezy My Neezy, My Websites So Cheesey', '2002-11-12 00:00:00', '', '<p><br />I\\\'ve managed to allow my website to turn into a piece of shit. This really comes as no surprise to me as most of my personal endevors on the Internet end up taking a back seat to other more interesting projects.</p>\r\n<p>Currently I\\\'m working on dynamic, data-driven, flash applications for hand-held devices. Obviously this holds much higher interests as far as \\"pushing the boundries\\" goes and has caused me to forget about everything else. I do however still plan on finishing my tons of already started projects and have thoughts about new projects.</p>\r\n<p>Look for the <a href=\\"http://bitpimps.lixlink.com/\\">bitPimps</a> site to be published within a few more months. I know, that\\\'s no real tight deadline, but as I mentioned before, all efforts are <em>not</em> on this project right now. Matter of fact, you would think I would finish my own personal site before taking on others, well that\\\'s not the case. Bummer for me and anyone visiting this junk. :O</p>'),
(13, 0, 'Once an egotistical, backstabbing piece of shit, always an egotistical, backstabbing piece of shit', '2002-11-18 00:00:00', '', '<p><br />\r\nYup, you read the title right. It�s all about people (pieces of shit) who think (egotistical) they are the smartest, most funny individuals to have blessed you with their presence in all of time.</p>\r\n<p>Yea I know, those people are commonplace, but truth be told, their aspirations are far from reality. I have several hypotheses to illustrate this point:</p>\r\n<ol>\r\n  <li>Most people are egotistical, on a daily basis; they have to speak of someone or something else in a negative manner so they feel better about themselves and their lives. It works, but only for ignorant individuals with an ego the size of Texas!</li>\r\n  <li>Most people live in a �fairy-tale� where all their dreams come true and they don�t have to think about the realities of the world and their actions in it.</li>\r\n  <li>Most people truly believe they are better than their environment, its make-up and their surroundings, they feel as if they don�t belong in such a miniscule world that offers nothing intellectual to them or poses a threat to their superiority.</li>\r\n</ol>\r\n<p>The reality of it all is this:<br />\r\nMost people are egotistical, backstabbing pieces of shit.\r\nWhy? Simple, because they lack the knowledge, dedication and drive to accomplish their goals and aspirations legitimately, so they revert to tactics that can help them achieve this seemingly unattainable goal. The goals themselves are within reach, however, due to their very limited knowledge and insight, they don�t seem to realize that they can actually obtain and achieve their goals through hard work and dedication. Their sense of laziness sets in and finds it easier to ridicule others, put them in a �bad� light, rather than take themselves to a higher level and show themselves in a �good� light. It�s too hard to be smart, it�s too hard to prove you�re right, it�s much easier to prove someone wrong on insignificant rather than to prove your worth. So they take the easy way out.</p>\r\n<p>There aren�t many people in the world that I have met that don�t adhere to this particular philosophy of life, which I�m sure is the same reason why people like myself, are doomed to be on the bottom and answer to numbers of people in your quest for a good life. I and others like me will always loose, no matter what, truly � the good guys loose and the bad guys win at this point. So what�s to keep you hoping for something better? What�s to keep you on the �straight and narrow�? Nothing, your own dedication to proving morons wrong! It takes more than one could ever imagine, but if you remember this: That all idiots are created equal, all idiots are just that, idiots, you can�t expect to use normal conversation and examples to get your point across, you�re going to have to put this into terms so that individuals lacking even a child�s intellect will understand you, or should if they have any hope of being an adult.</p>\r\n<p>I�m not going into details yet, as there are way too many to list. So just keep in mind that even if you mimic the actions of a moronic individual, you�ll still be reprimanded and dealt with in a fashion un-fitting to a sloth. Just remember, in life�s eyes, you are better than everyone else, everyone else is crazy, and you are not alone, however you will still probably fail as the reality is, morons/idiots rule the world you live in, welcome to it.</p>'),
(14, 1, 'bitPimps Goes Live To Rave Reviews', '2003-02-04 00:00:00', '', '<p><br />\r\nLate last night, I forced <a href=\\"http://bitpimps.lixlink.com/\\" target=\\"_blank\\">bitPimps</a> to go live, for better or worse. Since I\\\'m never quite pleased with my own work, I was sitting on the site, dreading yet another re-design, another re-programming, re-architectured, etc. That\\\'s the path I normally take, even on this site here that nobody reads, I purposely use no META information so it\\\'s harder to find by searches, and if revealed, it\\\'s burried. I\\\'m rather glad so far that I did force it to go live, for several reasons actually. First and foremost, I did like the design (just not the programming, architecture and the lack of content - a huge portion of the site). Secondly, I thought the ideas spawned were great, they were funny, entertaining and original. And last but not least, I haven\\\'t pushed out a personal site to the public in over 5 years and I barely use the server all this lives on, though I pay for it.</p>\r\n<p>So, while the site isn\\\'t much yet, it did give me a sense of satisfaction on several levels, and fairly quickly at that - that\\\'s return on investment baby! It\\\'s been less than 24 hours now and the site\\\'s starting to get some good attention and comments, I\\\'m excited to see more results on all aspects of this. I suspect the site will get quite a few visitors, maybe even some early surges of memberships, but if I don\\\'t keep on the site, updating regularly, I\\\'m going to loose those visitors just as fast as they came. At that point the site fades away into the wasteland of garbage on the Internet, I certainly don\\\'t want that to happen, it\\\'s too precious to me at this point. :)</p>'),
(15, 1, 'Another new site goes live', '2003-04-13 00:00:00', '', '<br />\r\nIt\\\'s been a long time since I\\\'ve updated anything, I\\\'ve rather given up on this site and moved to other interests. Though I\\\'ll still post for posterity sakes.<br />\r\nLet\\\'s see where to start, how about with the site\\\'s I\\\'ve recently been involved in making:<br />\r\n- <a href=\\"http://www.iconatg.com/\\" target=\\"_blank\\">IconATG</a><br />\r\n- <a href=\\"http://www.ofallonjc.org/\\" target=\\"_blank\\">O\\\'Fallon Jaycee\\\'s</a><br /><br />\r\nMultiple e-mail campaigns have been released along the times, here\\\'s a few of them:<br />\r\n- <a href=\\"http://training.iconmedialab.com/mailer/09_10_2002/index.html\\" target=\\"_blank\\">IconMedialab\\\'s Requirements Elicitation and Facilitation course</a><br />\r\n- <a href=\\"http://training.iconmedialab.com/mailer/breakfast/index.htm\\" target=\\"_blank\\">Breakfast @ IconMedialab</a><br />\r\n- <a href=\\"http://training.iconmedialab.com/mailer/breakfast_flashline/index.htm\\" target=\\"_blank\\">Flashline Breakfast</a><br />\r\n- <a href=\\"http://training.iconmedialab.com/mailer/mc_casestudy/index.html\\" target=\\"_blank\\">IconMedialab\\\'s Multi-channel Case Study</a><br />\r\n- <a href=\\"http://training.iconmedialab.com/mailer/multi_channel/index.html\\" target=\\"_blank\\">IconMedialab\\\'s Expo Give-away</a><br />\r\n- <a href=\\"http://training.iconmedialab.com/mailer/oosig/index.html\\" target=\\"_blank\\">OOSIG</a><br />\r\n- <a href=\\"http://training.iconmedialab.com/mailer/patrick/index.html\\" target=\\"_blank\\">IconMedialab\\\'s Case Study - The Metropolitan Museum of Art</a><br />\r\n- <a href=\\"http://training.iconmedialab.com/mailer/pirelle_spa/index.html\\" target=\\"_blank\\">IconMedialab\\\'s Case Study - Pirelle Spa</a><br />\r\n- <a href=\\"http://training.iconmedialab.com/mailer/sdexpo/index.html\\" target=\\"_blank\\">IconMedialab\\\'s SD Expo</a><br />\r\n- <a href=\\"http://training.iconmedialab.com/mailer/use_case_abuse/index.html\\" target=\\"_blank\\">IconMedialab\\\'s Treating Use Case Abuse</a><br /><br />\r\nFor IconATG, I added on to existing design, programmed many new functions into both the subsciber functions on the front-end as well as the back-end. I made a sniffer to sniff out pocket pcs, and direct them accordingly to a pocketpc version of the site, fed off the same database as the desktop site. I\\\'ve also managed to work in embedded media streamed with VBR and is also handle through administration screens. The entire site is dynamic, like all the site\\\'s I\\\'ve been doing lately and are database driven. I actually don\\\'t really like the design of the site, but that wasn\\\'t my doing. The site\\\'s been handed back and forth between at least 5 people now and keeps getting worse in my opinion, but that\\\'s not what counts.<br /><br />\r\nI designed and coded HTML, DHTML for a the <a href=\\"http://www.ofallonjc.org/\\" target=\\"_blank\\">O\\\'Fallon Jaycee\\\'s</a> of Missouri. I made quick work of it and just made corporate design, fixed their existing logo, and used color combo\\\'s based on their choosen base color. I also helped decide the actual architecture of the site along with a few administrative functions, another friend of mine did the back-end programming. The site was very well recieved by the chapter, as well as other chapters and a few of their sponsors. One even went as far to immediately inquire about using our services for their project, which could turn out quite fun. We\\\'ll see and hope for the best.');
# --------------------------------------------------------

#
# Table structure for table `gameentries`
#

DROP TABLE IF EXISTS gameentries;
CREATE TABLE gameentries (
  gameEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  gameType text NOT NULL,
  gameTitle text NOT NULL,
  imageName text NOT NULL,
  notes text NOT NULL,
  PRIMARY KEY  (gameEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `gameentries`
#

# --------------------------------------------------------

#
# Table structure for table `metaData`
#

DROP TABLE IF EXISTS metaData;
CREATE TABLE metaData (
  metaID tinyint(4) NOT NULL auto_increment,
  keywords varchar(255) NOT NULL default '',
  description varchar(255) NOT NULL default '',
  PRIMARY KEY  (metaID)
) TYPE=MyISAM;

#
# Dumping data for table `metaData`
#

INSERT INTO metaData (metaID, keywords, description) VALUES (1, 'scott, d, lix, professional, web, development, developer, tutorials, examples, designs, templates, downloads, movies, music, games, funny, dumb, collectables', 'Scott D. Lix - Professional Web Developer --- My personal site, essentially a toolbox of sorts for one and all. Bits and pieces for everyone on everything. Tune in... turn on... and drop out.');
# --------------------------------------------------------

#
# Table structure for table `movieGenre`
#

DROP TABLE IF EXISTS movieGenre;
CREATE TABLE movieGenre (
  id int(11) NOT NULL auto_increment,
  genreType text NOT NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table `movieGenre`
#

INSERT INTO movieGenre (id, genreType) VALUES (1, 'Action'),
(2, 'Adventure'),
(3, 'Animation'),
(4, 'Comedy'),
(5, 'Crime'),
(6, 'Documentary'),
(7, 'Drama'),
(8, 'Family'),
(9, 'Fantasy'),
(10, 'Horror'),
(11, 'Musical'),
(12, 'Mystery'),
(13, 'Romance'),
(14, 'Sci-Fi'),
(15, 'Thriller'),
(16, 'War'),
(17, 'Western');
# --------------------------------------------------------

#
# Table structure for table `movieLookup`
#

DROP TABLE IF EXISTS movieLookup;
CREATE TABLE movieLookup (
  Mid int(11) NOT NULL default '0',
  Gid int(11) NOT NULL default '0',
  PRIMARY KEY  (Mid,Gid)
) TYPE=MyISAM;

#
# Dumping data for table `movieLookup`
#

# --------------------------------------------------------

#
# Table structure for table `movieentries`
#

DROP TABLE IF EXISTS movieentries;
CREATE TABLE movieentries (
  movieEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  genre int(11) NOT NULL default '0',
  movieType int(11) NOT NULL default '0',
  releaseDate date NOT NULL default '0000-00-00',
  rating text NOT NULL,
  movieTitle text NOT NULL,
  imageName text NOT NULL,
  bodyCopy text NOT NULL,
  PRIMARY KEY  (movieEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `movieentries`
#

# --------------------------------------------------------

#
# Table structure for table `movieentriesaction`
#

DROP TABLE IF EXISTS movieentriesaction;
CREATE TABLE movieentriesaction (
  movieEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  genre text NOT NULL,
  movieType text NOT NULL,
  releaseDate text NOT NULL,
  rating text NOT NULL,
  movieTitle text NOT NULL,
  imageName text NOT NULL,
  bodyCopy text NOT NULL,
  PRIMARY KEY  (movieEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `movieentriesaction`
#

INSERT INTO movieentriesaction (movieEntryId, publishFlag, genre, movieType, releaseDate, rating, movieTitle, imageName, bodyCopy) VALUES (1, 1, 'Action - Adventure', 'DVD', '2001', 'PG-13', 'The Fast And The Furious', 'fastAndfurious.jpg', '<p><strong>Movie Summary:</strong><br />\r\nThey\\\'ve got the adrenaline rush and the mean machines, but most of all, they\\\'ve got the extreme need for speed.</p>\r\n<p>On the turbo-charged streets of Los Angeles, every night is a championship race. With nitro-boosted fury, Dominic Toretto [Vin Diesel], rules the road turning all his challengers into dust. He and his rival, Johnny Tran [Rick Yune] are the boldest, the baddest and the best. But now, there\\\'s a new rage on the road. They know he\\\'s tough, they now he\\\'s fast, but what they don\\\'t know is that he\\\'s a speed demon detective [Paul Walker] with enough drive and determination to come out the winner.</p>\r\n<p>With intense full-throttle action, awesome high-speed stunts, and full-on pedal to the metal intensity, this fast and furious assault puts you in the driver\\\'s seat and dares you to exceed all limits.</p>'),
(2, 1, 'Action - Adventure', 'DVD', '2002', 'R', 'Spy Game', 'spyGame.jpg', '<p><strong>Movie Summary:</strong><br />\r\nSuperstar Brad Pitt teams with Academy Award�-winner* Robert Redford in this pulse-pounding action thrill ride.</p>\r\n<p>When a top-secret, unauthorized mission goes bad, CIA agent Tom Bishop (Pitt) is captured � and sentenced to die. With just 24 hours to get him out alive, Bishop\\\'s boss Nathan Muir (Redford) must battle enemies abroad and the system inside the CIA to save his friend. Now, the clock is ticking and the race is on... as the deadliest game of all explodes into the spectacular, adrenaline-fueled thriller that <em>ABC Radio </em> says \\"Sizzles with suspense!\\"</p>'),
(3, 1, 'Action - Drama', 'DVD', '2002', 'PG-13', 'The Sum of All Fears', 'sumOfAllFears.jpg', '<p><strong>Movie Summary:</strong><br />\r\n<strong>Ben Affleck</strong> is ready for action, commanding the role of CIA agent Jack Ryan in this thrilling adventure based on the Tom Clancy bestseller.</p>\r\n<p>America\\\'s Cold War fears are rekindled after the President of Russia dies and is succeeded by a man with a cryptic past. But East-West tensions erupt when the CIA suspects that renegade Russian scientists are developing more nuclear weapons. Mobilized into action by CIA Director William Cabo (<strong>Morgan Freeman</strong>), Jack Ryan (Affleck) follows a danger-ridden trail to a shocking conclusion: terrorists plan to provoke a war between the U.S. and Russia - by detonating a nuclear bomb at a championship football game!</p>');
# --------------------------------------------------------

#
# Table structure for table `movieentriescomedy`
#

DROP TABLE IF EXISTS movieentriescomedy;
CREATE TABLE movieentriescomedy (
  movieEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  genre text NOT NULL,
  movieType text NOT NULL,
  releaseDate text NOT NULL,
  rating text NOT NULL,
  movieTitle text NOT NULL,
  imageName text NOT NULL,
  bodyCopy text NOT NULL,
  PRIMARY KEY  (movieEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `movieentriescomedy`
#

INSERT INTO movieentriescomedy (movieEntryId, publishFlag, genre, movieType, releaseDate, rating, movieTitle, imageName, bodyCopy) VALUES (1, 1, 'Comedy', 'DVD', '2000', 'R', 'Jay and Silent Bob Strike Back', 'jayBobStrike.jpg', '<p><strong>Movie Summary:</strong><br />\r\n<strong>P</strong>acked with stars including Ben Affleck (<em>Good Will Hunting</em>), Chris Rock (<em>Nurse Betty</em>), Shannon Elizabeth (<em>American Pie</em>), Jason Lee (<em>Almost Famous</em>) and more, this wildly irreverent comedy is actor/director Kevin Smith\\\'s hilarious finale to the adventures of Jay and Silent Bob that began in <em>Clerks</em> and ran through <em>Mallrats</em>, <em>Chasing Amy</em> and <em>Dogma</em>! When best buddies Jay (Jason Mewes) and Silent Bob (Smith) discover that a major motion picture is being based on their likenesses, they head for Hollywood to claim the big movie money they deserve. But when the dopey duo learn that they\\\'ve been cut out of the cash, they set out to sabotage the flick at all costs! Featuring a host of celebrity cameos set to a hot hit soundtrack, Jay and Silent Bob\\\'s raucous cross-country road trip is a crash course in the rules of the road with a nonstop assortment of outrageous characters that will have you laughing out loud!</p>'),
(2, 1, 'Comedy', 'DVD', '2002', 'PG-13', 'Orange County', 'orangeCounty.jpg', '<p><strong>Movie Summary:</strong><br />\r\nRising young stars Colin Hanks and Schuyler Fisk head up an outstanding cast including Jack Black (<em>Shallow Hal</em>), Catherine O\\\'Hara (<em>Home Alone</em>), John Lithgow (<em>3rd Rock From the Sun</em>), Harold Ramis and Lily Tomlin in this outrageous coming-of-age comedy.</p>\r\n<p>Shaun Brumder (Hanks) is content to be a bright, talented, but unfocused Southern California surf slacker - until the day he discovers a novel by acclaimed author Martin Skinner. Inspired, he suddenly realizes his life\\\'s ambition: to leave behind mind-numbing Orange County and study creative writing with Skinner at Stanford University. But after being denied enrollment due to an admissions error, Shaun is forced to seek help not only from his girlfriend Ashley (Fisk) but also his hopelessly dysfunctional parents (O\\\'Hara & Lithgow), stoner brother Lance (Black), and a host of hilarious circumstances to make his dream of escaping his hometown nightmare a reality.</p>'),
(3, 1, 'Comedy - Crime', 'DVD', '2002', 'R', 'Death to Smoochy', 'deathToSmoochy.jpg', '<p><strong>Movie Summary:</strong><br />\r\nKids love him. TV execs adore him. Sheesh, it\\\'s enough to make out-of-work kiddie-show host Rainbow Randolph puke purple. Ever since that plush, fuchsia-hued, platitude-spouting Smoochy the Rhino started Jiggy Ziggy-dancing in Randolph\\\'s time slot, he has just one mad goal: turn the rhino into a dead duck.</p>\r\n<p>Danny DeVito takes the rhino by the horn to direct and co-star in this gleefully twisted skewering of children\\\'s TV. Robin Williams, his famed wit set at warp, plays ranting Randolph. Edward Norton is the high-minded goodnik whose righteous-rhino creation becomes a sensation, and Catherine Keener protrays a jaded exec who likes kid-show hosts in, let\\\'s say, a grown-up way. Say nite-nite, rhino!</p>'),
(5, 1, 'Comedy - Romance', 'DVD', '2001', 'PG-13', 'Shallow Hal', 'shallowHal.jpg', '<p><strong>Movie Summary:</strong><br />\r\nDirected by the guys who brought you <em>There\\\'s Something About Mary</em> and <em>Me, Myself &amp; Irene</em>, this heavyweight hit comedy is \\"heartwarming and hilarious &#8212; an unbeatable comination!\\"</p>\r\n<p>Jack Black is <em>Shallow Hal</em>, a superficial skirt chaser who, after a mind-altering experience with a self-help guru, doesn\\\'t realize that his gorgeous girlfriend (Gwyneth Paltrow) is actually a 300-pound not-so-hottie. Meanwhile, Hal\\\'s playboy pal Mauricio (Jason Alexander) is determined to break the spell before someone gets...squashed! Packed with loads of laughs and non stop fun, it\\\'s the <strong>biggest</strong> love story ever told!</p>'),
(6, 1, 'Comedy - Animation', 'DVD', '2001', 'PG', 'Osmosis Jones', 'osmosisJones.jpg', '<p><strong>Movie Summary:</strong><br />\r\nHe\\\'s a new strain of hero. He\\\'s one cell of a guy. He\\\'s Osmosis Jones! This infectiously funny live-action / animated caper kicks off in the \\"real\\" world as Frank (Bill Murray) ingests a villainous virus named Thrax (Laurence Fishburne). Now, deep inside the spectacular, animated inner realm of the City of Frank, it\\\'s up to a maverick white blood cell cop named Osmosis Jones (Chris Rock) and his reluctant sidekick Drix (David Hyde Pierce) to thwart Thrax\\\'s epidemic of evil!</p>'),
(7, 1, 'Comedy - Crime', 'DVD', '2001', 'PG-13', 'Ocean\\\'s Eleven', 'oceansEleven.jpg', '<p><strong>Movie Summary:</strong><br />\r\nThe plan is set. The rules are clear. If all goes right for Danny Ocean\\\'s grifters, the payoff is $150 million. Divided by 11. You do the math.</p>\r\n<p>The skill of Academy Award&#0174; winning director Steven Soderbergh combines with enough starpower to light up the Las Vegas strip in this classy caper. George Clooney plays Danny, defying the odds in a split-second heist of three Vegas casinos &#8212; all owned by a magnate (Andy Garcia) who is dating Danny\\\'s ex-wife (Julia Roberts). A fixer (Brad Pitt), a pickpocket (Matt Damon), a blackjack dealer (Bernie Mac), a flimflammer (Carl Reiner) and others in well-defined roles are with Danny. Are you in or out?</p>'),
(8, 1, 'Comedy', 'DVD', '2001', 'PG-13', 'Zoolander', 'zoolander.jpg', '<p><strong>Movie Summary:</strong><br />\r\nClear the runway for <strong>Derek Zoolander</strong> (Ben Stiller), VH1\\\'s <strong>three-time</strong> male <strong>model of the year</strong>. His face falls when hippie-chic <strong>Hansel</strong> (Owen Wilson) scooters in to <strong>steal this year\\\'s award</strong>.</p>\r\n<p>The <strong>evil fashion</strong> guru <strong>Mugatu</strong> (Will Ferrell) seizes the opportunity to <strong>turn Derek</strong> into a <strong>killing machine</strong>. It\\\'s a well-designed conspiracy and only with the <strong>help of Hansel</strong> and a few well-chosen accessories like <strong>Matilda</strong> (Christine Taylor) can Derek <strong>make</strong> the <strong>world safe</strong> for <strong>male models</strong> everywhere.</p>'),
(9, 1, 'Comedy', 'DVD', '1996', 'N/A', 'Drawing Flies', 'drawingFlies.jpg', '<p><strong>Movie Summary:</strong><br />\r\n<strong>J</strong>ason Lee (<em>Vanilla Sky</em>) headlines an all-star cast, including Jason Mewes (<em>Jay and Silent Bob Strike Back</em>), Renee Humphrey (<em>Mallrats</em>) and Carmen Lee (<em>Chasing Amy</em>) in <strong>Drawing Flies</strong>, a hilarious comedy about insanity!</p>\r\n<p>Five twenty-something slackers are living the good life. All play and no work suits these kids just fine as they live comfortably off of their government welfare checks. But when their lives are turned upside down after the system cuts them off from their \\"easy money\\", it\\\'s out of the city and off to the country as they embark on a camping trip deep in the wilderness. As they head further into the woods, their fearless leader Donner (Lee) heads further from sanity, when what was thought to be a camping trip is actually a fatuous search for the legendary \\"Bigfoot\\" monster! Now they are lost, scared, at odds with one another as they soon realize that if the woods don\\\'t kill them, they just might do it themselves.</p>\r\n<p>Known to many as the \\"lost View Askew film\\", <strong>Drawing Flies</strong> is the brainchild of Producer, Writer, Directors Matthew Gissing and Malcolm Ingram (<em>Tail Lights Fade</em>) from Executive Producers Scott Mosier and Kevin Smith (<em>Dogma, Jay and Silent Bob Strike Back</em>) and features cameo appearances from some of your favorite View Askew regulars.</p>');
# --------------------------------------------------------

#
# Table structure for table `movieentriesdrama`
#

DROP TABLE IF EXISTS movieentriesdrama;
CREATE TABLE movieentriesdrama (
  movieEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  genre text NOT NULL,
  movieType text NOT NULL,
  releaseDate text NOT NULL,
  rating text NOT NULL,
  movieTitle text NOT NULL,
  imageName text NOT NULL,
  bodyCopy text NOT NULL,
  PRIMARY KEY  (movieEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `movieentriesdrama`
#

INSERT INTO movieentriesdrama (movieEntryId, publishFlag, genre, movieType, releaseDate, rating, movieTitle, imageName, bodyCopy) VALUES (1, 1, 'Drama - Romance', 'DVD', '2002', 'R', 'Vanilla Sky', 'vanillaSky.jpg', '<p><strong>Movie Summary:</strong><br />\r\nTom Cruise delivers one of his finest performances in this unforgettably powerful film that reunites him with Cameron Crowe, the director of <em>Jerry Maguire</em>.</p>\r\n<p>Publishing tycoon David Aames (Cruise) believes he may have found the missing piece to hiss incomplete life when he meets the woman of his dreams (Pen�lope Cruz). But a fateful encounter with a jealous lover (Cameron Diaz) sends David\\\'s world out of control, rocketing him on a roller-coaster ride of romance, sex, suspicion and dreams... to a shocking, final awakening you will never forget.</p>'),
(2, 1, 'Drama - Sci-Fi', 'DVD', '2001', 'PG-13', 'A.I. - Artificial Intelligence', 'ai.jpg', '<p><strong>Movie Summary:</strong><br />\r\nDirector Steven Spielberg\\\'s <em>A.I.</em> propels you into a future of astounding technology and adventure beyond the human imagination in an extraordinary film the <em>New York Observer</em> hails as a \\"masterpiece\\" and <em>Rolling Stone</em> applauds as \\"unmistakably the work of a real filmmaker.\\" In a future world of runaway global warming and awe-inspiring scientific advances, humans share every aspect of their lives with sophisticated companion robots called Mechas. But when an advanced prototype robot child named David (Haley Joel Osment) is programmed to show unconditional love, his human family isn\\\'t prepared for the consequences. Suddenly, David is on his own in a strange and dangerous world. Befriended by a streetwise Mecha (Jude Law), David embarks on a spectacular quest to discover the startling secret of his own identity. Celebrated as a film \\"filled with visual wonders and astonishing special effects...\\" (Roger Ebert, <em>Ebert & Roeper</em>), <em>A.I. Artificial Intelligence</em> is a visionary motion picture triumph!</p>'),
(3, 1, 'Drama - Thriller', 'DVD', '2002', 'R', 'Changing Lanes', 'changingLanes.jpg', '<p><strong>Movie Summary:</strong><br />\r\nModern society draws lines between right and wrong, good and evil, rage and redemption. A moment of self-absorption and a spark of anger will cause two men to cross them. As the battle of wills escalates, both lives are changed forever. Samuel L. Jackson and Ben Affleck star in a provocative and gripping drama that exposes the best and worst in all of us.</p>'),
(4, 1, 'Drama', 'DVD', '2001', 'R', 'Rock Star', 'rockStar.jpg', '<p><strong>Movie Summary:</strong><br />\r\nBy day Chris Cole repairs photocopiers. By night he takes the stage as frontman for a tribute band emulating Steel Dragon, the world\\\'s hottest heavy-metal band. Then, suddenly, opportunity rocks: Chris is tapped to become Steel Dragon\\\'s new lead singer. Just like that, he goes from small-town nobody to megastar. Just like that, he and his manager / girlfriend Emily enter a world crazier than either imagined.</p>\r\n<p>Mark Wahlberg and Jennifer Aniston headline and Stephen Herek (<em>Bill and Ted\\\'s Excellent Adventure</em>) directs this knowing, chord-crunching, hair-whipping look at 80\\\'s arena rock and the price of fame. Filled with style, strut and feel of an era, <em>Rock Star</em> gets it right. Long may it shine.</p>'),
(5, 1, 'Drama - Crime - Thriller', 'DVD', '2001', 'R', 'The Score', 'theScore.jpg', '<p><strong>Movie Summary:</strong><br />\r\nThree generations of acclaimed actors team up the <em>The Score</em>, an intriguing crime thriller that marks the first time that legendary Oscar� winners Robert De Niro and Marlon Brando have shared the screen. Also starring Oscar� nominee Edward Norton. <em>The Score</em> wowed critics and audiences alike.</p>\r\n<p>When expert safecracker Nick Wells (De Niro) decides it might be time to settle down with his girlfriend Diane (Oscar� nominee Angela Bassett) and stick to his legitimate business, running a jazz nightclub in Montreal, his friend and partner Max (Brando) has other plans. Heavily in debt to a crime boss, Max needs Nick to pull one last heist: help novice thief Jack Teller (Norton) steal a scepter worth $30 million from the House of Customs. Tempted by the $6 million payday, Nick reluctantly agrees to do the job. But what starts out as a safe bet turns into a high risk gamble when a clash of egos threatens to bring them all down.</p>\r\n<p>Featuring performances by jazz greats Cassandra Wilson and Mose Allison, <em>The Score</em> is one of the smartest, most entertaining crime capers ever filmed, with surprises at every turn.</p>'),
(6, 1, 'Drama - Crime - Thriller', 'DVD', '2001', 'R', 'Training Day', 'trainingDay.jpg', '<p><strong>Movie Summary:</strong><br />\r\nRookie cop Jake Hoyt wants to stop crooks, not become one. But staying on the right side of the line that separates cop from criminal will be more challenging than anything he\\\'s faced. Because Hoyt\\\'s senior partner for the next 24 hours is Alonzo Harris, an undercover narc meaner than any of L.A.\\\'s mean streets.</p>\r\n<p>In a powerful departure from his frequent good-guy roles, Denzel Washington plays Harris, the twisted but charismatic detective who both attracts and repels as he becomes the kind of thug he\\\'s supposed to collar. Ethan Hawke plays unseasoned recruit Hoyt. And Antoine Fuqua (<em>The Replacement Killers, Bait</em>) directs, guiding a cast that includes music stars Dr. Dre, Macy Gray and Snoop Dogg. <em>Training Day</em>. It\\\'s a day of reckoning.</p>');
# --------------------------------------------------------

#
# Table structure for table `movieentrieshorror`
#

DROP TABLE IF EXISTS movieentrieshorror;
CREATE TABLE movieentrieshorror (
  movieEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  genre text NOT NULL,
  movieType text NOT NULL,
  releaseDate text NOT NULL,
  rating text NOT NULL,
  movieTitle text NOT NULL,
  imageName text NOT NULL,
  bodyCopy text NOT NULL,
  PRIMARY KEY  (movieEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `movieentrieshorror`
#

INSERT INTO movieentrieshorror (movieEntryId, publishFlag, genre, movieType, releaseDate, rating, movieTitle, imageName, bodyCopy) VALUES (1, 1, 'Horror - Thriller', 'DVD', '1986', 'R', 'The Hitcher', 'theHitcher.jpg', '<p><strong>Movie Summary:</strong><br />\r\nWhen Jim Halsey (C. Thomas Howell) stops to pick up a hitcher one rainy night, he is soon dying to turn back time. The man (Rutger Hauer) puts a knife to Jim\\\'s throat as he tells him to pull past a stranded car on the side of the road. Its occupants have already been brutally slaughtered by the ominous stranger.</p>\r\n<p>Now a bloody game of cat-and-mouse is about to be played out on this desolate stretch of highway, and every car that passes, and every poor soul who rides that road, are going to take part whether they want to or not.</p>\r\n<p><strong>Terror Alert:</strong><br />\r\nThe Hitcher is a stretch for actress <strong>Jennifer Jason Leigh</strong>, especially when she\\\'s tied between two vehicles heading in opposite directions!</p>');
# --------------------------------------------------------

#
# Table structure for table `musicentries`
#

DROP TABLE IF EXISTS musicentries;
CREATE TABLE musicentries (
  musicEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  genre text NOT NULL,
  musicType text NOT NULL,
  artist text NOT NULL,
  releaseDate date NOT NULL default '0000-00-00',
  album text NOT NULL,
  imageName text NOT NULL,
  tracks text NOT NULL,
  PRIMARY KEY  (musicEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `musicentries`
#

INSERT INTO musicentries (musicEntryId, publishFlag, genre, musicType, artist, releaseDate, album, imageName, tracks) VALUES (2, 1, '80\\\'s', 'MP3', 'Adam Ant', '1969-12-31', 'Unknown', 'none.jpg', '<ol>\r\n<li>Desperate But Not Serious</li>\r\n<li>Goody Two Shoes</li>\r\n<li>Stand and Deliver</li>\r\n</ol>'),
(3, 1, '80\\\'s', 'MP3', 'Billy Joel', '1969-12-31', 'Greatest Hits Volume I (1973 - 1977)', 'none.jpg', '<ol>\r\n  <li>Piano Man</li>\r\n  <li>Captain Jack</li>\r\n  <li>The Entertainer</li>\r\n  <li>Say Goodbye to Hollywood</li>\r\n  <li>New York State of Mind</li>\r\n  <li>The Stranger</li>\r\n  <li>Scenes from an Italian Restaurant</li>\r\n  <li>Just the Way You Are</li>\r\n  <li>Movin\\\' Out (Anthony\\\'s Song)</li>\r\n  <li>Only the Good Die Young</li>\r\n  <li>She\\\'s Always a Woman to Me</li>\r\n</ol>'),
(4, 1, '80\\\'s', 'MP3', 'David Bowie', '1969-12-31', 'Outside', 'none.jpg', '<ol>\r\n  <li>Leon Takes Us Outside</li>\r\n  <li>A Small Plot of Land</li>\r\n  <li>The Motel</li>\r\n  <li>I Have Not Been To Oxford</li>\r\n  <li>No Control</li>\r\n  <li>Segue - Algeria Touchshriek</li>\r\n  <li>The Voyeur of Utter Destruction</li>\r\n  <li>Segue - Ramona A Stone I Am With</li>\r\n  <li>We Prick You</li>\r\n  <li>Segue - Nathan Adler</li>\r\n  <li>Man Who Sold the World (Live)</li>\r\n</ol>'),
(5, 1, '80\\\'s', 'MP3', 'David Bowie', '1969-12-31', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Space Oddity</li>\r\n  <li>Under Pressure (With Queen)</li>\r\n  <li>Golden Years</li>\r\n</ol>'),
(6, 1, '80\\\'s', 'MP3', 'Duran Duran', '1969-12-31', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Come Undone</li>\r\n  <li>Girls On Film</li>\r\n  <li>Hungry Like a Wolf</li>\r\n  <li>Reflex</li>\r\n  <li>Rio</li>\r\n  <li>Save a Prayer</li>\r\n  <li>A View To a Kill</li>\r\n</ol>'),
(7, 1, '80\\\'s', 'MP3', 'Madonna', '1969-12-31', 'Bedtime Stories', 'none.jpg', '<ol>\r\n  <li>Survival</li>\r\n  <li>Secret</li>\r\n  <li>I\\\'d Rather Be Your Lover</li>\r\n  <li>Don\\\'t Stop</li>\r\n  <li>Inside of Me</li>\r\n  <li>Human Nature</li>\r\n  <li>Forbidden Love</li>\r\n  <li>Love Tried To Welcome Me</li>\r\n  <li>Sanctuary</li>\r\n  <li>Bedtime Story</li>\r\n  <li>Take a Bow</li>\r\n</ol>'),
(8, 1, '80\\\'s', 'MP3', 'Madonna', '1969-12-31', 'Ray of Light', 'none.jpg', '<ol>\r\n  <li>Drowned World - Substitute for Love</li>\r\n  <li>Swim</li>\r\n  <li>Ray of Light</li>\r\n  <li>Candy Perfume Girl</li>\r\n  <li>Skin</li>\r\n  <li>Nothing Really Matters</li>\r\n  <li>Sky Fits Heaven</li>\r\n  <li>Shanti - Ashtangi</li>\r\n  <li>Frozen</li>\r\n  <li>The Power of Goodbye</li>\r\n  <li>To Have and Not To Hold</li>\r\n  <li>Little Star</li>\r\n  <li>Mer Girl</li>\r\n</ol>'),
(9, 1, '80\\\'s', 'MP3', 'Madonna', '1969-12-31', 'Something To Remember', 'none.jpg', '<ol>\r\n  <li>I Want You</li>\r\n  <li>I\\\'ll Remember</li>\r\n  <li>Take a Bow</li>\r\n  <li>You\\\'ll See</li>\r\n  <li>Crazy For You</li>\r\n  <li>This Used To Be My Playground</li>\r\n  <li>Live To Tell</li>\r\n  <li>Love Don\\\'t Live Here Anymore</li>\r\n  <li>Something To Remember</li>\r\n  <li>Forbidden Love</li>\r\n  <li>One More Chance</li>\r\n  <li>Rain</li>\r\n  <li>Oh Father</li>\r\n  <li>I Want You (Orchestral)</li>\r\n</ol>'),
(10, 1, '80\\\'s', 'MP3', 'Madonna', '1969-12-31', 'The Immaculate Collection', 'none.jpg', '<ol>\r\n  <li>Holiday</li>\r\n  <li>Lucky Star</li>\r\n  <li>Borderline</li>\r\n  <li>Like a Virgin</li>\r\n  <li>Material Girl</li>\r\n  <li>Crazy for You</li>\r\n  <li>Into the Groove</li>\r\n  <li>Live to Tell</li>\r\n  <li>Papa Don\\\'t Preach</li>\r\n  <li>Open Your Heart</li>\r\n  <li>La Isla Bonita</li>\r\n  <li>Like a Prayer</li>\r\n  <li>Express Yourself</li>\r\n  <li>Cherish</li>\r\n  <li>Vogue</li>\r\n  <li>Justify My Love</li>\r\n  <li>Rescue Me</li>\r\n</ol>'),
(11, 1, '80\\\'s', 'MP3', 'Madonna', '1969-12-31', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Express Yourself</li>\r\n  <li>Justify My Love</li>\r\n</ol>'),
(12, 1, '80\\\'s', 'MP3', 'Red Hot Chili Peppers', '1969-12-31', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Friends</li>\r\n  <li>Give It Away</li>\r\n  <li>Soul To Squeeze</li>\r\n</ol>'),
(13, 1, 'Funk', 'MP3', 'Colonel Les Claypool\\\'s Fearless Flying Frog Brigade', '2002-05-05', 'Live Frogs Set 1', 'none.jpg', '<ol>\r\n  <li>Thela Hun Ginjeet</li>\r\n  <li>Riddles Are Abound Tonight</li>\r\n  <li>Hendershot</li>\r\n  <li>Shattering Song</li>\r\n  <li>Running The Gauntlet</li>\r\n  <li>Girls For Single Men</li>\r\n  <li>Shine On You Crazy Diamond (Jack Irons version)</li>\r\n</ol>'),
(14, 1, 'Funk', 'MP3', 'Colonel Les Claypool\\\'s Fearless Flying Frog Brigade', '2002-05-05', 'Live Frogs Set 2', 'none.jpg', '<ol>\r\n  <li>Pigs On The Wing 1</li>\r\n  <li>Dogs</li>\r\n  <li>Pigs (Three Different Ones)</li>\r\n  <li>Sheep</li>\r\n  <li>Pigs On The Wing 2</li>\r\n</ol>'),
(15, 1, 'Funk', 'MP3', 'Les Claypool and the Holy Mackerel', '2002-05-05', 'Highball with the Devil', 'none.jpg', '<ol>\r\n  <li>Running the Gauntlet</li>\r\n  <li>Holy Mackerel</li>\r\n  <li>Highball with the Devil</li>\r\n  <li>Hendershot</li>\r\n  <li>Calling Kyle</li>\r\n  <li>Rancor</li>\r\n  <li>Cohibas Esplenditos</li>\r\n  <li>Delicate Tendrils</li>\r\n  <li>The Awakening</li>\r\n  <li>Precipitation</li>\r\n  <li>George E. Porge</li>\r\n  <li>El Sobrante Fortnight</li>\r\n  <li>Granny\\\'s Little Yard Gnome</li>\r\n  <li>Me and Chuck</li>\r\n  <li>Carolina Rig</li>\r\n</ol>');
# --------------------------------------------------------

#
# Table structure for table `musicentriesclassicrock`
#

DROP TABLE IF EXISTS musicentriesclassicrock;
CREATE TABLE musicentriesclassicrock (
  musicEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  musicType text NOT NULL,
  artist text NOT NULL,
  album text NOT NULL,
  imageName text NOT NULL,
  tracks text NOT NULL,
  PRIMARY KEY  (musicEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `musicentriesclassicrock`
#

INSERT INTO musicentriesclassicrock (musicEntryId, publishFlag, musicType, artist, album, imageName, tracks) VALUES (1, 1, 'MP3', 'Genesis', 'The Lamb Lies Down On Broadway', 'none.jpg', '<ul>\r\n  <li>Disc 1\r\n    <ol>\r\n      <li>The Lamb Lies Down On Broadway</li>\r\n      <li>Fly On a Windshield</li>\r\n      <li>Broadway Melody of 1974</li>\r\n      <li>Cukoo Cucoon</li>\r\n      <li>In the Cage</li>\r\n      <li>The Grand Parade of Lifeless Packaging</li>\r\n      <li>Back In N.Y.C.</li>\r\n      <li>Hairless Heart</li>\r\n      <li>Counting Out Time</li>\r\n      <li>The Carpet Crawlers</li>\r\n      <li>The Chamber of 32 Doors</li>\r\n    </ol>\r\n  </li>\r\n  <li>Disc 2\r\n    <ol>\r\n      <li>Lilywhite Lilith</li>\r\n      <li>The Waiting Room</li>\r\n      <li>Anyway</li>\r\n      <li>The Supernatural Anaesthetist</li>\r\n      <li>The Lamia</li>\r\n      <li>Silent Sorrow In Empty Boats</li>\r\n      <li>The Colony of Slippermen</li>\r\n      <li>Ravine</li>\r\n      <li>The Light Dies Down On Broadway</li>\r\n      <li>Riding the Scree</li>\r\n      <li>In the Rapids</li>\r\n      <li>It</li>\r\n    </ol>\r\n  </li>\r\n</ul>'),
(2, 1, 'MP3', 'Alice Cooper', 'Goes To Hell', 'none.jpg', '<ol>\r\n  <li>Go To Hell</li>\r\n  <li>You Gotta Dance</li>\r\n  <li>I\\\'m The Coolest</li>\r\n  <li>I\\\'m Always Chasing Rainbows</li>\r\n  <li>Going Home</li>\r\n</ol>'),
(3, 1, 'MP3', 'Billy Joel', 'Greatest Hits Volume I 1973 - 1977', 'none.jpg', '<ol>\r\n  <li>Piano Man</li>\r\n  <li>Captain Jack</li>\r\n  <li>The Entertainer</li>\r\n  <li>Say Goodbye to Hollywood</li>\r\n  <li>New York State of Mind</li>\r\n  <li>The Stranger</li>\r\n  <li>Scenes from an Italian Restaurant</li>\r\n  <li>Just The Way You Are</li>\r\n  <li>Movin\\\' Out (Anthony\\\'s Song)</li>\r\n  <li>Only the Good Die Young</li>\r\n  <li>She\\\'s Always a Woman to Me</li>\r\n</ol>'),
(4, 1, 'MP3 - CD', 'Black Sabbath', 'We Sold Our Soul For Rock \\\'N\\\' Roll', 'none.jpg', '<ol>\r\n  <li>Black Sabbath</li>\r\n  <li>The Wizard</li>\r\n  <li>Paranoid</li>\r\n  <li>War Pigs</li>\r\n  <li>Iron Man</li>\r\n  <li>Tomorrow\\\'s Dream</li>\r\n  <li>Fairies Wear Boots</li>\r\n  <li>Changes</li>\r\n  <li>Sweet Leaf</li>\r\n  <li>Children of the Grave</li>\r\n  <li>Sabbath, Bloody Sabbath</li>\r\n  <li>Am I Going Insane (radio)</li>\r\n  <li>Snowblind</li>\r\n  <li>N.I.B.</li>\r\n</ol>'),
(5, 1, 'MP3', 'Crosby, Stills, Nash, and Young', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Find the Cost of Freedom</li>\r\n  <li>Right Between the Eyes</li>\r\n  <li>Teach Your Children</li>\r\n  <li>Woodstock</li>\r\n  <li>Chicago</li>\r\n  <li>Cinnamon Girl / Down By The River</li>\r\n  <li>Marakesh Express</li>\r\n  <li>Ohio</li>\r\n  <li>Wooden Ships</li>\r\n  <li>Carry On</li>\r\n  <li>Country Girl</li>\r\n  <li>Southern Cross</li>\r\n  <li>Love the One You\\\'re With</li>\r\n  <li>Our House</li>\r\n  <li>Suite Judy Blue Eyes</li>\r\n</ol>'),
(6, 1, 'MP3', 'Genesis', 'Archive', 'none.jpg', '<ul>\r\n  <li>Disc 1\r\n    <ol>\r\n      <li>The Lamb Lies Down On Broadway</li>\r\n      <li>Fly On A Windshield</li>\r\n      <li>Broadway Melody of 1974</li>\r\n      <li>Cuckoo Cocoon</li>\r\n      <li>In the Cage</li>\r\n      <li>The Grand Parade of Lifeless Packaging</li>\r\n      <li>Back In N.Y.C.</li>\r\n      <li>Hairless Heart</li>\r\n      <li>Counting Out Time</li>\r\n      <li>Carpet Crawlers</li>\r\n      <li>The Chamber of 32 Doors</li>\r\n    </ol>\r\n  </li>\r\n  <li>Disc 2\r\n    <ol>\r\n      <li>Lilywhite Lilith</li>\r\n      <li>The Waiting Room</li>\r\n      <li>Anyway</li>\r\n      <li>Here Comes The Supernatural Anaesthetist</li>\r\n      <li>The Lamia</li>\r\n      <li>Silent Sorrow In Empty Boats</li>\r\n      <li>The Colony of Slippermen</li>\r\n      <li>Ravine</li>\r\n      <li>The Light Dies Down On Broadway</li>\r\n      <li>Riding the Scree</li>\r\n      <li>In the Rapids</li>\r\n      <li>It</li>\r\n    </ol>\r\n  </li>\r\n  <li>Disc 3\r\n    <ol>\r\n      <li>Dancing with the Moon</li>\r\n      <li>Firth of Fifth</li>\r\n      <li>More Fool Me</li>\r\n      <li>Supper\\\'s Ready</li>\r\n      <li>I Know What I Like</li>\r\n      <li>Stagnation</li>\r\n      <li>Twilight Alehouse</li>\r\n      <li>Happy the Man</li>\r\n      <li>Watcher of the Skies</li>\r\n    </ol>\r\n  </li>\r\n  <li>Disc 4\r\n    <ol>\r\n      <li>In the Wilderness</li>\r\n      <li>Shepherd</li>\r\n      <li>Pacidy</li>\r\n      <li>Let Us Now Make Love</li>\r\n      <li>Going Out To Get You</li>\r\n      <li>Dusk</li>\r\n      <li>Build Me a Mountain</li>\r\n      <li>Image Blown Out</li>\r\n      <li>One Day</li>\r\n      <li>Where the Sour Turns to Sweet</li>\r\n      <li>In the Beginning</li>\r\n      <li>The Magic of Time</li>\r\n      <li>Hey!</li>\r\n      <li>Hidden In the World of Dawn</li>\r\n      <li>Sea Bee</li>\r\n      <li>The Mystery of the Flannan Isle Lighthouse</li>\r\n      <li>Hair On the Arms and Legs</li>\r\n      <li>She Is Beautiful</li>\r\n      <li>Try a Little Sadness</li>\r\n      <li>Patricia</li>\r\n    </ol>\r\n  </li>\r\n</ul>'),
(7, 1, 'MP3', 'Genesis', 'Nursery Crymes', 'none.jpg', '<ol>\r\n  <li>The Musical Box</li>\r\n  <li>For Absent Friends</li>\r\n  <li>The Return of the Giant Hogweed</li>\r\n  <li>Seven Stones</li>\r\n  <li>Harold the Barrel</li>\r\n  <li>Harlequin</li>\r\n  <li>The Fountain of Salmacis</li>\r\n</ol>'),
(8, 1, 'MP3', 'Genesis', 'Foxtrot', 'none.jpg', '<ol>\r\n  <li>Get \\\'Em Out by Friday</li>\r\n  <li>Time Table</li>\r\n  <li>Watcher of the Skies</li>\r\n  <li>Can Utility and the Coastline</li>\r\n  <li>Horizon\\\'s</li>\r\n  <li>Supper\\\'s Ready</li>\r\n</ol>'),
(9, 1, 'MP3', 'Genesis', 'Selling England by the Pound', 'none.jpg', '<ol>\r\n  <li>Dancing with the Moonlit Knight</li>\r\n  <li>I Know What I Like (In Your Wardrobe)</li>\r\n  <li>Firth of Fifth</li>\r\n  <li>More Fool Me</li>\r\n  <li>The Battle of Epping Forest</li>\r\n  <li>After the Ordeal</li>\r\n  <li>The Cinema Show</li>\r\n  <li>Aisle of Plenty</li>\r\n</ol>'),
(10, 1, 'MP3', 'Genesis', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>In Hiding</li>\r\n  <li>The Conqueror</li>\r\n  <li>The Lamb Lies Down On Broadway</li>\r\n  <li>The Silent Sun</li>\r\n</ol>'),
(11, 1, 'MP3', 'Grateful Dead', 'American Beauty', 'none.jpg', '<ol>\r\n  <li>Attics of My Life</li>\r\n  <li>Box of Rain</li>\r\n  <li>Brokedown Palace</li>\r\n  <li>Candyman</li>\r\n  <li>Operator</li>\r\n  <li>Ripple</li>\r\n  <li>Sugar Magnolia</li>\r\n  <li>Till the Morning Comes</li>\r\n  <li>Truckin\\\'</li>\r\n</ol>'),
(12, 1, 'MP3', 'Grateful Dead', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>St. Stephen</li>\r\n  <li>08-07-76 (live)</li>\r\n  <li>Knocking On Heaven\\\'s Door - with Bob Dylan (live)</li>\r\n  <li>Slow Train - with Bob Dylan</li>\r\n  <li>Morning Dew</li>\r\n  <li>Dark Star (Woodstock \\\'69)</li>\r\n  <li>Monkey & the Engineer (10-11-80)</li>\r\n  <li>Let It Grow (10-02-77)</li>\r\n  <li>Casey Jones (live)</li>\r\n  <li>Casey Jones</li>\r\n  <li>Uncle John\\\'s Band</li>\r\n  <li>Franklins Tower</li>\r\n  <li>Iko Iko (acoustic)</li>\r\n  <li>Looks Like Rain (10-19-77 - live)</li>\r\n  <li>Morning Dew (live)</li>\r\n  <li>Next Time You See Me</li>\r\n  <li>Peggy-O</li>\r\n  <li>09-07-85 (Red Rocks)</li>\r\n  <li>Standing On the Moon</li>\r\n  <li>Touch of Grey</li>\r\n  <li>Werewolves of London</li>\r\n  <li>Women Are Smarter</li>\r\n  <li>To Lay Me Down (10-01-80)</li>\r\n  <li>On the Road Again (live - acoustic)</li>\r\n  <li>Shakedown Street</li>\r\n  <li>Scarlet Begonias</li>\r\n</ol>'),
(13, 1, 'MP3', 'Jerry Garcia Band', '08-29-87', 'none.jpg', '<ul>\r\n  <li>Disc 1\r\n    <ol>\r\n      <li>Deep Elem Blues</li>\r\n      <li>All Around the World</li>\r\n      <li>Friend of the Devil</li>\r\n      <li>I\\\'m Troubled</li>\r\n      <li>Diamond Joe</li>\r\n      <li>Spike Drivers Blues</li>\r\n      <li>Ain\\\'t No Lie</li>\r\n    </ol>\r\n  </li>\r\n  <li>Disc 2\r\n    <ol>\r\n      <li>How Sweet It Is</li>\r\n      <li>Forever Young</li>\r\n      <li>Get Out of My Life</li>\r\n      <li>Run for the Roses</li>\r\n      <li>And It Stoned Me</li>\r\n      <li>Sisters & Brothers</li>\r\n    </ol>\r\n  </li>\r\n</ul>'),
(14, 1, 'MP3', 'Jerry Garcia Band', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Russian Lullaby</li>\r\n  <li>Dear Prudence (04-27-94)</li>\r\n  <li>Simple Twist of Fate</li>\r\n  <li>Tangled Up In Blue</li>\r\n  <li>The Way You Do the Things You Do</li>\r\n  <li>Love Scene Zabriskie Point (rare)</li>\r\n  <li>02-06-72</li>\r\n</ol>'),
(15, 1, 'MP3', 'Jimi Hendrix', 'Electric Ladyland', 'none.jpg', '<ol>\r\n  <li>And the Gods Made Love</li>\r\n  <li>Have You Ever Been (To Electric Ladyland)</li>\r\n  <li>Crosstown Traffic</li>\r\n  <li>Voodoo Chile</li>\r\n  <li>Little Miss Strange</li>\r\n  <li>Long Hot Summer Night</li>\r\n  <li>Come On (Let the Good Times Roll)</li>\r\n  <li>Gypsy Eyes</li>\r\n  <li>Burning of the Midnight Lamp</li>\r\n  <li>Rainy Day, Dream Away</li>\r\n  <li>1983 (A Merman I Should Turn To Be)</li>\r\n  <li>Moon, Turn the Tides Gently, Gently Away</li>\r\n  <li>Still Raining, Still Dreaming</li>\r\n</ol>'),
(16, 1, 'MP2', 'Jimi Hendrix', 'Gothenburg Set 2 (January 8)', 'none.jpg', '<ol>\r\n  <li>Voodoo Chile</li>\r\n  <li>Foxy Lady</li>\r\n  <li>Red House</li>\r\n  <li>I Don\\\'t Live Today</li>\r\n  <li>Hear My Train a Comin\\\'</li>\r\n  <li>Purple Haze</li>\r\n</ol>'),
(17, 1, 'MP3', 'Jimi Hendrix', 'Kiss The Sky', 'none.jpg', '<ol>\r\n  <li>Are You Experienced</li>\r\n  <li>I Don\\\'t Live Today</li>\r\n  <li>Voodoo Chile (Slight Return)</li>\r\n  <li>Stepping Stone</li>\r\n  <li>Castles Made of Sand</li>\r\n  <li>Killing Floor (Unreleased)</li>\r\n  <li>Purple Haze</li>\r\n  <li>Red House (Unedited)</li>\r\n  <li>Crosstown Traffic</li>\r\n  <li>Third Stone from the Sun</li>\r\n  <li>All Along the Watchtower</li>\r\n</ol>'),
(18, 1, 'MP2', 'Jimi Hendrix', 'Loose Ends', 'none.jpg', '<ol>\r\n  <li>Come Down Hard On Me Baby</li>\r\n  <li>Drifters Escape</li>\r\n</ol>'),
(19, 1, 'MP3', 'Jimi Hendrix', 'Multicolored Blues', 'none.jpg', '<ul>\r\n  <li>Disc 1\r\n    <ol>\r\n      <li>Earth Blues</li>\r\n      <li>Dolly Dagger</li>\r\n      <li>Room Full of Mirrors</li>\r\n      <li>Stepping Stone</li>\r\n      <li>Bleeding Heart</li>\r\n      <li>Drifter\\\'s Escape</li>\r\n      <li>Midnight</li>\r\n      <li>3 Little Bears</li>\r\n      <li>Jam Back at the House</li>\r\n      <li>Freedom</li>\r\n      <li>Lover Man</li>\r\n      <li>My Friend</li>\r\n      <li>Astro Man</li>\r\n      <li>Straight Ahead</li>\r\n      <li>1983 (A Merman I Shall Turn To Be)</li>\r\n      <li>Maui Sunset</li>\r\n    </ol>\r\n  </li>\r\n  <li>Disc 2\r\n    <ol>\r\n      <li>Slow Time Blues</li>\r\n      <li>Freedom</li>\r\n      <li>Drifting</li>\r\n      <li>Angel</li>\r\n      <li>Belly Button Window</li>\r\n      <li>Night Bird Flying</li>\r\n      <li>Pride of Man</li>\r\n      <li>Ezy Rider</li>\r\n      <li>Winter Blues</li>\r\n      <li>Last Thursday Morning</li>\r\n      <li>Crash Landing</li>\r\n      <li>Message To Love</li>\r\n      <li>Ezy Rider (revisted)</li>\r\n    </ol>\r\n  </li>\r\n</ul>'),
(20, 1, 'MP2', 'Jimi Hendrix', 'Record Plant Jams 2', 'none.jpg', '<ol>\r\n  <li>I\\\'m a Man</li>\r\n</ol>'),
(21, 1, 'MP2', 'Jimi Hendrix', 'Red House Cuts', 'none.jpg', '<ol>\r\n  <li>Red House 2</li>\r\n  <li>Red House 3</li>\r\n  <li>Red House 4</li>\r\n  <li>Red House NY Pop</li>\r\n</ol>'),
(22, 1, 'MP3', 'Jimi Hendrix', 'Smash Hits', 'none.jpg', '<ol>\r\n  <li>Purple Haze</li>\r\n  <li>Fire</li>\r\n  <li>The Wind Cries Mary</li>\r\n  <li>Can You See Me</li>\r\n  <li>All Along the Watchtower</li>\r\n  <li>Manic Depression</li>\r\n  <li>Foxy Lady</li>\r\n  <li>51st Anniversary</li>\r\n  <li>Highway Chile</li>\r\n  <li>Stone Free</li>\r\n  <li>Crosstown Traffic</li>\r\n</ol>'),
(23, 1, 'MP3', 'Jimi Hendrix', 'South Saturn Delta', 'none.jpg', '<ol>\r\n  <li>Look Over Yonder</li>\r\n  <li>Little Wing</li>\r\n  <li>Here He Comes</li>\r\n  <li>South Saturn Delta</li>\r\n  <li>Power of Soul</li>\r\n  <li>Message to the Universe</li>\r\n  <li>Tax Free</li>\r\n  <li>All Along the Watchtower</li>\r\n  <li>The Stars That Play with Laughing Sams</li>\r\n  <li>Midnight</li>\r\n  <li>Sweet Angel</li>\r\n  <li>Bleeding Heart</li>\r\n  <li>Paligap</li>\r\n  <li>Drifters Escape</li>\r\n  <li>Midnight Lightning</li>\r\n</ol>'),
(24, 1, 'MP3', 'Jimi Hendrix', 'The Home Recordings', 'none.jpg', '<ol>\r\n  <li>Angel</li>\r\n  <li>Cherokee Jam</li>\r\n  <li>Hear My Train a Comin\\\'</li>\r\n  <li>Gypsy Eyes</li>\r\n</ol>'),
(25, 1, 'MP2', 'Jimi Hendrix', 'The Singles Album (October 29)', 'none.jpg', '<ol>\r\n  <li>Gloria (studio)</li>\r\n</ol>'),
(26, 1, 'MP2', 'Jimi Hendrix', 'Vienna - Set 1 (January 22)', 'none.jpg', '<ol>\r\n  <li>Come On</li>\r\n</ol>'),
(27, 1, 'MP3 - MP2', 'Jimi Hendrix', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Voodoo Chile [MP3]</li>\r\n  <li>End [MP2]</li>\r\n  <li>Bleeding Heart</li>\r\n  <li>Fire [MP2]</li>\r\n  <li>Little Wing [MP2]</li>\r\n  <li>Room Full of Mirrors [MP2]</li>\r\n  <li>Wild Thing [MP2]</li>\r\n  <li>Catfish Blues [MP2]</li>\r\n  <li>Foxy Lady [MP2]</li>\r\n  <li>Red House [MP2]</li>\r\n  <li>Drivin\\\' South [MP2]</li>\r\n  <li>The Wind Cries Mary [MP2]</li>\r\n  <li>Fire [MP2]</li>\r\n  <li>Little Wing [MP2]</li>\r\n  <li>I Don\\\'t Live Today 1 [MP2]</li>\r\n  <li>I Don\\\'t Live Today 2 [MP2]</li>\r\n  <li>I Don\\\'t Live Today 3 [MP2]</li>\r\n  <li>I Don\\\'t Live Today [MP3]</li>\r\n  <li>Int [MP3]</li>\r\n  <li>Live in Frankfurt [MP2]</li>\r\n  <li>Purple Haze [MP3]</li>\r\n  <li>Third Stone from the Sun [MP3]</li>\r\n  <li>Voodoo Chile [MP3]</li>\r\n  <li>Voodoo Chile, Slight Return [MP3]</li>\r\n  <li>1983 (A Merman I Should Turn To Be) [MP3]</li>\r\n  <li>Cherokee Jam [MP3]</li>\r\n</ol>'),
(28, 1, 'MP3', 'Kool & The Gang', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Jungle Boogie</li>\r\n  <li>Misled</li>\r\n  <li>Get Down On It</li>\r\n  <li>Fresh</li>\r\n  <li>Summer Madness</li>\r\n  <li>Funky Stuff</li>\r\n</ol>'),
(29, 1, 'MP3', 'Led Zeppelin', 'BBC Sessions', 'none.jpg', '<ul>\r\n  <li>Disc 1\r\n    <ol>\r\n      <li>Communications Breakdown</li>\r\n      <li>How Many More Times</li>\r\n      <li>I Can\\\'t Quit You Babe</li>\r\n      <li>Something Else</li>\r\n      <li>The Girl I Love Got Long Black Hair</li>\r\n      <li>Traveling Riverside Blues</li>\r\n      <li>What Is and What Should Never Be</li>\r\n      <li>Whole Lotta Love</li>\r\n      <li>You Shook Me</li>\r\n    </ol>\r\n  </li>\r\n  <li>Disc 2\r\n    <ol>\r\n      <li>Black Dog</li>\r\n      <li>Dazed and Confused</li>\r\n      <li>Going to California</li>\r\n      <li>Heartbreaker</li>\r\n      <li>Immigrant Song</li>\r\n      <li>Since I\\\'ve Been Loving You</li>\r\n      <li>Stairway to Heaven</li>\r\n      <li>That\\\'s the Way</li>\r\n    </ol>\r\n  </li>\r\n</ul>'),
(30, 1, 'MP3', 'Led Zeppelin', 'Coda', 'none.jpg', '<ol>\r\n  <li>Bonzo\\\'s Montreux</li>\r\n  <li>Darlene</li>\r\n  <li>Ozone Baby</li>\r\n  <li>Poor Tom</li>\r\n  <li>Walter\\\'s Walk</li>\r\n  <li>Wearing and Tearing</li>\r\n  <li>We\\\'re Gonna Groove</li>\r\n</ol>'),
(31, 1, 'MP3', 'Led Zeppelin', 'Houses of the Holy', 'none.jpg', '<ol>\r\n  <li>Dancin\\\' Days</li>\r\n  <li>D\\\'yer Maker</li>\r\n  <li>No Quarter</li>\r\n  <li>Over the Hills and Far Away</li>\r\n  <li>The Ocean</li>\r\n  <li>The Rain Song</li>\r\n  <li>The Song Remains the Same</li>\r\n</ol>'),
(32, 1, 'MP3', 'Led Zeppelin', 'I', 'none.jpg', '<ol>\r\n  <li>Good Times Bad Times</li>\r\n  <li>Babe I\\\'m Gonna Leave You</li>\r\n  <li>You Shook Me</li>\r\n  <li>Dazed and Confused</li>\r\n  <li>Your Time Is Gonna Come</li>\r\n  <li>Black Mountain Side</li>\r\n  <li>Communication Breakdown</li>\r\n  <li>I Can\\\'t Quit You Baby</li>\r\n  <li>How Many More Times</li>\r\n</ol>'),
(33, 1, 'MP3', 'Led Zeppelin', 'II', 'none.jpg', '<ol>\r\n  <li>The Lemon Song</li>\r\n  <li>Thank You</li>\r\n  <li>Ramble On</li>\r\n  <li>Moby Dick</li>\r\n  <li>Bring It On Home</li>\r\n  <li>What Is and What Should Never Be</li>\r\n</ol>'),
(34, 1, 'MP3', 'Led Zeppelin', 'III', 'none.jpg', '<ol>\r\n  <li>Bron-y-aur Stomp</li>\r\n  <li>Gallows Pole</li>\r\n  <li>Out On the Tiles</li>\r\n  <li>Tangerine</li>\r\n  <li>The Immigrant Song</li>\r\n</ol>'),
(35, 1, 'MP3', 'Led Zeppelin', 'In Through the Out Door', 'none.jpg', '<ol>\r\n  <li>All My Love</li>\r\n  <li>Carouselambra</li>\r\n  <li>Fool In the Rain</li>\r\n  <li>Hot Dog</li>\r\n  <li>I\\\'m Gonna Crawl</li>\r\n  <li>In the Evening</li>\r\n  <li>South Bound Saurez</li>\r\n</ol>'),
(36, 1, 'MP3', 'Led Zeppelin', 'IV', 'none.jpg', '<ol>\r\n  <li>Misty Mountain Hop</li>\r\n  <li>Four Sticks</li>\r\n  <li>Going To California</li>\r\n  <li>When the Levee Breaks</li>\r\n  <li>Rock and Roll</li>\r\n</ol>'),
(37, 1, 'MP3', 'Led Zeppelin', 'Physical Graffiti', 'none.jpg', '<ul>\r\n  <li>Disc 1\r\n    <ol>\r\n      <li>Houses of the Holy</li>\r\n      <li>In My Time of Dying</li>\r\n      <li>Trampled Under Foot</li>\r\n      <li>Custard Pie</li>\r\n      <li>The Rover</li>\r\n      <li>Kashmir</li>\r\n    </ol>\r\n  </li>\r\n  <li>Disc 2\r\n    <ol>\r\n      <li>Black Country Woman</li>\r\n      <li>Boogie with Stu</li>\r\n      <li>Bron-y-aur Stomp</li>\r\n      <li>Down by the Seaside</li>\r\n      <li>In the Light</li>\r\n      <li>Night Flight</li>\r\n      <li>Sick Again</li>\r\n      <li>Ten Years Gone</li>\r\n      <li>The Wanton Song</li>\r\n    </ol>\r\n  </li>\r\n</ul>'),
(38, 1, 'MP3', 'Led Zeppelin', 'Presence', 'none.jpg', '<ol>\r\n  <li>Candy Store Rock</li>\r\n  <li>Achillies Last Stand</li>\r\n  <li>For Your Life</li>\r\n  <li>Hots On for Nowhere</li>\r\n  <li>Nobody\\\'s Fault But Mine</li>\r\n  <li>Royal Orleans</li>\r\n  <li>Tea for One</li>\r\n</ol>'),
(39, 1, 'MP3', 'Led Zeppelin', 'The Song Remains the Same', 'none.jpg', '<ul>\r\n  <li>Disc 1\r\n    <ol>\r\n      <li>Celebration Day</li>\r\n      <li>Dazed and Confused</li>\r\n      <li>Rain Song</li>\r\n      <li>Rock and Roll</li>\r\n      <li>The Song Remains the Same</li>\r\n    </ol>\r\n  </li>\r\n  <li>Disc 2\r\n    <ol>\r\n      <li>Moby Dick</li>\r\n      <li>Stairway to Heaven</li>\r\n      <li>Whole Lotta Love</li>\r\n    </ol>\r\n  </li>\r\n</ul>'),
(40, 1, 'MP3', 'Led Zeppelin', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Baby Come On Home</li>\r\n  <li>Custard Pie</li>\r\n  <li>Hey Hey What Can I Do</li>\r\n  <li>Kashmir</li>\r\n  <li>Moby Dick - Bonzo\\\'s Montreux</li>\r\n  <li>Stairway to Heaven</li>\r\n  <li>That\\\'s the Way</li>\r\n  <li>The Battle of Evermore</li>\r\n  <li>The Rover</li>\r\n  <li>The Song Remains the Same</li>\r\n  <li>Trampled Under Foot</li>\r\n  <li>Wearing and Tearing</li>\r\n  <li>What Is and What Should Never Be</li>\r\n  <li>When the Levee Breaks</li>\r\n  <li>White Summer - Black Mountain Side</li>\r\n  <li>Whole Lotta Love (edit)</li>\r\n  <li>Whole Lotta Love (medley)</li>\r\n  <li>You Shook Me</li>\r\n</ol>'),
(41, 1, 'MP3', 'Lou Reed', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Waiting for the Man (with David Bowie)</li>\r\n  <li>September Song</li>\r\n  <li>Perfect Day</li>\r\n  <li>Take a Walk on the Wild Side</li>\r\n</ol>'),
(42, 1, 'MP3', 'Lynard Skynard', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Don\\\'t Ask Me No Questions</li>\r\n  <li>Preacher Man</li>\r\n  <li>Simple Man</li>\r\n  <li>Sweet Home Alabama</li>\r\n  <li>The Ballad of Curtis Lowe</li>\r\n  <li>They Call Me the Breeze</li>\r\n  <li>Tuesday\\\'s Gone</li>\r\n</ol>'),
(43, 1, 'MP3', 'Otis Redding', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>I Can See Clearly Now the Rain is Gone</li>\r\n  <li>I\\\'ve Been Loving You Too Long</li>\r\n  <li>I\\\'ve Got Dreams to Remember</li>\r\n  <li>Chain Gang</li>\r\n</ol>'),
(44, 1, 'MP3', 'Paul Simon', 'Graceland', 'none.jpg', '<ol>\r\n  <li>The Boy In the Bubble</li>\r\n  <li>Graceland</li>\r\n  <li>I Know What I Know</li>\r\n  <li>Gumboots</li>\r\n  <li>Diamonds On the Soles of Her Shoes</li>\r\n  <li>You Can Call Me Al</li>\r\n  <li>Under African Skies</li>\r\n  <li>Homeless</li>\r\n  <li>Crazy Love, Vol. II</li>\r\n  <li>That Was Your Mother</li>\r\n  <li>All Around the World or the Myth</li>\r\n</ol>'),
(45, 1, 'MP3', 'Phish', '02-15-99', 'none.jpg', '<ol>\r\n  <li>Bell Bottom Blues</li>\r\n  <li>Brian & Robert</li>\r\n  <li>Chalkdust Torture</li>\r\n  <li>Chasin\\\' the Waste</li>\r\n  <li>Come On #1</li>\r\n  <li>Come On Baby</li>\r\n  <li>Dirt</li>\r\n  <li>Dogs Stole Things</li>\r\n  <li>Driver</li>\r\n  <li>Drums</li>\r\n  <li>Guyute</li>\r\n  <li>I Can See Clearly Now</li>\r\n  <li>Jiboo</li>\r\n  <li>Last Tube</li>\r\n  <li>Mozambique</li>\r\n  <li>Oooh Child</li>\r\n  <li>Pistol</li>\r\n  <li>Possum</li>\r\n  <li>Ribot</li>\r\n  <li>Row Jimmy</li>\r\n  <li>Runaway Jim</li>\r\n</ol>'),
(46, 1, 'MP3', 'Phish', '05-11-99', 'none.jpg', '<ul>\r\n  <li>Set 1\r\n    <ol>\r\n      <li>Get Back On the Train</li>\r\n      <li>Farmhouse</li>\r\n      <li>Kissed By Mist</li>\r\n      <li>Snowflakes In the Sand</li>\r\n      <li>Bathtub Gin</li>\r\n      <li>Driver</li>\r\n      <li>Trey Talks</li>\r\n      <li>Real Country Song</li>\r\n      <li>Billy Breathes</li>\r\n      <li>Sleep</li>\r\n      <li>Blue and Shiny</li>\r\n    </ol>\r\n  </li>\r\n  <li>Set 2\r\n    <ol>\r\n      <li>Gotta Jiboo</li>\r\n      <li>Will It Go Round In Circles</li>\r\n      <li>First Tube</li>\r\n      <li>Oooh Child</li>\r\n      <li>Heavy Things</li>\r\n      <li>Sand</li>\r\n      <li>Drum Duel</li>\r\n      <li>I Can See Clearly Now</li>\r\n      <li>Aqui Coma Alla</li>\r\n      <li>Voodoo Child</li>\r\n      <li>Row Jimmy</li>\r\n    </ol>\r\n  </li>\r\n</ul>'),
(47, 1, 'MP3', 'Phish', '09-17-99 Mountain View', 'none.jpg', '<ol>\r\n  <li>Free Thought</li>\r\n  <li>Guyute</li>\r\n  <li>Ghost</li>\r\n  <li>Lawn Boy</li>\r\n  <li>Peaches en Regalia</li>\r\n  <li>Moma Dance</li>\r\n  <li>Water In the Sky</li>\r\n  <li>When the Circus Comes</li>\r\n  <li>Get Back On the Train</li>\r\n  <li>David Bowie</li>\r\n  <li>Squirming Coil</li>\r\n  <li>Runaway Jim</li>\r\n  <li>Sand</li>\r\n  <li>Piper</li>\r\n  <li>Roggae</li>\r\n  <li>You Enjoy Myself</li>\r\n  <li>Bass Duel (Lesh)</li>\r\n  <li>Wolfman\\\'s Brother</li>\r\n  <li>Cold Rain and Snow</li>\r\n  <li>Viola Lee Blues</li>\r\n</ol>'),
(48, 1, 'MP3', 'Phish', '09-24-99 Austin, TX', 'none.jpg', '<ol>\r\n  <li>Farmhouse</li>\r\n</ol>'),
(49, 1, 'MP3', 'Phish', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Psycho Killer - Live 12-07-97 (Talking Heads)</li>\r\n  <li>You Enjoy Myself - with Medeski, Martin & Wood (live)</li>\r\n  <li>Four Strong Winds - with Sarah Mclachlan & Neil Young</li>\r\n</ol>'),
(50, 1, 'MP3', 'Pink Floyd', 'A Momentary Lapse of Reason', 'none.jpg', '<ol>\r\n  <li>A New Machine (Part 1)</li>\r\n  <li>A New Machine (Part 2)</li>\r\n  <li>Terminal Frost</li>\r\n  <li>Yet Another Movie Round and Around</li>\r\n  <li>Learning To Fly</li>\r\n  <li>On the Turning Away</li>\r\n  <li>One Slip</li>\r\n  <li>Signs of Life</li>\r\n  <li>Sorrow</li>\r\n  <li>The Dogs of War</li>\r\n</ol>'),
(51, 1, 'MP3 - CD', 'Pink Floyd', 'Animals', 'none.jpg', '<ol>\r\n  <li>Pigs On the Wing (Part 1)</li>\r\n  <li>3 Pigs (Three Different Ones)</li>\r\n  <li>Dogs</li>\r\n  <li>Pigs On the Wing (Part 2)</li>\r\n  <li>Sheep</li>\r\n</ol>'),
(52, 1, 'MP3', 'Pink Floyd', 'Meddle', 'none.jpg', '<ol>\r\n  <li>A Pillow of Winds</li>\r\n  <li>Echoes</li>\r\n  <li>Fearless</li>\r\n  <li>One of These Days</li>\r\n  <li>San Tropez</li>\r\n  <li>Seamus</li>\r\n</ol>'),
(53, 1, 'MP3', 'Pink Floyd', 'Piper at the Gates of Dawn', 'none.jpg', '<ol>\r\n  <li>Astronomy Domine</li>\r\n  <li>Bike</li>\r\n  <li>Chapter 24</li>\r\n  <li>Flaming</li>\r\n  <li>Interstellar Overdrive</li>\r\n  <li>Lucifer Sam</li>\r\n  <li>Matilda Mother</li>\r\n  <li>Pow R Toc H</li>\r\n  <li>Scarecrow</li>\r\n  <li>Take Up Thy Stethoscope and Walk</li>\r\n  <li>The Gnome</li>\r\n</ol>'),
(54, 1, 'MP3', 'Pink Floyd', 'Pulse', 'none.jpg', '<ul>\r\n  <li>Disc 1\r\n    <ol>\r\n      <li>A Great Day for Freedom</li>\r\n      <li>Astronomy Domine</li>\r\n      <li>Coming Back to Life</li>\r\n      <li>High Hopes</li>\r\n      <li>Keep Talking</li>\r\n      <li>Shine On You Crazy Diamond</li>\r\n      <li>Sorrow</li>\r\n      <li>What Do You Want From Me</li>\r\n    </ol>\r\n  </li>\r\n  <li>Disc 2 (live)\r\n    <ol>\r\n      <li>Any Colour You Like</li>\r\n      <li>Brain Damage</li>\r\n      <li>Breathe</li>\r\n      <li>Comfortably Numb</li>\r\n      <li>Eclipse</li>\r\n      <li>Money</li>\r\n      <li>On the Run</li>\r\n      <li>Run Like Hell</li>\r\n      <li>Speak To Me</li>\r\n      <li>The Great Gig In the Sky</li>\r\n      <li>Time</li>\r\n      <li>Us and Them</li>\r\n      <li>Wish You Were Here</li>\r\n    </ol>\r\n  </li>\r\n</ul>'),
(55, 1, 'MP3', 'Pink Floyd', 'Relics', 'none.jpg', '<ol>\r\n  <li>Arnold Layne</li>\r\n  <li>See Emily Play</li>\r\n  <li>Paintbox</li>\r\n  <li>Julia Dream</li>\r\n  <li>Careful with That Axe, Eugene</li>\r\n</ol>'),
(56, 1, 'MP3', 'Pink Floyd', 'Saucerful of Secrets', 'none.jpg', '<ol>\r\n  <li>Let There Be More Light</li>\r\n  <li>Remember a Day</li>\r\n  <li>Set the Controls for the Heart of the Sun</li>\r\n  <li>Corpocal Clegg</li>\r\n  <li>A Saucerful of Secrets</li>\r\n  <li>See Saw</li>\r\n  <li>Jughand Blues</li>\r\n</ol>'),
(57, 1, 'MP3', 'Pink Floyd', 'The Dark Side of the Moon', 'none.jpg', '<ol>\r\n  <li>Any Colour You Like</li>\r\n  <li>Brain Damage</li>\r\n  <li>Breathe In the Air</li>\r\n  <li>Eclipse</li>\r\n  <li>Money</li>\r\n  <li>On the Run</li>\r\n  <li>Speak To Me</li>\r\n  <li>The Great Gig In the Sky</li>\r\n  <li>Time</li>\r\n  <li>Us and Them</li>\r\n</ol>'),
(58, 1, 'MP3', 'Pink Floyd', 'The Final Cut', 'none.jpg', '<ol>\r\n  <li>The Post War Dream</li>\r\n  <li>Your Possible Pasts</li>\r\n  <li>One of the Few</li>\r\n  <li>The Hero\\\'s Return</li>\r\n  <li>The Gunner\\\'s Dream</li>\r\n  <li>Paranoid Eyes</li>\r\n  <li>Get Your Filthy Hands Off My Desert</li>\r\n  <li>The Fletcher Memorial Home</li>\r\n  <li>Southampton Dock</li>\r\n</ol>'),
(59, 1, 'MP3', 'Pink Floyd', 'The Wall', 'none.jpg', '<ol>\r\n  <li>The Happiest Days of Our Lives</li>\r\n  <li>Vera</li>\r\n  <li>Another Brick In the Wall (Part 2)</li>\r\n  <li>Bring the Boys Back Home</li>\r\n  <li>Comfortably Numb</li>\r\n  <li>Mother</li>\r\n  <li>Goodbye Blue Sky</li>\r\n  <li>Empty Spaces</li>\r\n  <li>In the Flesh</li>\r\n  <li>Young Lust</li>\r\n  <li>Hey You</li>\r\n</ol>'),
(60, 1, 'MP3', 'Pink Floyd', 'Miscellaneous', 'none.jgp', '<ol>\r\n  <li>Candy and a Current Bon</li>\r\n  <li>The Scarecrow</li>\r\n  <li>Wish You Were Here</li>\r\n  <li>Apples and Oranges</li>\r\n  <li>Shine On You Crazy Diamond (Part VI-IX)</li>\r\n  <li>It Would Be So Nice</li>\r\n  <li>The Show Must Go On</li>\r\n  <li>Point Me At the Sky</li>\r\n  <li>Run Like Hell</li>\r\n  <li>On the Turning Away</li>\r\n  <li>In the Flesh</li>\r\n  <li>Learning To Fly</li>\r\n  <li>Miami My Amy</li>\r\n  <li>Mother</li>\r\n  <li>Shine On You Crazy Diamond (Part I-V)</li>\r\n</ol>'),
(61, 1, 'MP3', 'Santana', 'Supernatural', 'none.jpg', '<ol>\r\n  <li>(Da Le) Yaleo</li>\r\n  <li>Love of My Life</li>\r\n  <li>Put Your Lights On</li>\r\n  <li>Africa Bamba</li>\r\n  <li>Smooth</li>\r\n  <li>Do You Like the Way</li>\r\n  <li>Maria Maria</li>\r\n  <li>Migra</li>\r\n  <li>Corazon Espinado</li>\r\n  <li>Wishing It Was</li>\r\n  <li>El Farol</li>\r\n  <li>Primavera</li>\r\n  <li>The Calling</li>\r\n</ol>'),
(62, 1, 'MP3', 'Santana - CD', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>As the Years Go By</li>\r\n  <li>El Corazon Manda</li>\r\n  <li>Everything Is Coming Our Way</li>\r\n  <li>Jingo</li>\r\n  <li>La Puerta Del Sol</li>\r\n  <li>Persuasion</li>\r\n</ol>'),
(63, 1, 'MP3', 'Stevie Wonder', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Seasons of Love (Rent)</li>\r\n  <li>Isn\\\'t She Lovely</li>\r\n  <li>Knocks Me Off My Feet</li>\r\n  <li>Superstition</li>\r\n  <li>You Are the Sunshine of My Life</li>\r\n  <li>I Just Called To Say I Love You</li>\r\n</ol>'),
(64, 1, 'MP3', 'The Beatles', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Come Together</li>\r\n  <li>Dear Prudence</li>\r\n  <li>Free As a Bird</li>\r\n  <li>Let It Be</li>\r\n  <li>I Am the Walrus</li>\r\n  <li>Strawberry Fields</li>\r\n  <li>Back In the U.S.S.R.</li>\r\n  <li>Birthday</li>\r\n  <li>ObLaDiObLaDa</li>\r\n</ol>'),
(65, 1, 'MP3', 'The Doors', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Hello I Love You</li>\r\n  <li>Riders On the Storm</li>\r\n</ol>'),
(66, 1, 'MP3', 'The Police', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Invisible Sun</li>\r\n  <li>Message In a Bottle</li>\r\n  <li>Spirits In the Material World</li>\r\n  <li>Synchronicity II</li>\r\n  <li>Walking On the Moon</li>\r\n</ol>'),
(67, 1, 'MP3', 'The Rolling Stones', 'Exile On Main Street', 'none.jpg', '<ol>\r\n  <li>Rocks Off</li>\r\n  <li>Rip This Joint</li>\r\n  <li>Shake Your Hips</li>\r\n  <li>Casino Boogie</li>\r\n  <li>Tumbling Dice</li>\r\n  <li>Sweet Virginia</li>\r\n  <li>Torn and Frayed</li>\r\n  <li>Sweet Black Angel</li>\r\n  <li>Loving Cup</li>\r\n  <li>Happy</li>\r\n  <li>Turd On The Run</li>\r\n  <li>Soul Survivor</li>\r\n  <li>I Just Want To See His Face</li>\r\n  <li>Let It Loose</li>\r\n  <li>All Down The Line</li>\r\n  <li>Stop Breaking Down</li>\r\n  <li>Shine A Light</li>\r\n  <li>Ventilator Blues</li>\r\n</ol>'),
(68, 1, 'MP3', 'The Rolling Stones', 'Sticky Fingers', 'none.jpg', '<ol>\r\n  <li>Bitch</li>\r\n  <li>Brown Sugar</li>\r\n  <li>Can\\\'t You Hear Me Knocking</li>\r\n  <li>Dead Flowers</li>\r\n  <li>I Got The Blues</li>\r\n  <li>Moonlight Mile</li>\r\n  <li>Sister Morphine</li>\r\n  <li>Sway</li>\r\n  <li>Wild Horses</li>\r\n  <li>You Gotta Move</li>\r\n</ol>'),
(69, 1, 'MP3', 'The Rolling Stones', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Jumping Jack Flash</li>\r\n  <li>Let\\\'s Spend The Night Together</li>\r\n  <li>Midnight Rambler (live)</li>\r\n  <li>Monkey Man</li>\r\n  <li>Street Fighting Man</li>\r\n  <li>Sympathy For The Devil</li>\r\n</ol>'),
(70, 1, 'MP3', 'The Who', 'Danish Treat', 'none.jpg', '<ol>\r\n  <li>I Can\\\'t Explain</li>\r\n  <li>Summertime Blues</li>\r\n  <li>My Wife</li>\r\n  <li>Baba O\\\'Riley</li>\r\n  <li>Behind Blue Eyes</li>\r\n  <li>Bargain</li>\r\n  <li>Won\\\'t Get Fooled Again</li>\r\n  <li>Magic Bus</li>\r\n  <li>The Relay</li>\r\n  <li>Pinball Wizard</li>\r\n  <li>See Me Feel Me</li>\r\n</ol>'),
(71, 1, 'MP3', 'The Who', 'Quadrophenia', 'none.jpg', '<ol>\r\n  <li>5-15</li>\r\n  <li>Bell Boy</li>\r\n  <li>Cut My Hair</li>\r\n  <li>Doctor Jimmy</li>\r\n  <li>Drowned</li>\r\n  <li>Helpless Dancer</li>\r\n  <li>I Am The Sea</li>\r\n  <li>I\\\'m One</li>\r\n  <li>Is It In My Head</li>\r\n  <li>I\\\'ve Had Enough</li>\r\n  <li>Love, Reign O\\\'er Me</li>\r\n  <li>Quadrophenia</li>\r\n  <li>Sea and Sand</li>\r\n  <li>The Dirty Jobs</li>\r\n  <li>The Punk Meets The Godfather</li>\r\n  <li>The Real Me</li>\r\n  <li>The Rock</li>\r\n</ol>'),
(72, 1, 'MP3', 'The Who', 'San Francisco 1971', 'none.jpg', '<ol>\r\n  <li>Summertime Blues</li>\r\n  <li>My Wife</li>\r\n  <li>Baba O\\\'Riley</li>\r\n  <li>Behind Blue Eyes</li>\r\n  <li>Bargain</li>\r\n  <li>Won\\\'t Get Fooled Again</li>\r\n</ol>'),
(73, 1, 'MP3', 'The Who', 'Tangled', 'none.jpg', '<ol>\r\n  <li>Heaven and Hell</li>\r\n  <li>I Can\\\'t Explain</li>\r\n  <li>Water</li>\r\n  <li>I Don\\\'t Even Know Myself</li>\r\n  <li>Young Man Blues</li>\r\n  <li>Overture - It\\\'s A Boy</li>\r\n  <li>1921</li>\r\n  <li>Amazing Journey</li>\r\n  <li>Sparks</li>\r\n  <li>Eyesight To The Blind</li>\r\n  <li>Acid Queen</li>\r\n  <li>Pinball Wizard</li>\r\n  <li>Do You Think It\\\'s Alright - Fiddle About</li>\r\n  <li>Tommy Can You Hear Me</li>\r\n  <li>There\\\'s a Doctor - Go To The Mirror</li>\r\n  <li>Smash The Mirror</li>\r\n  <li>Miracle Cure - I\\\'m Free</li>\r\n  <li>Tommy\\\'s Holiday Camp</li>\r\n  <li>We\\\'re Not Gonna Take It</li>\r\n  <li>See Me, Feel Me</li>\r\n  <li>My Generation</li>\r\n  <li>Boris The Spider</li>\r\n  <li>Summertime Blues</li>\r\n  <li>Shakin\\\' All Over</li>\r\n  <li>Magic Bus</li>\r\n  <li>Young Man Blues</li>\r\n  <li>My Generation</li>\r\n  <li>Naked Eye</li>\r\n  <li>Too Much Of Anything</li>\r\n</ol>'),
(74, 1, 'MP3', 'The Who', 'Tommy (Remastered)', 'none.jpg', '<ol>\r\n  <li>Overture</li>\r\n  <li>It\\\'s A Boy</li>\r\n  <li>1921</li>\r\n  <li>Amazing Journey</li>\r\n  <li>Sparks</li>\r\n  <li>Eyesight To The Blind</li>\r\n  <li>Christmas</li>\r\n  <li>Cousin Kevin</li>\r\n  <li>The Acid Queen</li>\r\n  <li>Underture</li>\r\n  <li>Do You Think It\\\'s Alright</li>\r\n  <li>Fiddle About</li>\r\n  <li>Pinball Wizard</li>\r\n  <li>There\\\'s A Doctor</li>\r\n  <li>Go To The Mirror!</li>\r\n  <li>Tommy Can You Hear Me</li>\r\n  <li>Smash The Mirror</li>\r\n  <li>Sensation</li>\r\n  <li>Miracle Cure</li>\r\n  <li>Sally Simpson</li>\r\n  <li>I\\\'m Free</li>\r\n  <li>Welcome</li>\r\n  <li>Tommy\\\'s Holiday Camp</li>\r\n  <li>We\\\'re Not Gonna Take It</li>\r\n</ol>'),
(75, 1, 'MP3', 'The Who', 'Who\\\'s Next', 'none.jpg', '<ol>\r\n  <li>Baba O\\\'Riley</li>\r\n  <li>Bargain</li>\r\n  <li>Love Ain\\\'t For Keepin\\\'</li>\r\n  <li>My Wife</li>\r\n  <li>The Song Is Over</li>\r\n  <li>Gettin\\\' In Tune</li>\r\n  <li>Going Mobile</li>\r\n  <li>Behind Blue Eyes</li>\r\n  <li>Won\\\'t Get Fooled Again</li>\r\n  <li>Pure and Easy</li>\r\n</ol>'),
(76, 1, 'MP3', 'The Who', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>My Generation</li>\r\n  <li>Teenage Wasteland</li>\r\n  <li>Won\\\'t Get Fooled Again</li>\r\n  <li>I Can See For Miles</li>\r\n</ol>'),
(77, 1, 'MP3', 'Traffic', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Can\\\'t Find My Way Home</li>\r\n  <li>Dear Mr. Fantasy</li>\r\n  <li>Glad</li>\r\n  <li>John Barleycorn Must Die</li>\r\n  <li>Low Spark Of The High-Heeled Boys</li>\r\n  <li>Rock and Stew</li>\r\n  <li>Medicated Goo</li>\r\n  <li>Empty Pages</li>\r\n  <li>Light Up Or Leave Me Alone</li>\r\n</ol>'),
(78, 1, 'MP3', 'Van Halen', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Hot For Teacher</li>\r\n  <li>I\\\'ll Wait</li>\r\n  <li>Atomic Punk</li>\r\n  <li>Bottoms Up</li>\r\n  <li>Drop Dead Legs</li>\r\n  <li>Girl Gone Bad</li>\r\n  <li>House Of Pain</li>\r\n  <li>Me Wise Magic</li>\r\n  <li>Runnin\\\' With The Devil</li>\r\n  <li>Top Jimmy</li>\r\n  <li>And The Cradle Will Rock</li>\r\n</ol>'),
(79, 1, 'MP3', 'Van Morrison', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Brown Eyed Girl</li>\r\n  <li>Days Like This</li>\r\n  <li>Domino</li>\r\n  <li>Have I Told You Lately</li>\r\n</ol>'),
(80, 1, 'MP3', 'Classic Rock', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>AC/DC - Back In Black</li>\r\n  <li>AC/DC - Shook Me All Night Long</li>\r\n  <li>Blues Traveler - I Want To Take You Higher</li>\r\n  <li>Canned Heat - Going Up The Country</li>\r\n  <li>Canned Heat - Time Was</li>\r\n  <li>Creedance Clearwater Revival - Bad Moon Rising</li>\r\n  <li>Creedance Clearwater Revival - Down On The Corner</li>\r\n  <li>Creedance Clearwater Revival - Fortunate Son</li>\r\n  <li>Creedance Clearwater Revival - Proud Mary</li>\r\n  <li>Chicago - You\\\'re The Inspiration</li>\r\n  <li>Chicago - Feeling Stronger Every Day</li>\r\n  <li>Chuck Berry - Johnny B. Goode</li>\r\n  <li>Louis Armstrong & Duke Ellington - Drop Me Off</li>\r\n  <li>Doobie Brothers - China Grove</li>\r\n  <li>George Thorogood - Bad To The Bone</li>\r\n  <li>George Thorogood - One Whiskey, One Scotch, One Beer</li>\r\n  <li>Gerry Rafferty - Baker Street</li>\r\n  <li>Gerry Rafferty - Right Down The Line</li>\r\n  <li>Grand Funk Railroad - I\\\'m Your Captain</li>\r\n  <li>James Gang - Rocky Mountain Way</li>\r\n  <li>Janis Joplin - Me And Bobby McGee</li>\r\n  <li>Joe Satriani - Up In The Sky</li>\r\n  <li>Louis Armstrong - Wonderful World</li>\r\n  <li>Mountain - Mississippi Queen</li>\r\n  <li>Paul Simon - Me And Julio Down By The Schoolyard</li>\r\n  <li>Paul Simon - You Can Call Me Al</li>\r\n  <li>Peter Tosh - Legalize It</li>\r\n  <li>Rollins Band - Four Sticks</li>\r\n  <li>Van Halen - Somebody Get Me A Doctor</li>\r\n  <li>Steve Winwood & Blind Faith - Can\\\'t Find My Way Home</li>\r\n  <li>Stevie Ray Vaughan - Ain\\\'t Gone & Give Up On Love</li>\r\n  <li>Stevie Ray Vaughan - Look At Little Sister</li>\r\n  <li>The Band with Bob Dylan</li>\r\n  <li>The Champs - Tequila</li>\r\n  <li>These Words</li>\r\n  <li>War - Low Rider</li>\r\n</ol>'),
(81, 1, 'MP3', 'Bob Dylan', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Lay Lady Lay</li>\r\n  <li>Blowing In The Wind</li>\r\n  <li>Everybody Must Get Stoned</li>\r\n  <li>Hurricane</li>\r\n  <li>Like A Rolling Stone</li>\r\n  <li>Mr. Bo Jangles</li>\r\n  <li>Mr. Tamborine Man</li>\r\n  <li>Stuck In The Middle With You</li>\r\n  <li>Tangled Up In Blue</li>\r\n  <li>The Times They Are A Changin\\\'</li>\r\n  <li>Playin\\\' In The Band (Live)</li>\r\n  <li>Up On Cripple Creek</li>\r\n  <li>Wish You Were Here</li>\r\n</ol>'),
(82, 1, 'MP3', 'The Moody Blues', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Nights In White Satin</li>\r\n  <li>The Day Begins</li>\r\n  <li>Dust In The Wind</li>\r\n  <li>House Of The Rising Sun</li>\r\n  <li>Isn\\\'t Life Strange</li>\r\n  <li>Know You\\\'re Out There Somewhere</li>\r\n  <li>Legend Of A Mind (Timothy Leary)</li>\r\n  <li>Singer In A Rock-n-Roll Band</li>\r\n  <li>The Dream</li>\r\n  <li>The Other Side Of Life</li>\r\n  <li>This Is The Moment</li>\r\n  <li>How Is It (We Are Here)</li>\r\n  <li>Gemini Dream</li>\r\n  <li>Go Now</li>\r\n  <li>Voyage</li>\r\n  <li>Never Comes The Day</li>\r\n  <li>Your Wildest Dreams</li>\r\n</ol>');
# --------------------------------------------------------

#
# Table structure for table `musicentriescomedy`
#

DROP TABLE IF EXISTS musicentriescomedy;
CREATE TABLE musicentriescomedy (
  musicEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  musicType text NOT NULL,
  artist text NOT NULL,
  album text NOT NULL,
  imageName text NOT NULL,
  tracks text NOT NULL,
  PRIMARY KEY  (musicEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `musicentriescomedy`
#

INSERT INTO musicentriescomedy (musicEntryId, publishFlag, musicType, artist, album, imageName, tracks) VALUES (2, 1, 'MP3', 'Cheech & Chong', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Don\\\'t Answer The Phone</li>\r\n  <li>Mexican Americans</li>\r\n  <li>Santa Claus</li>\r\n  <li>Dog Shit Joint</li>\r\n  <li>Kung Fu Fighting</li>\r\n  <li>Pussy</li>\r\n  <li>Vietnam</li>\r\n  <li>Gonorrhea</li>\r\n</ol>'),
(3, 1, 'MP3', 'George Carlin', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>4 Groups That Gotta Go</li>\r\n  <li>About God</li>\r\n  <li>Airport Security</li>\r\n  <li>Airline Announcements</li>\r\n  <li>American The Beautiful</li>\r\n  <li>Assholes</li>\r\n  <li>Baseball vs Footbal</li>\r\n  <li>Birth Control</li>\r\n  <li>Capital Punishment</li>\r\n  <li>Class Clown</li>\r\n  <li>Cute Little Farts</li>\r\n  <li>Delta Commercial In Ebonics</li>\r\n  <li>Don\\\'t Pull The Plug On Me</li>\r\n  <li>Ebonics Language Session</li>\r\n  <li>English Language</li>\r\n  <li>Euphemisms</li>\r\n  <li>Farting In Public</li>\r\n  <li>Fear Of Germs</li>\r\n  <li>Feb. 99 (Part 4)</li>\r\n  <li>Feminist Blowjob</li>\r\n  <li>Free Floating Hostility</li>\r\n  <li>Fuck Mickey Mouse</li>\r\n  <li>Fuck The Children</li>\r\n  <li>Good Ideas</li>\r\n  <li>I Ain\\\'t Affraid Of Cancer</li>\r\n  <li>I Love My Dog</li>\r\n  <li>Incomplete List Of Impolite Words</li>\r\n  <li>Lifes Little Moments</li>\r\n  <li>Man Stuff</li>\r\n  <li>Minority Language</li>\r\n  <li>More Stuff On Cars and Driving</li>\r\n  <li>My God\\\'s Dick Is Huge!</li>\r\n  <li>Offensive Language</li>\r\n  <li>Organ Donor Programs</li>\r\n  <li>Pussification Of The American Male</li>\r\n  <li>Rape Can Be Funny</li>\r\n  <li>Seven Words You Can\\\'t Say On TV</li>\r\n  <li>Sex In Commercials</li>\r\n  <li>Some People Are Stupid</li>\r\n  <li>State Prison Farms</li>\r\n  <li>Teenage Masterbation</li>\r\n  <li>They\\\'re Only Words</li>\r\n  <li>Things You\\\'ve Never Heard</li>\r\n  <li>Things You Don\\\'t Want To Hear</li>\r\n  <li>Things You Never Hear</li>\r\n  <li>Things You Never See</li>\r\n  <li>Usage of Fuck</li>\r\n  <li>Used To Be Irish Catholic</li>\r\n  <li>Vagina Song</li>\r\n  <li>War Of The Penises</li>\r\n  <li>You\\\'re All Diseased</li>\r\n</ol>'),
(4, 1, 'MP3', 'Tenacious D', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>One Note Song</li>\r\n  <li>Sex Supreme</li>\r\n  <li>Kyle Took A Bullet For Me</li>\r\n  <li>Explosivo</li>\r\n  <li>City Hall</li>\r\n  <li>Cock Pushups</li>\r\n  <li>Dio</li>\r\n  <li>Double Team</li>\r\n  <li>Drive Thru</li>\r\n  <li>Fat Albert</li>\r\n  <li>Friendship Test</li>\r\n  <li>Fuck Her Gently</li>\r\n  <li>Hard Fucking</li>\r\n  <li>I\\\'m The OnlyGay Eskimo</li>\r\n  <li>Inward Singing</li>\r\n  <li>Karate Schnitzel</li>\r\n  <li>Kielbasa</li>\r\n  <li>Lee</li>\r\n  <li>My Biznitch Is The Shiznit</li>\r\n  <li>Rock Your Socks</li>\r\n  <li>Rocketsauce</li>\r\n  <li>Sasquatch</li>\r\n  <li>Tribute</li>\r\n  <li>The Road</li>\r\n  <li>They Fucked Our Asses</li>\r\n  <li>UFO</li>\r\n  <li>With Karate I\\\'ll Kick Your Ass</li>\r\n  <li>Wonderboy</li>\r\n  <li>Kyle Quit</li>\r\n</ol>'),
(5, 1, 'MP3', 'Comedy', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Chris Farley - A Van Down By The River</li>\r\n  <li>Bill Clinton - Smack My Bitch Up</li>\r\n  <li>Bill Clinton - Reefer</li>\r\n  <li>Bill Clinton - Miss Lewinsky and I</li>\r\n  <li>Brain Reagan - Stupid In School</li>\r\n  <li>Bud Light Presents - Mr. Outside The Stadium Peanut Seller</li>\r\n  <li>Carlos Mencia - Unmerciful</li>\r\n  <li>Carlon Mencia - Take A Joke America</li>\r\n  <li>Cartman & Elvis - In The Ghetto</li>\r\n  <li>Cookie Monster - I Did It All For The Cookie</li>\r\n  <li>Jennifer Lopez Parody - If You Had My Butt</li>\r\n  <li>Britney Spears Parody - Oops! I\\\'m Pregnant Again</li>\r\n  <li>Titanic Parody - My Fart Will Go On</li>\r\n  <li>Crisqo - Bong Song</li>\r\n  <li>Dennis Leary - Voices In Your Head</li>\r\n  <li>Howard Stern - Darth Vader Orgasm</li>\r\n  <li>Howard Stern - Monicas Song For The President</li>\r\n  <li>Jerky Boys - Gay Gangsters</li>\r\n  <li>Monty Python - Penis Song</li>\r\n  <li>Mr. Show - David Cross HBO Special \\\'95</li>\r\n  <li>Muppets - Happy Feet</li>\r\n  <li>Muppets - Muppet Show Theme</li>\r\n  <li>Elmo In Hooker Land</li>\r\n  <li>Pinkard & Bowden - Propane</li>\r\n  <li>Pok-E-Mon Adult Toys</li>\r\n  <li>Prank Phone Calls - I\\\'m Gonna Fuck Your Day Up</li>\r\n  <li>Simpsons - Springfield Police At McDonald\\\'s</li>\r\n  <li>Star Wars - Yoda Drunk On The Set</li>\r\n  <li>The Spy Who Shagged Me - Just The Two Of Us (Dr. Evil)</li>\r\n  <li>Weird Al Yankovic - Asshole Sun</li>\r\n</ol>');
# --------------------------------------------------------

#
# Table structure for table `musicentrieseighties`
#

DROP TABLE IF EXISTS musicentrieseighties;
CREATE TABLE musicentrieseighties (
  musicEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  musicType text NOT NULL,
  artist text NOT NULL,
  album text NOT NULL,
  imageName text NOT NULL,
  tracks text NOT NULL,
  PRIMARY KEY  (musicEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `musicentrieseighties`
#

INSERT INTO musicentrieseighties (musicEntryId, publishFlag, musicType, artist, album, imageName, tracks) VALUES (1, 1, 'MP3', 'Adam Ant', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Desperate But Not Serious</li>\r\n  <li>Goody Two Shoes</li>\r\n  <li>Stand and Deliver</li>\r\n</ol>'),
(2, 1, 'MP3', 'David Bowie', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Space Oddity</li>\r\n  <li>Under Pressure (with Queen)</li>\r\n  <li>Golden Years</li>\r\n</ol>'),
(3, 1, 'MP3', 'Devo', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Satisfaction</li>\r\n  <li>Pop Musik</li>\r\n  <li>Whip It</li>\r\n</ol>'),
(4, 1, 'MP3', 'Duran Duran', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>A View To A Kill</li>\r\n  <li>Come Undone</li>\r\n  <li>Girls On Film</li>\r\n  <li>Hungry Like A Wolf</li>\r\n  <li>Reflex</li>\r\n  <li>Rio</li>\r\n  <li>Save A Prayer</li>\r\n  <li>Thank You</li>\r\n</ol>'),
(5, 1, 'MP3', 'Queen', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Another One Bites The Dust</li>\r\n  <li>Crazy Little Thing Called Love</li>\r\n  <li>Radio Ga Ga</li>\r\n</ol>'),
(6, 1, 'MP3', 'Talking Heads', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>And She Was</li>\r\n  <li>Burning Down The House</li>\r\n  <li>Cities</li>\r\n  <li>Heaven</li>\r\n  <li>Once In A Lifetime</li>\r\n  <li>Phycho Killer</li>\r\n  <li>Road To Nowhere</li>\r\n  <li>Wild, Wild Life</li>\r\n  <li>Until The End of The World</li>\r\n</ol>'),
(7, 1, 'MP3', '80\\\'s', 'Miscellaneous', 'none.jpg', '<ul>\r\n  <li>Madness\r\n    <ol>\r\n      <li>House of Fun</li>\r\n    </ol>\r\n  </li>\r\n  <li>Prince\r\n    <ol>\r\n      <li>Little Red Corvette</li>\r\n      <li>When Doves Cry</li>\r\n    </ol>\r\n  </li>\r\n  <li>The Fixx\r\n    <ol>\r\n      <li>One Thing Leads To Another</li>\r\n    </ol>\r\n  </li>\r\n  <li>Timex Social Club\r\n    <ol>\r\n      <li>Rumors (extended)</li>\r\n    </ol>\r\n  </li>\r\n  <li>The Violent Femmes\r\n    <ol>\r\n      <li>Blister In The Sun</li>\r\n    </ol>\r\n  </li>\r\n</ul>'),
(8, 1, 'MP3', 'Peter Gabriel', 'Passion Music For The Last Temptation of Christ', 'none.jpg', '<ol>\r\n  <li>The Feeling Begins</li>\r\n  <li>Gethsemane</li>\r\n  <li>Of These, Hope</li>\r\n  <li>Lazarus Raised</li>\r\n  <li>Of These, Hope (reprise)</li>\r\n  <li>In Doubt</li>\r\n  <li>A Different Drum</li>\r\n  <li>Zaar</li>\r\n  <li>Troubled</li>\r\n  <li>Open</li>\r\n  <li>Before Night Falls</li>\r\n  <li>With This Love</li>\r\n  <li>Sandstorm</li>\r\n  <li>Stigmata</li>\r\n  <li>Passion</li>\r\n  <li>With This Love (choir)</li>\r\n  <li>Wall of Breath</li>\r\n  <li>The Promise of Shadows</li>\r\n  <li>Disturbed</li>\r\n  <li>It Is Accomplished</li>\r\n  <li>Bread and Wine</li>\r\n</ol>'),
(9, 1, 'MP3', 'Peter Gabriel', 'Secret World Live', 'none.jpg', '<ul>\r\n  <li>Disc 1\r\n    <ol>\r\n      <li>Across The River</li>\r\n      <li>Blood of Eden</li>\r\n      <li>Come Talk To Me</li>\r\n      <li>Kiss That Frog</li>\r\n      <li>Red Rain</li>\r\n      <li>Shaking The Tree</li>\r\n      <li>Slow Marimbas</li>\r\n      <li>Solsbury Hill</li>\r\n      <li>Steam</li>\r\n      <li>Washing of The Water</li>\r\n    </ol>\r\n  </li>\r\n  <li>Disc 2\r\n    <ol>\r\n      <li>Digging In The Dirt</li>\r\n      <li>Don\\\'t Give Up</li>\r\n      <li>In Your Eyes</li>\r\n      <li>Secret World</li>\r\n      <li>Sledgehammer</li>\r\n    </ol>\r\n  </li>\r\n</ul>'),
(10, 1, 'MP3', 'Peter Gabriel', 'So', 'none.jpg', '<ol>\r\n  <li>Red Rain</li>\r\n  <li>Sledgehammer</li>\r\n  <li>Don\\\'t Give Up</li>\r\n  <li>That Voice Again</li>\r\n  <li>In Your Eyes</li>\r\n  <li>Mercy Street</li>\r\n  <li>Big Time</li>\r\n  <li>We Do What We\\\'re Told (Milgram\\\'s 37)</li>\r\n  <li>This Is The Picture (Excellent Birds)</li>\r\n</ol>'),
(11, 1, 'MP3', 'Peter Gabriel', 'Us', 'none.jpg', '<ol>\r\n  <li>Come Talk To Me</li>\r\n  <li>Love To Be Loved</li>\r\n  <li>Blood of Eden</li>\r\n  <li>Steam</li>\r\n  <li>Only Us</li>\r\n  <li>Washing of the Water</li>\r\n  <li>Digging in the Dirt</li>\r\n  <li>Fourteen Black Paintings</li>\r\n  <li>Kiss That Frog</li>\r\n  <li>Secret World</li>\r\n</ol>'),
(12, 1, 'MP3', 'The Cure', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Just Like Heaven</li>\r\n  <li>Maybe Someday</li>\r\n  <li>Boys Don\\\'t Cry</li>\r\n  <li>Close To Me</li>\r\n  <li>High</li>\r\n  <li>If Only Tonight We Could Sleep</li>\r\n  <li>Lullaby</li>\r\n  <li>Fascination Street</li>\r\n  <li>Everything Mix</li>\r\n  <li>The Caterpillar (Flicker Mix)</li>\r\n  <li>Disintegration</li>\r\n</ol>');
# --------------------------------------------------------

#
# Table structure for table `musicentriesfunk`
#

DROP TABLE IF EXISTS musicentriesfunk;
CREATE TABLE musicentriesfunk (
  musicEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  musicType text NOT NULL,
  artist text NOT NULL,
  album text NOT NULL,
  imageName text NOT NULL,
  tracks text NOT NULL,
  PRIMARY KEY  (musicEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `musicentriesfunk`
#

INSERT INTO musicentriesfunk (musicEntryId, publishFlag, musicType, artist, album, imageName, tracks) VALUES (2, 1, 'MP3', 'The Strokes', 'Is This It', 'none.jpg', '<ol>\r\n  <li>Is This It</li>\r\n  <li>The Modern Age</li>\r\n  <li>Soma</li>\r\n  <li>Barely Legal</li>\r\n  <li>Someday</li>\r\n  <li>Alone, Together</li>\r\n  <li>Last Nite</li>\r\n  <li>Hard To Explain</li>\r\n  <li>New York City Cops</li>\r\n  <li>Trying Your Luck</li>\r\n  <li>Take It or Leave It</li>\r\n</ol>'),
(3, 1, 'MP3', 'Archers of Loaf', 'Unknown', 'none.jpg', '<ol>\r\n  <li>I.N.S.</li>\r\n  <li>Nostalgia</li>\r\n  <li>Smokin\\\' Pot In The Hot City</li>\r\n  <li>Telepathic Traffic</li>\r\n</ol>'),
(4, 1, 'MP3', 'Beastie Boys', 'Licensed To Ill', 'none.jpg', '<ol>\r\n  <li>Brass Monkey</li>\r\n  <li>Fight For Your Right</li>\r\n  <li>Girls</li>\r\n  <li>Hold It Now, Hit It</li>\r\n  <li>No Sleep Till Brooklyn</li>\r\n  <li>Paul Revere</li>\r\n  <li>Posse In Effect</li>\r\n  <li>Rhymin\\\' & Stealin\\\'</li>\r\n  <li>She\\\'s Crafty</li>\r\n  <li>Slow And Low</li>\r\n  <li>The New Style</li>\r\n  <li>Time To Get Ill</li>\r\n</ol>'),
(5, 1, 'MP3', 'Blur', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Beatlebum</li>\r\n  <li>Girls And Boys</li>\r\n  <li>Music Is My Radar</li>\r\n  <li>No Distance Left To Run</li>\r\n  <li>Woohoo</li>\r\n</ol>'),
(6, 1, 'MP3', 'Cold Storage', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Tentative</li>\r\n  <li>Canada</li>\r\n  <li>Transvaal</li>\r\n  <li>Doh T</li>\r\n</ol>'),
(7, 1, 'MP3', 'Cracker', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Been Around The World</li>\r\n  <li>Dixie Babylon</li>\r\n  <li>Euro Trash Girl</li>\r\n  <li>Get Off This</li>\r\n  <li>I Can\\\'t Forget You</li>\r\n  <li>James River</li>\r\n  <li>Take Me Down To The Infirmary</li>\r\n</ol>'),
(8, 1, 'MP3', 'The Crystal Method', 'Vegas', 'none.jpg', '<ol>\r\n  <li>Trip Like I Do</li>\r\n  <li>Busy Child</li>\r\n  <li>Cherry Twist</li>\r\n  <li>High Roller</li>\r\n  <li>Comin\\\' Back</li>\r\n  <li>Keep Hope Alive</li>\r\n  <li>Vapor Trail</li>\r\n  <li>She\\\'s My Pusher</li>\r\n  <li>Jaded</li>\r\n  <li>Bad Stone</li>\r\n</ol>'),
(9, 1, 'MP3', 'The Crystal Method', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Sidewinder</li>\r\n  <li>Caterpillar</li>\r\n  <li>Wild, Sweet And Cool</li>\r\n  <li>Roll It Up</li>\r\n  <li>Over The Line</li>\r\n  <li>The Winner</li>\r\n  <li>Hype</li>\r\n  <li>Come Together</li>\r\n  <li>I Think I\\\'m Crystalized</li>\r\n  <li>Name Of The Game</li>\r\n  <li>Miss Blue</li>\r\n  <li>Nitrous Oxide</li>\r\n  <li>Outer</li>\r\n  <li>Replacement Killers</li>\r\n  <li>Sensation</li>\r\n  <li>Ten Miles Back</li>\r\n</ol>'),
(10, 1, 'MP3', 'Faith No More', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Kindergarten</li>\r\n  <li>Another Body Murdered</li>\r\n  <li>Edge Of The World</li>\r\n  <li>A Small Victory</li>\r\n  <li>Be Aggressive</li>\r\n  <li>Caffeine</li>\r\n  <li>I Started A Joke</li>\r\n  <li>Ricochet</li>\r\n  <li>Malpractice</li>\r\n  <li>Midlife Crisis</li>\r\n  <li>Midnight Cowboy</li>\r\n  <li>Insect Hororscope</li>\r\n  <li>RV</li>\r\n  <li>Smaller And Smaller</li>\r\n  <li>We Care A Lot</li>\r\n  <li>What Is It</li>\r\n  <li>Woodpecker From Mars</li>\r\n  <li>Surprise Your Dead</li>\r\n  <li>The Morning After</li>\r\n  <li>Epic</li>\r\n  <li>Take This Bottle</li>\r\n  <li>Zombie Eaters</li>\r\n</ol>'),
(11, 1, 'MP3', 'G. Love & Special Sauce', 'Philadelphonic', 'none.jpg', '<ol>\r\n  <li>Around The World (Thank You)</li>\r\n  <li>Do It For Free</li>\r\n  <li>Dreamin\\\'</li>\r\n  <li>Friday Night (Hundred Dollar Bill)</li>\r\n  <li>Gimme Some Lovin\\\'</li>\r\n  <li>Honor And Harmony</li>\r\n  <li>Kick Drum</li>\r\n  <li>Love</li>\r\n  <li>No Turning Back</li>\r\n  <li>Numbers</li>\r\n  <li>Relax</li>\r\n  <li>Roaches</li>\r\n  <li>Rock & Roll (Shouts Out Back To The Rappers)</li>\r\n  <li>Rodeo Clowns</li>\r\n</ol>'),
(12, 1, 'MP3', 'G. Love & Special Sauce', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Shooting Hoops</li>\r\n  <li>I-76</li>\r\n  <li>Sweet Sugar Mama</li>\r\n  <li>Stepping Stones</li>\r\n  <li>Dreamin\\\'</li>\r\n  <li>Cold Beverages</li>\r\n  <li>Kick Drum</li>\r\n  <li>Muppets From Space</li>\r\n  <li>This Ain\\\'t Living</li>\r\n</ol>'),
(13, 1, 'MP3', 'Garbage', 'Beautiful Garbage', 'none.jpg', '<ol>\r\n  <li>Androgyny</li>\r\n  <li>Breaking Up The Girl</li>\r\n  <li>Can\\\'t Cry These Tears</li>\r\n  <li>Cherry Lips (Go Baby Go!)</li>\r\n  <li>Cup Of Coffee</li>\r\n  <li>Drive You Home</li>\r\n  <li>Nobody Loves You</li>\r\n  <li>Parade</li>\r\n  <li>Shut Your Mouth</li>\r\n  <li>Silence Is Golden</li>\r\n  <li>So Like A Rose</li>\r\n  <li>Till The Day I Die</li>\r\n  <li>Untouchable</li>\r\n</ol>'),
(14, 1, 'MP3', 'Garbage', 'Unknown', 'none.jpg', '<ol>\r\n  <li>#1 Crush (Romeo And Juliet Soundtrack)</li>\r\n  <li>Supervixen</li>\r\n  <li>Queer</li>\r\n  <li>Only Happy When It Rains</li>\r\n  <li>As Heaven Is Wide</li>\r\n  <li>Not My Idea</li>\r\n  <li>A Stroke Of Luck</li>\r\n  <li>Vow</li>\r\n  <li>Stupid</li>\r\n  <li>Dog New Tricks</li>\r\n  <li>Sleep Together</li>\r\n  <li>My Lover\\\'s Box</li>\r\n  <li>Fix Me Now</li>\r\n  <li>Milk</li>\r\n  <li>Afterglow</li>\r\n  <li>Alien Sex Fiend</li>\r\n  <li>Kick My Ass</li>\r\n  <li>Temptation Waits</li>\r\n  <li>Dumb</li>\r\n  <li>When I Grow Up</li>\r\n  <li>Hammering In My Head</li>\r\n</ol>'),
(15, 1, 'MP3', 'Beastie Boys', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Body Movin\\\'</li>\r\n  <li>Shake Your Rump</li>\r\n  <li>So Whatcha Want</li>\r\n</ol>'),
(16, 1, 'MP3', 'Dido', 'No Angel', 'none.jpg', '<ol>\r\n  <li>Here With Me</li>\r\n  <li>Hunter</li>\r\n  <li>Don\\\'t Think Of Me</li>\r\n  <li>My Lover\\\'s Gone</li>\r\n  <li>All You Want</li>\r\n  <li>Thank You</li>\r\n  <li>Honestly OK</li>\r\n  <li>Slide</li>\r\n  <li>Isobel</li>\r\n  <li>I\\\'m No Angel</li>\r\n  <li>My Life</li>\r\n  <li>Take My Hand</li>\r\n</ol>'),
(17, 1, 'MP3', 'Digable Planets', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Jungle Free Bass</li>\r\n  <li>Blowing Down</li>\r\n  <li>The May 4th Movement</li>\r\n  <li>Le Femme Fetale</li>\r\n</ol>'),
(18, 1, 'MP3', 'Everything But The Girl', 'Amplified Heart', 'none.jpg', '<ol>\r\n  <li>Roller Coaster</li>\r\n  <li>Troubled Mind</li>\r\n  <li>I Don\\\'t Understand Anything</li>\r\n  <li>Walking To You</li>\r\n  <li>Get Me</li>\r\n  <li>Missing</li>\r\n  <li>Two Star</li>\r\n  <li>We Walk The Same Line</li>\r\n  <li>25th December</li>\r\n  <li>Disenchanted</li>\r\n  <li>Missing (Todd Terry Club Mix)</li>\r\n</ol>'),
(19, 1, 'MP3', 'Everything But The Girl', 'Temperamental', 'none.jpg', '<ol>\r\n  <li>Five Fathoms</li>\r\n  <li>Low Tide Of The Night</li>\r\n  <li>Blame</li>\r\n  <li>Hatfield 1980</li>\r\n  <li>Temperamental</li>\r\n  <li>Compression</li>\r\n  <li>Downhill Racer</li>\r\n  <li>Lullaby Of Clubland</li>\r\n  <li>No Difference</li>\r\n  <li>The Future Of The Future (Stay Gold)</li>\r\n</ol>'),
(20, 1, 'MP3', 'Everything But The Girl', 'Walking Wounded', 'none.jpg', '<ol>\r\n  <li>Before Today</li>\r\n  <li>Wrong</li>\r\n  <li>Single</li>\r\n  <li>The Heart Remains A Child</li>\r\n  <li>Walking Wounded</li>\r\n  <li>Flipside</li>\r\n  <li>Big Deal</li>\r\n  <li>Mirrorball</li>\r\n  <li>Good Cop Bad Cop</li>\r\n  <li>Wrong (Todd Terry Remix)</li>\r\n  <li>Walking Wounded (Omni Trio Remix)</li>\r\n</ol>'),
(21, 1, 'CD', 'Colonel Les Claypool\\\'s Fearless Flying Frog Brigade', 'Live Frogs Set 1', 'frogs1.jpg', '<p>Live 10/8,9/00 at The Great American Music Hall</p>\r\n<ol>\r\n  <li>Thela Hun Ginjeet</li>\r\n  <li>Riddles Are Abound Tonight</li>\r\n  <li>Hendershot</li>\r\n  <li>Shattering Song</li>\r\n  <li>Running The Gauntlet</li>\r\n  <li>Girls For Single Men</li>\r\n  <li>Shine On You Crazy Diamond (Jack Irons version)</li>\r\n</ol>'),
(22, 1, 'CD', 'Colonel Les Claypool\\\'s Fearless Flying Frog Brigade', 'Live Frogs Set 2', 'frogs2.jpg', '<p>Live 10/8,9/00 at The Great American Music Hall</p>\r\n<ol>\r\n  <li>Pigs On The Wing 1</li>\r\n  <li>Dogs</li>\r\n  <li>Pigs (Three Different Ones)</li>\r\n  <li>Sheep</li>\r\n  <li>Pigs On The Wing 2</li>\r\n</ol>'),
(23, 1, 'CD', 'Les Claypool and the Holy Mackerel', 'Highball with the Devil', 'holyMackerel.jpg', '<ol>\r\n  <li>Running The Gauntlet</li>\r\n  <li>Holy Mackerel</li>\r\n  <li>Highball With The Devil</li>\r\n  <li>Hendershot</li>\r\n  <li>Calling Kyle</li>\r\n  <li>Rancor</li>\r\n  <li>Cohibas Esplenditos</li>\r\n  <li>Delicate Tendrils</li>\r\n  <li>The Awakening</li>\r\n  <li>Precipitation</li>\r\n  <li>George E. Porge</li>\r\n  <li>El Sobrante Fortnight</li>\r\n  <li>Granny\\\'s Little Yard Gnome</li>\r\n  <li>Me And Chuck</li>\r\n  <li>Carolina Rig</li>\r\n</ol>'),
(24, 1, 'CD', 'Elliot Smith', 'Figure 8', 'elliotSmith1.jpg', '<ol>\r\n  <li>Son Of Sam</li>\r\n  <li>Somebody That I Used To Know</li>\r\n  <li>Junk Bond Trader</li>\r\n  <li>Everything Reminds Me Of Her</li>\r\n  <li>Everything Means Nothing To Me</li>\r\n  <li>LA</li>\r\n  <li>In The Lost And Found (Honky Bach) The Roost</li>\r\n  <li>Stupidity Tries</li>\r\n  <li>Easy Way Out</li>\r\n  <li>Wouldn\\\'t Mama Be Proud?</li>\r\n  <li>Color Bars</li>\r\n  <li>Happiness The Gondola Man</li>\r\n  <li>Pretty Mary K</li>\r\n  <li>I Better Be Quiet Now</li>\r\n  <li>Can\\\'t Make A Sound</li>\r\n  <li>Bye</li>\r\n</ol>'),
(25, 1, 'MP3', 'Elliot Smith', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>No Name #3</li>\r\n  <li>Alphabet Town</li>\r\n  <li>Amity</li>\r\n  <li>Baby Britian</li>\r\n  <li>Because</li>\r\n  <li>Between The Bars</li>\r\n  <li>Christian Brothers</li>\r\n  <li>Clementine</li>\r\n  <li>Coming Up Roses</li>\r\n  <li>Everybody Cares, Everybody Understands</li>\r\n  <li>Everything Means Nothing To Me</li>\r\n  <li>Good To Go</li>\r\n  <li>I Didn\\\'t Understand</li>\r\n  <li>Last Call</li>\r\n  <li>Needle In The Hay</li>\r\n  <li>Oh Well, Okay</li>\r\n  <li>Pictures Of Me</li>\r\n  <li>Pitseleh</li>\r\n  <li>Satellite</li>\r\n  <li>Single File</li>\r\n  <li>St...</li>\r\n  <li>Sweet Adeline</li>\r\n  <li>The Biggest Lie</li>\r\n  <li>The White Lady Loves You More</li>\r\n  <li>Tommorow, Tommorow</li>\r\n  <li>Bled White</li>\r\n  <li>A Question Mark</li>\r\n  <li>Angeles</li>\r\n  <li>Bottle Up & Explode! (early version)</li>\r\n  <li>Jealous Guy (John Lennon cover)</li>\r\n  <li>Miss Misery</li>\r\n  <li>Say Yes</li>\r\n  <li>Some Song</li>\r\n  <li>Son Of Sam</li>\r\n  <li>The Enemy Is You</li>\r\n  <li>Waltz #1</li>\r\n  <li>Waltz #2</li>\r\n  <li>Independence Day</li>\r\n</ol>'),
(26, 1, 'MP3', 'George Clinton & Parliament Funkadelic', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Hideous Mutant Freekz</li>\r\n  <li>Sax Machine</li>\r\n  <li>Cosmic Slop</li>\r\n  <li>Atomic Dog (Original Extended)</li>\r\n  <li>Maggot Brain</li>\r\n  <li>Tear The Roof Off</li>\r\n  <li>Mothership Connection</li>\r\n  <li>P-Funk</li>\r\n  <li>Erotic City</li>\r\n  <li>Bop Gun</li>\r\n</ol>'),
(27, 1, 'MP3', 'Local H', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Born To Be Down</li>\r\n  <li>Bound For The Floor</li>\r\n  <li>Copasetic</li>\r\n  <li>Half Life</li>\r\n  <li>Hi Fiving Mother Fucker</li>\r\n  <li>Just Don\\\'t Get It</li>\r\n  <li>Serve The Servents (Nirvana Cover)</li>\r\n  <li>Sweet Child O\\\'Mine (Gun N\\\' Roses Cover)</li>\r\n  <li>School (Live Summerfest Nirvana Cover)</li>\r\n</ol>'),
(28, 1, 'MP3', 'Medeski, Martin, and Wood', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Last Chance To Dance Trance (Perhaps)</li>\r\n  <li>C-Jam Blues</li>\r\n  <li>Bubblehouse</li>\r\n  <li>Psychedelic Sally</li>\r\n  <li>Shack Man</li>\r\n  <li>The Lover</li>\r\n  <li>Crosstown Traffic</li>\r\n  <li>Jellybelly</li>\r\n  <li>Satan\\\'s Church Of The Hypnotized</li>\r\n  <li>You Enjoy Myself</li>\r\n</ol>'),
(29, 1, 'MP3', 'Mr. Bungle', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Jerry Reed Cover</li>\r\n  <li>Zombie Eaters</li>\r\n  <li>For No Reason</li>\r\n  <li>Cottage Cheese</li>\r\n  <li>Thunderball (Rough Mix)</li>\r\n  <li>What The World Needs Now Is Love</li>\r\n  <li>Goddammit I Love America!</li>\r\n  <li>Retrovertigo</li>\r\n  <li>Sweet Charity</li>\r\n  <li>None Of Them Knew They Were Robots</li>\r\n  <li>The Air-Conditioned Nightmare</li>\r\n  <li>Creeping Death (Live)</li>\r\n  <li>Drug Me</li>\r\n  <li>Feel For You</li>\r\n  <li>Actual Recording</li>\r\n  <li>Mr. T Shot Tupac</li>\r\n  <li>Nothing Compares 2 U</li>\r\n  <li>Parents Were Little Once Too</li>\r\n  <li>Pee Wee Herman Theme (Ska Version)</li>\r\n  <li>Raping Your Mind</li>\r\n  <li>Romanian Song</li>\r\n  <li>Squeeze Me Macaroni</li>\r\n  <li>Star Wars Medley (Live)</li>\r\n  <li>State Opression (Raw Power)</li>\r\n  <li>Welcome Back Kotter</li>\r\n  <li>Zelda Theme (Ska Version)</li>\r\n  <li>Yardbird Suite</li>\r\n  <li>Wicked Game (Live)</li>\r\n  <li>Evil Satan</li>\r\n  <li>Drug Me</li>\r\n  <li>California</li>\r\n  <li>Super Mario Brothers Theme (Ska Version)</li>\r\n</ol>'),
(30, 1, 'MP3', 'My Life With The Thrill Kill Kult', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>After The Flesh</li>\r\n  <li>Days Of Swine And Roses</li>\r\n  <li>I Live For Drugs</li>\r\n  <li>Sex On Wheelz</li>\r\n  <li>Kooler Than Jesus</li>\r\n</ol>'),
(31, 1, 'MP3', 'Nine Inch Nails', 'Downward Spiral', 'none.jpg', '<ol>\r\n  <li>Mr. Self Destruct</li>\r\n  <li>Piggy</li>\r\n  <li>Heresy</li>\r\n  <li>March Of The Pigs</li>\r\n  <li>Closer</li>\r\n  <li>Ruiner</li>\r\n  <li>The Becoming</li>\r\n  <li>I Do Not Want This</li>\r\n  <li>Big Man With A Gun</li>\r\n  <li>A Warm Place</li>\r\n  <li>Eraser</li>\r\n  <li>Reptile</li>\r\n  <li>The Downward Spiral</li>\r\n  <li>Hurt</li>\r\n</ol>'),
(32, 1, 'MP3', 'Nine Inch Nails', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>I\\\'m Afraid Of Americans</li>\r\n  <li>Freak On A Leash</li>\r\n  <li>Like A Virgin</li>\r\n  <li>Dead Souls</li>\r\n  <li>Deep</li>\r\n  <li>Fuck You Like An Animal</li>\r\n  <li>Head Like A Hole</li>\r\n  <li>My Own Summer</li>\r\n  <li>Sanctified</li>\r\n  <li>Something I Can Never Have</li>\r\n  <li>Starfuckers, Inc.</li>\r\n  <li>The Big Come Down</li>\r\n  <li>The Perfect Drug</li>\r\n</ol>'),
(33, 1, 'MP3', 'Oysterhead', 'October 27, 2001 - The Hollywood Palladium', 'none.jpg', '<ol>\r\n  <li>Intro</li>\r\n  <li>Oysterhead</li>\r\n  <li>Inspiration</li>\r\n  <li>Les Blab 1</li>\r\n  <li>Instrumental</li>\r\n  <li>Rubberneck</li>\r\n  <li>Les Blab 2</li>\r\n  <li>Owner Jam</li>\r\n  <li>Owner Of The World</li>\r\n  <li>Instrumental</li>\r\n  <li>Wildwood Weed</li>\r\n  <li>Sinkin\\\' Down</li>\r\n  <li>Les Blab 3</li>\r\n  <li>Suicide</li>\r\n  <li>Jerry Was A Race Car Driver</li>\r\n  <li>Space Jam</li>\r\n  <li>Immagrant Song</li>\r\n  <li>Isreallites</li>\r\n  <li>All Day</li>\r\n  <li>Rising Sun</li>\r\n</ol>'),
(34, 1, 'CD', 'Oysterhead', 'The Grand Pecking Order', 'oysterheadGrand.jpg', '<ol>\r\n  <li>Little Faces</li>\r\n  <li>Oz Is Ever Floating</li>\r\n  <li>Mr. Oysterhead</li>\r\n  <li>Shadown Of A Man</li>\r\n  <li>Radon Balloon</li>\r\n  <li>Army\\\'s On Ecstasy</li>\r\n  <li>Rubberneck Lions</li>\r\n  <li>Polka Dot Rose</li>\r\n  <li>Birthday Boys</li>\r\n  <li>Wield The Spade</li>\r\n  <li>Pseudo Suicide</li>\r\n  <li>The Grand Pecking Order</li>\r\n  <li>Owner Of The World</li>\r\n</ol>'),
(35, 1, 'MP3', 'Pete Yorn', 'Music For The Morning After', 'none.jpg', '<ol>\r\n  <li>Life On A Chain</li>\r\n  <li>Strange Condition</li>\r\n  <li>Just Another</li>\r\n  <li>Black</li>\r\n  <li>Lose You</li>\r\n  <li>For Nancy</li>\r\n  <li>Murray</li>\r\n  <li>June</li>\r\n  <li>Sense</li>\r\n  <li>Closet</li>\r\n  <li>On Your Side</li>\r\n  <li>Sleep Better</li>\r\n  <li>EZ</li>\r\n  <li>Simonize</li>\r\n</ol>'),
(36, 1, 'MP3', 'David Gray', 'A Century Ends', 'none.jpg', '<ol>\r\n  <li>Shine</li>\r\n  <li>A Century Ends</li>\r\n  <li>Debauchery</li>\r\n  <li>Let The Truth Sting</li>\r\n  <li>Gathering Dust</li>\r\n  <li>Wisdom</li>\r\n  <li>Lead Me Upstairs</li>\r\n  <li>Living Room</li>\r\n  <li>Birds Without Wings</li>\r\n  <li>It\\\'s All Over</li>\r\n</ol>'),
(37, 1, 'MP3', 'Jack Johnson', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>F-Stop Blues</li>\r\n  <li>Bubble Toes</li>\r\n  <li>Flake</li>\r\n  <li>Fortunate Fool</li>\r\n  <li>Middle Man</li>\r\n  <li>Mudfootball</li>\r\n  <li>Posters</li>\r\n  <li>Sexi Plexi</li>\r\n  <li>Stars</li>\r\n  <li>Steel Guitar Rag</li>\r\n  <li>The News</li>\r\n  <li>Think Clearly</li>\r\n  <li>Walk Alone</li>\r\n</ol>'),
(38, 1, 'MP3', 'Gorillaz', 'Gorillaz', 'none.jpg', '<ol>\r\n  <li>Re-Hash</li>\r\n  <li>5/4</li>\r\n  <li>Tomorrow Comes Today</li>\r\n  <li>New Genious (Brother)</li>\r\n  <li>Clint Eastwood</li>\r\n  <li>Man Research (Clapper)</li>\r\n  <li>Punk</li>\r\n  <li>Sound Check (Gravity)</li>\r\n  <li>Double Bass</li>\r\n  <li>Rock The House</li>\r\n  <li>19-2000</li>\r\n  <li>Latin Simone (Que Pasa Contigo)</li>\r\n  <li>Starshine</li>\r\n  <li>Slow Country</li>\r\n  <li>M1 A1</li>\r\n</ol>'),
(39, 1, 'MP3', 'Keller Williams', 'Breathe', 'none.jpg', '<ol>\r\n  <li>Stupid Questions</li>\r\n  <li>Brunette</li>\r\n  <li>Breathe</li>\r\n  <li>Best Feeling</li>\r\n  <li>Bounty Hunter</li>\r\n  <li>Vacate</li>\r\n  <li>Roshambo</li>\r\n  <li>Revelation</li>\r\n  <li>Lightning</li>\r\n  <li>Blatant Ripoff</li>\r\n  <li>Not Of This Earth</li>\r\n  <li>Rockumal</li>\r\n  <li>Callalloo And Red Snapper</li>\r\n</ol>'),
(40, 1, 'MP3', 'Keller Williams', 'Loop', 'none.jpg', '<ol>\r\n  <li>Thin Mint</li>\r\n  <li>Kiwi And The Apricot</li>\r\n  <li>More Than A Little</li>\r\n  <li>Vacate</li>\r\n  <li>Blatant Ripoff</li>\r\n  <li>Kidney In A Cooler</li>\r\n  <li>Landlord</li>\r\n  <li>Turn In Difference</li>\r\n  <li>No Hablo Espanol</li>\r\n  <li>Rockumal</li>\r\n  <li>Stupid Questions</li>\r\n  <li>Inhale To The Chief</li>\r\n  <li>Nomini</li>\r\n</ol>'),
(41, 1, 'MP3', 'Uncle Kracker', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Whiskey & Water</li>\r\n  <li>Follow Me</li>\r\n  <li>Mr. Hawkins</li>\r\n  <li>Split This Room In Half</li>\r\n  <li>Yeah, Yeah, Yeah</li>\r\n</ol>'),
(42, 1, 'CD', 'Primus', 'Antipop', 'primusAntipop.jpg', '<ol>\r\n  <li>Intro</li>\r\n  <li>Electric Uncle Sam</li>\r\n  <li>Natural Joe</li>\r\n  <li>Laquer Head</li>\r\n  <li>The Antipop</li>\r\n  <li>Eclectic Electric</li>\r\n  <li>Greet The Sacred Cow</li>\r\n  <li>Mama Didn\\\'t Raise No Fool</li>\r\n  <li>Dirty Drowning Man</li>\r\n  <li>Ballad Of Bodacious</li>\r\n  <li>Power Mad</li>\r\n  <li>The Final Voyage Of The Liquid Sky</li>\r\n  <li>Coattails Of A Dead Man</li>\r\n</ol>'),
(43, 1, 'CD', 'Primus', 'Miscellaneous Debris', 'primusDebris.jpg', '<ol>\r\n  <li>Intruder</li>\r\n  <li>Making Plans For Nigel</li>\r\n  <li>Sinister Exaggerator</li>\r\n  <li>Tippi Toes</li>\r\n  <li>Have A Cigar</li>\r\n</ol>'),
(44, 1, 'CD', 'Primus', 'Pork Soda', 'primusPorkSoda.jpg', '<ol>\r\n  <li>Pork Chop\\\'s Little Ditty</li>\r\n  <li>My Name Is Mud</li>\r\n  <li>Welcome To This World</li>\r\n  <li>Bob</li>\r\n  <li>DMV</li>\r\n  <li>The Ol\\\' Diamondback Sturgeon (Fisherman\\\'s Chronicles, Part 3)</li>\r\n  <li>Nature Boy</li>\r\n  <li>Wounded Knee</li>\r\n  <li>Pork Soda</li>\r\n  <li>The Pressman</li>\r\n  <li>Mr. Krinkle</li>\r\n  <li>The Air Is Getting Slippery</li>\r\n  <li>Hamburger Train</li>\r\n  <li>Pork Chop\\\'s Little Ditty</li>\r\n  <li>Hail Santa</li>\r\n</ol>'),
(45, 1, 'CD', 'Primus', 'Suck On This', 'primusSuck.jpg', '<ol>\r\n  <li>John The Fisherman</li>\r\n  <li>Groundhog\\\'s Day</li>\r\n  <li>The Heckler</li>\r\n  <li>Pressman</li>\r\n  <li>Jellikit</li>\r\n  <li>Tommy The Cat</li>\r\n  <li>Pudding Time</li>\r\n  <li>Harold Of The Rocks</li>\r\n  <li>Frizzle Fry</li>\r\n</ol>'),
(46, 1, 'CD', 'Primus', 'Sailing The Seas Of Cheese', 'primusCheese.jpg', '<ol>\r\n  <li>Seas Of Cheese</li>\r\n  <li>Here Come The Bastards</li>\r\n  <li>Sgt. Baker</li>\r\n  <li>American Life</li>\r\n  <li>Jerry Was A Race Car Driver</li>\r\n  <li>Eleven</li>\r\n  <li>Is It Luck?</li>\r\n  <li>Grandad\\\'s Little Ditty</li>\r\n  <li>Tommy The Cat</li>\r\n  <li>Sathington Waltz</li>\r\n  <li>Those Damn Blue-Collar Tweekers</li>\r\n  <li>Fish On (Fisherman Chronicles, Part II)</li>\r\n  <li>Los Bastardos</li>\r\n</ol>'),
(47, 1, 'CD', 'Primus', 'Tales From The Punchbowl', 'primusTales.jpg', '<ol>\r\n  <li>Professor Nutbutter\\\'s House Of Treats</li>\r\n  <li>Mrs. Blaileen</li>\r\n  <li>Wynona\\\'s Big Brown Beaver</li>\r\n  <li>Southbound Pachyderm</li>\r\n  <li>Space Farm</li>\r\n  <li>Year Of The Parrot</li>\r\n  <li>Hellbound 17 1/2 (theme from)</li>\r\n  <li>Glass Sandwich</li>\r\n  <li>Del Davis Tree Farm</li>\r\n  <li>De Anza Jig</li>\r\n  <li>On The Tweek Again</li>\r\n  <li>Over The Electric Grapevine</li>\r\n  <li>Captain Shiner</li>\r\n</ol>');
# --------------------------------------------------------

#
# Table structure for table `musicentriespunk`
#

DROP TABLE IF EXISTS musicentriespunk;
CREATE TABLE musicentriespunk (
  musicEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  musicType text NOT NULL,
  artist text NOT NULL,
  album text NOT NULL,
  imageName text NOT NULL,
  tracks text NOT NULL,
  PRIMARY KEY  (musicEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `musicentriespunk`
#

INSERT INTO musicentriespunk (musicEntryId, publishFlag, musicType, artist, album, imageName, tracks) VALUES (1, 1, 'MP3', 'Lard', 'The Last Temptation of Reid', 'none.jpg', '<ol>\r\n  <li>Bozo Skeleton</li>\r\n  <li>Can God Fill Teeth</li>\r\n  <li>Drug Raid at 4 A.M.</li>\r\n  <li>Forkboy</li>\r\n  <li>I am Your Clock</li>\r\n  <li>Mate, Spawn & Die</li>\r\n  <li>Pineapple Face</li>\r\n  <li>Sylvestre Matuschka</li>\r\n  <li>They\\\'re Coming to Take Me Away</li>\r\n</ol>'),
(2, 1, 'MP3', 'Alient Ant Farm', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Movies</li>\r\n  <li>Flesh And Bone</li>\r\n  <li>Summer</li>\r\n  <li>Sticks And Stones</li>\r\n  <li>Stranded</li>\r\n  <li>Calico</li>\r\n  <li>Attitude</li>\r\n  <li>Universe</li>\r\n  <li>Wish</li>\r\n</ol>'),
(3, 1, 'MP3', 'Fugazi', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Give Me The Cure</li>\r\n  <li>Glue Man</li>\r\n  <li>Margin Walker</li>\r\n  <li>Waiting Room</li>\r\n</ol>'),
(4, 1, 'MP3', 'The Living End', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Freak Of The Week</li>\r\n  <li>Lone Ranger</li>\r\n  <li>Roll On</li>\r\n  <li>Sleep On It</li>\r\n  <li>Stay Away</li>\r\n  <li>Tainted Love (Live Cover)</li>\r\n  <li>Uncle Harry</li>\r\n  <li>Growing Up</li>\r\n</ol>'),
(5, 1, 'MP3', 'Archers of Loaf', 'Unknown', 'none.jpg', '<ol>\r\n  <li>I.N.S.</li>\r\n  <li>Nostalgia</li>\r\n  <li>Smoking Pot In The Hot City</li>\r\n  <li>Telepathic Traffic</li>\r\n</ol>'),
(6, 1, 'MP3', 'The Misfits', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Die, Die, Die My Darling</li>\r\n  <li>Helena</li>\r\n  <li>Hate Breeders</li>\r\n  <li>Mommy, Can I Go Out And Kill Tonight</li>\r\n  <li>Angelfuck</li>\r\n  <li>Cough Cool</li>\r\n  <li>Day Of The Dead</li>\r\n  <li>Hunting Humans</li>\r\n  <li>Hybrid Moments</li>\r\n  <li>Last Caress</li>\r\n  <li>Spinal Remains</li>\r\n  <li>London Dungeon</li>\r\n  <li>Monster Mash</li>\r\n  <li>Night Of The Living Dead</li>\r\n  <li>Pumpkin Head</li>\r\n  <li>Return Of The Fly</li>\r\n  <li>Teenagers From Mars</li>\r\n  <li>The Forbidden Zone</li>\r\n  <li>The Island Earth</li>\r\n  <li>Where Eagles Dare</li>\r\n  <li>Dig Up Her Bones</li>\r\n  <li>Rat Fink</li>\r\n</ol>'),
(7, 1, 'MP3', 'Pennywise', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Time Marches On</li>\r\n  <li>Land Of The Free</li>\r\n  <li>The World</li>\r\n  <li>Fuck Authority</li>\r\n  <li>Something Wrong</li>\r\n  <li>Enemy</li>\r\n  <li>My God</li>\r\n  <li>Twist Of Fate</li>\r\n  <li>Who\\\'s On Your Side</li>\r\n  <li>It\\\'s Up To You</li>\r\n  <li>Divine Intervention</li>\r\n  <li>WTO</li>\r\n  <li>Anyone Listening</li>\r\n</ol>'),
(8, 1, 'MP3', 'The Sex Pistols', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>C\\\'mon Everybody</li>\r\n  <li>Anarchy In The U.K.</li>\r\n  <li>New York</li>\r\n  <li>Big Tits Across America</li>\r\n  <li>EMI</li>\r\n  <li>Holidays In The Sun</li>\r\n  <li>I\\\'m Not Your Stepping Stone</li>\r\n  <li>Johnny B. Good</li>\r\n  <li>Liar</li>\r\n  <li>Pretty Vacant</li>\r\n  <li>Punk Rock Christmas</li>\r\n  <li>Seventeen</li>\r\n  <li>Submission</li>\r\n  <li>Swindle</li>\r\n  <li>I Did It My Way (Sid Vicious)</li>\r\n</ol>'),
(9, 1, 'MP3', 'Punk', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Handsome Devil - Makin\\\' Money</li>\r\n  <li>A New Found Glory - Dressed To Kill</li>\r\n  <li>A New Found Glory - Hit Or Miss</li>\r\n  <li>A New Found Glory - Back That Ass Up</li>\r\n  <li>Ahmet And Dweezil Zappa - Baby One More Time (Britney Spears Cover)</li>\r\n  <li>The Anti-Heros - I\\\'m A Rock \\\'n\\\' Roll Nigger</li>\r\n  <li>The Anti-Heros - White Riot</li>\r\n  <li>The Anti-Heros - Catch 22</li>\r\n  <li>CIV - Can\\\'t Wait One Minute More</li>\r\n  <li>Crown Of Thornz - Unemployed</li>\r\n  <li>The Dead Milkmen - Bithcin\\\' Camaro</li>\r\n  <li>The Dead Kennedys - Nazi Punks Fuck Off</li>\r\n  <li>The Dead Kennedys - Viva Las Vegas</li>\r\n  <li>Gob - I Hear You Calling</li>\r\n  <li>Godhead - Break You Down</li>\r\n  <li>Goldfinger - Mable</li>\r\n  <li>Henry Rollins Band - Liar</li>\r\n  <li>Jimmy Eat World - Bleed American</li>\r\n  <li>Kittie - Brackish</li>\r\n  <li>Kurt Cobain with Mudhoney - The Money Will Roll Right In</li>\r\n  <li>Linkin Park - Crawling</li>\r\n  <li>Mest - Cadillac</li>\r\n  <li>MXPX - I\\\'m OK, You\\\'re OK</li>\r\n  <li>MXPX - Punk Rock Show</li>\r\n  <li>The Pilfers - Agua</li>\r\n  <li>Prime STH - I\\\'m Stupid</li>\r\n  <li>Puddle Of Mudd - Control</li>\r\n  <li>Saliva - Click, Click Boom</li>\r\n  <li>Seventeen - Porno Getaway</li>\r\n  <li>The Suicidal Tendencies - Institutionalized</li>\r\n  <li>System Of A Down - Chop Suey</li>\r\n  <li>System Of A Down - Johnny</li>\r\n  <li>The Ramones - I Wanna Be Sedated</li>\r\n  <li>The Warlock Pinchers - Morrisse</li>\r\n</ol>'),
(10, 1, 'MP3', 'Front Line Assembly', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Body Count (Live)</li>\r\n  <li>Circuitry</li>\r\n  <li>Columbian Necktie</li>\r\n  <li>Digital Tension</li>\r\n  <li>Division Of Mind</li>\r\n  <li>Epidemic</li>\r\n  <li>Internal Combustion</li>\r\n  <li>Millennium</li>\r\n  <li>Mindphaser</li>\r\n  <li>Neologic Spasm (Dislocated)</li>\r\n  <li>Plasticity (Zero)</li>\r\n  <li>Predator</li>\r\n  <li>Search And Destroy</li>\r\n  <li>Toxic</li>\r\n  <li>Victim Of A Criminal</li>\r\n</ol>'),
(11, 1, 'MP3', 'Front 242', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Head Hunter</li>\r\n  <li>Until Death</li>\r\n  <li>Body To Body</li>\r\n  <li>Crapage</li>\r\n  <li>Funkahdafi</li>\r\n  <li>I\\\'m Rhythmus Bleiben</li>\r\n  <li>Junkdrome</li>\r\n  <li>Melt</li>\r\n  <li>No Shuffle</li>\r\n  <li>Overland</li>\r\n  <li>Quite Unusual</li>\r\n  <li>Religion</li>\r\n  <li>Soul Manager</li>\r\n  <li>Take One</li>\r\n  <li>Welcome To Paradise</li>\r\n</ol>'),
(12, 1, 'MP3', 'Blink 182', 'Enema Of The State', 'none.jpg', '<ol>\r\n  <li>Dumpweed</li>\r\n  <li>Don\\\'t Leave Me</li>\r\n  <li>Aliens Exist</li>\r\n  <li>Going Away To College</li>\r\n  <li>What\\\'s My Age Again</li>\r\n  <li>Dysentery Gary</li>\r\n  <li>Adam\\\'s Song</li>\r\n  <li>All The Small Things</li>\r\n  <li>The Party Song</li>\r\n  <li>Mutt</li>\r\n  <li>Wendy Clear</li>\r\n  <li>Anthem</li>\r\n</ol>'),
(13, 1, 'MP3', 'Coal Chamber', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Notion</li>\r\n  <li>Loco</li>\r\n  <li>Bradley</li>\r\n  <li>Oddity</li>\r\n  <li>Unspoiled</li>\r\n  <li>Big Truck</li>\r\n  <li>Sway</li>\r\n  <li>First</li>\r\n  <li>I</li>\r\n  <li>Clock</li>\r\n  <li>My Frustration</li>\r\n  <li>Dreamtime</li>\r\n  <li>Pig</li>\r\n</ol>'),
(14, 1, 'CD', 'Godflesh', 'Pure', 'godfleshPure.jpg', '<ol>\r\n  <li>Spite</li>\r\n  <li>Mothra</li>\r\n  <li>I Wasn\\\'t Born To Follow</li>\r\n  <li>Predominance</li>\r\n  <li>Pure</li>\r\n  <li>Monotremata</li>\r\n  <li>Baby Blue Eyes</li>\r\n  <li>Don\\\'t Bring Me Flowers</li>\r\n  <li>Love, Hate (Slugbaiting)</li>\r\n  <li>Pure II</li>\r\n</ol>'),
(15, 1, 'MP3', 'Green Day', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Geek Stink Breath</li>\r\n  <li>Brain Stew</li>\r\n  <li>Good Riddance</li>\r\n</ol>'),
(16, 1, 'CD', 'Helmet', 'Meantime', 'helmetMeantime.jpg', '<ol>\r\n  <li>In The Meantime</li>\r\n  <li>Ironhead</li>\r\n  <li>Give It</li>\r\n  <li>Unsung</li>\r\n  <li>Turned Out</li>\r\n  <li>He Feels Bad</li>\r\n  <li>Better</li>\r\n  <li>You Borrowed</li>\r\n  <li>FBLA II</li>\r\n  <li>Role Model</li>\r\n</ol>');
# --------------------------------------------------------

#
# Table structure for table `musicentriesrap`
#

DROP TABLE IF EXISTS musicentriesrap;
CREATE TABLE musicentriesrap (
  musicEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  musicType text NOT NULL,
  artist text NOT NULL,
  album text NOT NULL,
  imageName text NOT NULL,
  tracks text NOT NULL,
  PRIMARY KEY  (musicEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `musicentriesrap`
#

INSERT INTO musicentriesrap (musicEntryId, publishFlag, musicType, artist, album, imageName, tracks) VALUES (1, 1, 'MP3', 'Afroman', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Back to School</li>\r\n  <li>Afroman Is Coming</li>\r\n  <li>Colt 45</li>\r\n  <li>Crazy Rap</li>\r\n  <li>Girls</li>\r\n  <li>Hush</li>\r\n  <li>Mississippi Rap</li>\r\n  <li>Paranoid</li>\r\n  <li>Sell Your Dope</li>\r\n  <li>She Won\\\'t Let Me</li>\r\n  <li>Lets All Get Drunk</li>\r\n</ol>'),
(2, 1, 'MP3', 'Beat Nuts', 'Unknown', 'none.jpg', '<ol>\r\n  <li>Mayonnaise</li>\r\n  <li>Beat Nuts Forever</li>\r\n  <li>Folk\\\'n Beat</li>\r\n  <li>Hardcore</li>\r\n  <li>Se Acabo</li>\r\n</ol>'),
(3, 1, 'MP3', 'DMX', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>It\\\'s All Good (Fuck All Day, Fuck All Night)</li>\r\n  <li>Ruff Rider\\\'s Anthem</li>\r\n  <li>What These Bitches Want From A Nigga</li>\r\n  <li>What\\\'s My Name</li>\r\n  <li>Where My Dogs At</li>\r\n  <li>Party Up</li>\r\n  <li>Grand Finale</li>\r\n  <li>Niggas Die For Me</li>\r\n</ol>'),
(4, 1, 'MP3', 'KRS1', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Illegal Business</li>\r\n  <li>That\\\'s Not Hot</li>\r\n  <li>KRS1 Attacks</li>\r\n  <li>Step Into Our World</li>\r\n  <li>Blade</li>\r\n</ol>'),
(5, 1, 'MP3', 'Method Man', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Bring The Pain (Chemical Brothers Remix)</li>\r\n  <li>Bullworth</li>\r\n  <li>How High</li>\r\n  <li>Tear Da Roof Off</li>\r\n  <li>Fire In A Hole</li>\r\n  <li>Make-ups To Break-ups</li>\r\n  <li>M-E-T-H-O-D</li>\r\n  <li>The Riddler</li>\r\n  <li>Belly</li>\r\n  <li>Pussy Pop</li>\r\n  <li>Da Rockwilder</li>\r\n  <li>Shut The Fuck Up (with Limp Bizkit)</li>\r\n  <li>Rollin (with Limp Bizkit)</li>\r\n</ol>'),
(6, 1, 'MP3', 'Nelly', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Batter Up</li>\r\n  <li>Country Grammar</li>\r\n  <li>E.I.</li>\r\n  <li>Here We Come</li>\r\n  <li>Other Side</li>\r\n  <li>Ride With Me</li>\r\n  <li>St. Louie</li>\r\n  <li>Thicky Thick Girl</li>\r\n  <li>Lovin\\\' Me</li>\r\n  <li>Midwest Swing</li>\r\n</ol>'),
(7, 1, 'MP3', 'Rap', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Big Pun & Fat Joe - Still Not A Player</li>\r\n  <li>Big Tymers - Get Your Roll</li>\r\n  <li>Mary J. Blige - Everything</li>\r\n  <li>Craig Mack - Vibin\\\'</li>\r\n  <li>Busta Rhymes - Tear Da Roof Off</li>\r\n  <li>Busta Rhymes - Why We Die</li>\r\n  <li>Busta Rhymes - Woo Ha! (Got You All In Check)</li>\r\n  <li>Dr. Dre & Snoop Doggy Dogg - Nothing But A G Thang</li>\r\n  <li>Eve - Scenario 2000</li>\r\n  <li>Eve & Nokio - What Y\\\'all Niggas Want</li>\r\n  <li>Funkmaster Flex, Killah Sin - Cream Team</li>\r\n  <li>Insane Clown Posse - Bitches</li>\r\n  <li>Insane Clown Posse - Halls Of Illusions</li>\r\n  <li>Insane Clown Posse - Hokus Pokus</li>\r\n  <li>Insane Clown Posse - I Want My Shit</li>\r\n  <li>Insane Clown Posse - Santa\\\'s A Fat Bitch</li>\r\n  <li>Ja Rule - Every Little Thing That We Do</li>\r\n  <li>Ja Rule - Holla, Holla</li>\r\n  <li>Ja Rule - It\\\'s Murda</li>\r\n  <li>Ja Rule - Always On Time</li>\r\n  <li>Ja Rule - Between Me And You</li>\r\n  <li>Ja Rule - Put It On Me</li>\r\n  <li>Juvenile - Be Quiet</li>\r\n  <li>Juvenile - Down Bottom</li>\r\n  <li>Juvenile - Ya\\\' Understand</li>\r\n  <li>Lil Kim - How Many Licks</li>\r\n  <li>Lil Wayne - Tha Block Is Ho</li>\r\n  <li>Luniz - I Got Five On It</li>\r\n  <li>Nas - Oochie Wally</li>\r\n  <li>NWA - Dopeman</li>\r\n  <li>NWA - Express Yourself</li>\r\n  <li>NWA - Straight Outta Compton</li>\r\n  <li>Public Enemy - Survival</li>\r\n  <li>Slick Rick - Indian Girl (Adult Story)</li>\r\n  <li>Snoop Doggy Dogg - Gin & Juice</li>\r\n  <li>Snoop Doggy Dogg - What\\\'s My Name</li>\r\n  <li>Snoop Doggy Dogg - Lay Low</li>\r\n  <li>Trick Daddy - Shut Up</li>\r\n  <li>Tupac - Thugz At Arms</li>\r\n  <li>Twiztid - What The Fuck</li>\r\n  <li>Onyx - Evil Streets</li>\r\n</ol>'),
(8, 1, 'MP3', 'Cypress Hill', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Maryjane</li>\r\n  <li>I Want To Get High</li>\r\n  <li>Rap Superstar</li>\r\n  <li>Stoned Is The Way Of The Walk</li>\r\n  <li>Hits From The Bong</li>\r\n  <li>Insane In The Brain</li>\r\n  <li>Roll It Up. Light It Up. Smoke It Up.</li>\r\n</ol>'),
(9, 1, 'MP3', 'Jay-Z', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Heart Of The City</li>\r\n  <li>Big Pimpin\\\'</li>\r\n  <li>Can I Get A Fuck You</li>\r\n  <li>H To The Izzo</li>\r\n  <li>Jigga My Nigga</li>\r\n  <li>Can I Get A What What</li>\r\n  <li>Girls Best Friend</li>\r\n</ol>');
# --------------------------------------------------------

#
# Table structure for table `musicentriesrock`
#

DROP TABLE IF EXISTS musicentriesrock;
CREATE TABLE musicentriesrock (
  musicEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  musicType text NOT NULL,
  artist text NOT NULL,
  album text NOT NULL,
  imageName text NOT NULL,
  tracks text NOT NULL,
  PRIMARY KEY  (musicEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `musicentriesrock`
#

INSERT INTO musicentriesrock (musicEntryId, publishFlag, musicType, artist, album, imageName, tracks) VALUES (1, 1, 'MP3', 'Metallica', 'Master of Puppets', 'none.jpg', '<ol>\r\n  <li>Battery</li>\r\n  <li>Damage, Inc.</li>\r\n  <li>Disposable Heroes</li>\r\n  <li>Leper Messiah</li>\r\n  <li>Master of Puppets</li>\r\n  <li>Orion</li>\r\n  <li>The Thing That Should Not Be</li>\r\n  <li>Welcome Home (Sanitarium)</li>\r\n</ol>'),
(2, 1, 'MP3', 'Fun Lovin\\\' Criminals', 'Unknown', 'none.jpg', '<ol>\r\n  <li>The Fun Lovin\\\' Criminal</li>\r\n  <li>King Of New York</li>\r\n  <li>Scooby Snacks</li>\r\n</ol>'),
(3, 1, 'MP3', 'Lenny Kravitz', 'Greatest Hits', 'none.jpg', '<ol>\r\n  <li>Are You Gonna Go My Way</li>\r\n  <li>Fly Away</li>\r\n  <li>Rock And Roll Is Dead</li>\r\n  <li>Again</li>\r\n  <li>It Ain\\\'t Over Til It\\\'s Over</li>\r\n  <li>Can\\\'t Get You Off My Mind</li>\r\n  <li>Mr. Cab Driver</li>\r\n  <li>American Woman</li>\r\n  <li>Stand By My Woman</li>\r\n  <li>Always On The Run</li>\r\n  <li>Heaven Help</li>\r\n  <li>I Belong To You</li>\r\n  <li>Believe</li>\r\n  <li>Let Love Rule</li>\r\n  <li>Black Velveteen</li>\r\n</ol>'),
(4, 1, 'MP3', 'Monster Magnet', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>See You In Hell</li>\r\n  <li>Look To Your Orb For The Warning</li>\r\n  <li>Silver Future</li>\r\n  <li>Powertrip</li>\r\n  <li>Space Lord</li>\r\n  <li>Into The Void</li>\r\n  <li>Negasonic Teenage Warhead</li>\r\n</ol>'),
(5, 1, 'MP3', 'Metallica', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Free Speech For The Dumb</li>\r\n  <li>It\\\'s Electric</li>\r\n  <li>Killing Time</li>\r\n  <li>Stone Cold Crazy</li>\r\n  <li>Helpless</li>\r\n  <li>Am I Evil</li>\r\n  <li>Blitzkrieg</li>\r\n  <li>Breadfan</li>\r\n  <li>Last Caress (Green Hell)</li>\r\n  <li>The Four Horsemen</li>\r\n  <li>The Prince</li>\r\n</ol>'),
(6, 1, 'MP3', 'Nirvana', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Machine Head (Bush Cover)</li>\r\n  <li>Blandest</li>\r\n  <li>Come As You Are</li>\r\n  <li>Drain You</li>\r\n  <li>Half The Man I Used To Be</li>\r\n  <li>Heart Shaped Box</li>\r\n  <li>I Hate Myself And Want To Die</li>\r\n  <li>In Bloom</li>\r\n  <li>Mrs. Robinson (Beatles Cover)</li>\r\n  <li>Plateau</li>\r\n  <li>The Man Who Sold The World</li>\r\n  <li>On A Plain</li>\r\n</ol>'),
(7, 1, 'MP3', 'Onion', 'Scream Of Consciousness', 'none.jpg', '<ol>\r\n  <li>A Fragment Of Our Troubles</li>\r\n  <li>A Fragment Of Disbelief</li>\r\n  <li>All Swollen</li>\r\n  <li>Angst (To Think And Act Like God)</li>\r\n  <li>Anodyne</li>\r\n  <li>Blue Maroon</li>\r\n  <li>Downward</li>\r\n  <li>Headwalking</li>\r\n  <li>In The Future</li>\r\n  <li>Marie</li>\r\n  <li>Not The Same</li>\r\n  <li>Sister</li>\r\n  <li>Song Of The Woodroach</li>\r\n  <li>Stranger</li>\r\n  <li>Termites</li>\r\n</ol>'),
(8, 1, 'MP3', 'Rage Against The Machine', 'Renegade Of Funk', 'rageRenegades.jpg', '<ol>\r\n  <li>Microphone Fiend</li>\r\n  <li>Pistolgrip Pump</li>\r\n  <li>Kick Out The Jams</li>\r\n  <li>Renegades Of Funk</li>\r\n  <li>Beautiful World</li>\r\n  <li>I\\\'m Housin\\\'</li>\r\n  <li>In My Eyes</li>\r\n  <li>How I Could Just Kill A Man</li>\r\n  <li>Ghost Of Tom Joad</li>\r\n  <li>Down On The Street</li>\r\n  <li>Street Fighting Man</li>\r\n  <li>Maggie\\\'s Farm</li>\r\n  <li>(Untitled Track 1)</li>\r\n  <li>(Untitled Track 2)</li>\r\n</ol>'),
(9, 1, 'MP3', 'Rock', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Blues Traveler - I Want To Take You Higher</li>\r\n  <li>Deicide - Kill The Christian</li>\r\n  <li>Disturbed - Stupify</li>\r\n  <li>Disturbed - Down With The Sickness</li>\r\n  <li>Eve 6 - Inside Out</li>\r\n  <li>Lemonheads - Mrs. Robinson</li>\r\n  <li>Marliyn Manson - Dogma</li>\r\n  <li>Marliyn Manson - Dope Show</li>\r\n  <li>Megadeath - Symphony Of Destruction</li>\r\n  <li>Obituary - Find The Arise</li>\r\n  <li>Obituary - Slowly We Rot</li>\r\n  <li>Obituary - Threatening Skies</li>\r\n  <li>Offspring - Total Immortal</li>\r\n  <li>Powerman 5000 - Nobody\\\'s Real</li>\r\n  <li>Powerman 5000 - When Worlds Collide</li>\r\n  <li>Presidents Of The United States Of America - Dune Buggy</li>\r\n  <li>Presidents Of The United States Of America - Lump</li>\r\n  <li>Presidents Of The United States Of America - Peaches</li>\r\n  <li>Slipknot - My Plauge</li>\r\n  <li>Rob Zombie - Dragula</li>\r\n  <li>Saliva - Click, Click Boom</li>\r\n  <li>Slipknot - Left Behind</li>\r\n  <li>Slipknot - Wait And Bleed</li>\r\n  <li>Social Distortion - Making Believe</li>\r\n  <li>Stabbing Westward - You Complete Me</li>\r\n  <li>Staind - Mudshovel</li>\r\n  <li>Static X - Bled For Days</li>\r\n  <li>Toadies - Sweet Angel</li>\r\n  <li>Toadies - Possum Kingdom</li>\r\n</ol>'),
(10, 1, 'MP3', 'Weezer', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Dukes Of Hazzard Theme Song</li>\r\n  <li>Smile</li>\r\n  <li>I Just Threw Out The Love Of My Dreams</li>\r\n  <li>Island In The Sun</li>\r\n  <li>Dope Nose</li>\r\n  <li>Fall Together</li>\r\n  <li>Serendipity</li>\r\n  <li>Hit Me Baby One More Time (Britney Spears Cover)</li>\r\n  <li>No One Else</li>\r\n  <li>Rivers</li>\r\n  <li>Say It Ain\\\'t So</li>\r\n  <li>Surf Wax America</li>\r\n  <li>Susanne</li>\r\n  <li>Photograph</li>\r\n  <li>Crab</li>\r\n  <li>Knock Down Drag Out</li>\r\n  <li>Glorious Day</li>\r\n  <li>O Lisa</li>\r\n  <li>Hash Pipe</li>\r\n  <li>Velouria</li>\r\n  <li>El Scorcho</li>\r\n  <li>Buddy Holly</li>\r\n</ol>'),
(11, 1, 'MP3', 'Slayer', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Bloodline</li>\r\n  <li>Angel Of Death</li>\r\n  <li>Here Comes The Pain</li>\r\n  <li>In A Gadda Da Vida</li>\r\n  <li>Raining Blood</li>\r\n  <li>War Ensemble</li>\r\n  <li>Seasons In The Abyss</li>\r\n  <li>Sick Boy</li>\r\n  <li>Mandatory Suicide</li>\r\n  <li>Dissident Aggressor</li>\r\n  <li>South Of Heaven</li>\r\n  <li>Stain Of Mind</li>\r\n</ol>'),
(12, 1, 'MP3', 'Skinny Puppy', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Crapage</li>\r\n  <li>Dig It</li>\r\n  <li>Fritter (Stella\\\'s Home)</li>\r\n  <li>Hospital Waste</li>\r\n  <li>Killing Game</li>\r\n  <li>Nature\\\'s Revenge</li>\r\n  <li>Negativeland</li>\r\n  <li>Spasmolytic</li>\r\n  <li>TFWO</li>\r\n  <li>The Soul That Creates</li>\r\n  <li>Spahn Dirge</li>\r\n  <li>Tin Omen</li>\r\n  <li>Worlock</li>\r\n  <li>Dead Of Winter</li>\r\n  <li>Addiction</li>\r\n  <li>Assimilate</li>\r\n  <li>Deadlines</li>\r\n  <li>Haunted</li>\r\n  <li>La Human</li>\r\n  <li>Love In Vein</li>\r\n  <li>Morphedus</li>\r\n  <li>Ode Too Groovy</li>\r\n  <li>Smothered Hope</li>\r\n  <li>Testure</li>\r\n  <li>Who\\\'s Laughing Now</li>\r\n  <li>Serpants</li>\r\n  <li>Far Too Frail</li>\r\n</ol>'),
(13, 1, 'MP3', 'Guster', 'Lost & Gone Forever', 'gusterLost.jpg', '<ol>\r\n  <li>What You Wish For</li>\r\n  <li>Barrel Of A Gun</li>\r\n  <li>Either Way</li>\r\n  <li>Fa Fa</li>\r\n  <li>I Spy</li>\r\n  <li>Center Of Attention</li>\r\n  <li>All The Way Up To Heaven</li>\r\n  <li>Happier</li>\r\n  <li>So Long</li>\r\n  <li>Two Points For Honesty</li>\r\n  <li>Rainy Day</li>\r\n</ol>'),
(14, 1, 'MP3', 'Guster', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Do They Know It\\\'s Christmas</li>\r\n  <li>I Would Walk 500 Miles</li>\r\n  <li>50 Nifty United States</li>\r\n  <li>The Harder They Come</li>\r\n  <li>Celebrate Good Times</li>\r\n  <li>Cocoon</li>\r\n  <li>Everybody Else</li>\r\n  <li>Fall In Two</li>\r\n  <li>I Think We\\\'re Alone Now (Tiffany Cover)</li>\r\n  <li>Mona Lisa</li>\r\n  <li>Princeton SAT</li>\r\n  <li>Rocketship</li>\r\n  <li>Sweet Child Of Mine (Guns N Roses Cover)</li>\r\n  <li>Great Escape</li>\r\n  <li>Come On Eileen</li>\r\n  <li>Down In It (Nine Inch Nails Cover)</li>\r\n  <li>Stand By Me</li>\r\n</ol>'),
(15, 1, 'MP3', 'Jane\\\'s Addiction', 'Kettle Whistle', 'janesWhistle.jpg', '<ol>\r\n  <li>Kettle Whistle</li>\r\n  <li>Ocean Size</li>\r\n  <li>My Cat\\\'s Name Is Maceo</li>\r\n  <li>Had A Dad</li>\r\n  <li>So What!</li>\r\n  <li>Jane Says</li>\r\n  <li>Mountain Song</li>\r\n  <li>Slow Divers</li>\r\n  <li>Three Days</li>\r\n  <li>Ain\\\'t No Right</li>\r\n  <li>Up The Beach</li>\r\n  <li>Stop!</li>\r\n  <li>Been Caught Stealing</li>\r\n  <li>Whores</li>\r\n  <li>City</li>\r\n</ol>'),
(16, 1, 'MP3', 'Massive Attack', 'Blue Lines', 'massiveAttackBlueLines.jpg', '<ol>\r\n  <li>Safe From Harm</li>\r\n  <li>One Love</li>\r\n  <li>Blue Lines</li>\r\n  <li>Be Thankful For What You\\\'ve Got</li>\r\n  <li>Five Man Army</li>\r\n  <li>Unfinished Sympathy</li>\r\n  <li>Daydreaming</li>\r\n  <li>Lately</li>\r\n  <li>Hymn Of The Big Wheel</li>\r\n</ol>'),
(17, 1, 'MP3', 'Morphine', 'Miscellaneous', 'none.jpg', '<ol>\r\n  <li>Candy</li>\r\n  <li>Claire</li>\r\n  <li>Cure For Pain</li>\r\n  <li>I\\\'m Free Now</li>\r\n  <li>In Spite Of Me</li>\r\n  <li>Birthday Cake</li>\r\n  <li>The Saddest Song</li>\r\n  <li>Thursday</li>\r\n  <li>Whisper</li>\r\n  <li>You Look Like Rain</li>\r\n</ol>');
# --------------------------------------------------------

#
# Table structure for table `musicentriessoundtrack`
#

DROP TABLE IF EXISTS musicentriessoundtrack;
CREATE TABLE musicentriessoundtrack (
  musicEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  musicType text NOT NULL,
  artist text NOT NULL,
  album text NOT NULL,
  imageName text NOT NULL,
  tracks text NOT NULL,
  PRIMARY KEY  (musicEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `musicentriessoundtrack`
#

INSERT INTO musicentriessoundtrack (musicEntryId, publishFlag, musicType, artist, album, imageName, tracks) VALUES (1, 1, 'MP3', 'Good Will Hunting', 'Soundtrack', 'none.jpg', '<ol>\r\n  <li>Elliot Smith - Between the Bars (Orchestral)</li>\r\n  <li>Jeb Roy Nichols - As the Rain</li>\r\n  <li>Elliot Smith - Angeles</li>\r\n  <li>Elliot Smith - No Name #3</li>\r\n  <li>The Waterboys - Fisherman\\\'s Blues</li>\r\n  <li>Luscious Jackson - Why Do I Lie</li>\r\n  <li>Danny Elfman - Will Hunting (Main Title)</li>\r\n  <li>Elliot Smith - Between the Bars</li>\r\n  <li>Elliot Smith - Say Yes</li>\r\n  <li>Gerry Rafferty - Baker Street</li>\r\n  <li>Andru Donalds - Somebody\\\'s Baby</li>\r\n  <li>The Dandy Warhols - Boys Better</li>\r\n  <li>Al Green - How Can You Mend a Broken Heart</li>\r\n  <li>Elliot Smith - Miss Misery</li>\r\n  <li>Danny Elfman - Weepy Donuts</li>\r\n</ol>'),
(2, 1, 'MP3', 'Grosse Pointe Blanke', 'Soundtrack', 'none.jpg', '<ol>\r\n  <li>The Violent Femmes - Blister In the Sun</li>\r\n  <li>The Clash - Rudie Can\\\'t Fail</li>\r\n  <li>The English Beat - Mirror In the Bathroom</li>\r\n  <li>David Bowie and Queen - Under Pressure</li>\r\n  <li>Johnny Nash - I Can See Clearly Now</li>\r\n  <li>Guns N Roses - Live and Let Die</li>\r\n  <li>Faith No More - We Care a Lot</li>\r\n  <li>The Specials - Pressure Drop</li>\r\n  <li>The Jam - Absolute Beginners</li>\r\n  <li>The Clash - Armagideon Time</li>\r\n  <li>Los Fabulosos Cadillacs - El Matador</li>\r\n  <li>Pete Townsend - Let My Love Open the Door (E. Cola Mix)</li>\r\n  <li>Violent Femmes - Blister 2000</li>\r\n</ol>'),
(3, 1, 'MP3', 'Reservoir Dogs', 'Soundtrack', 'none.jpg', '<ol>\r\n  <li>And Now Little Green Bag (dialogue)</li>\r\n  <li>The George Baker Selection - Little Green Bag</li>\r\n  <li>Rock Flock of Five (dialogue)</li>\r\n  <li>Blue Swede - Hooked On a Feeling</li>\r\n  <li>Bohemiath (dialogue)</li>\r\n  <li>Joe Tex - I Gotcha</li>\r\n  <li>Bedlam - Magic Carpet Ride</li>\r\n  <li>Madonna Speech (dialogue)</li>\r\n  <li>Sandy Rogers - Fool For Love</li>\r\n  <li>Super Sounds (dialogue)</li>\r\n  <li>Stealers Wheel - Stuck In the Middle With You</li>\r\n  <li>Bedlam - Harvest Moon</li>\r\n  <li>Let\\\'s Get a Taco (dialogue)</li>\r\n  <li>Keep On Truckin\\\' (dialogue)</li>\r\n  <li>Harry Nilsson - Coconut</li>\r\n  <li>Home of Rock (dialogue)</li>\r\n</ol>'),
(4, 1, 'MP3', 'The Matrix', 'Soundtrack', 'none.jpg', '<ol>\r\n  <li>Marilyn Manson - Rock Is Dead</li>\r\n  <li>Propellerheads - Spybreak</li>\r\n  <li>Ministry - Bad Blood</li>\r\n  <li>Rob D - Clubbed To Death (Kurayamino mix)</li>\r\n  <li>Meat Beat Manifesto - Prime Audio Soup</li>\r\n  <li>Lunatic Calm - Leave You Far Behind (Lunatics Roller Coaster mix)</li>\r\n  <li>Prodigy - Mindfields</li>\r\n  <li>Rob Zombie - Dragula (Hot Rod Hermin remix)</li>\r\n  <li>Deftones - My Own Summer (Shove It)</li>\r\n  <li>Hive - Ultrasonic Sound</li>\r\n  <li>Monster Magnet - Look To Your Orb For The Warning</li>\r\n  <li>Rammstein - Du Hast</li>\r\n  <li>Rage Against The Machine - Wake Up</li>\r\n</ol>'),
(5, 1, 'MP3', 'Soundtracks', 'Miscellaneous', 'none.jpg', '<ul>\r\n  <li>American Pie 2\r\n    <ol>\r\n      <li>Left Front Tire - Bring You Down</li>\r\n      <li>3 Doors Down - Be Like That</li>\r\n      <li>Stroke 9 - Kick Some Ass</li>\r\n      <li>Sum 41 - Fat Lip</li>\r\n      <li>Fenix TX - Phoebe Cates</li>\r\n      <li>Uncle Kracker - Split This Room In Half</li>\r\n    </ol>\r\n  </li>\r\n  <li>Blade\r\n    <ol>\r\n      <li>Unknown - Techno Theme</li>\r\n      <li>Unknown - Struck By Lightening (remix)</li>\r\n    </ol>\r\n  </li>\r\n  <li>Buffy The Vampire Slayer\r\n    <ol>\r\n      <li>Nerf Herder - Soundtrack</li>\r\n    </ol>\r\n  </li>\r\n  <li>Commercials\r\n    <ol>\r\n      <li>The Volkswagon Trio - Dah Dah Dah</li>\r\n      <li>Volkswagon - Jetta Song</li>\r\n      <li>Wiseguys (Mitsubishi) - Body In Motion</li>\r\n    </ol>\r\n  </li>\r\n  <li>The Crow\r\n    <ol>\r\n      <li>My Life With The Thrill Kill Kult - After The Flesh</li>\r\n    </ol>\r\n  </li>\r\n  <li>The Fifth Element\r\n    <ol>\r\n      <li>Unknown - Little Light of Love</li>\r\n      <li>Unknown - Heat</li>\r\n    </ol>\r\n  </li>\r\n  <li>Gone In 60 Seconds\r\n    <ol>\r\n      <li>BT Featuring M. Doughty - Never Gonna Come Back Down</li>\r\n    </ol>\r\n  </li>\r\n  <li>Hackers\r\n    <ol>\r\n      <li>Orbital - Halcyon On On</li>\r\n    </ol>\r\n  </li>\r\n  <li>High Fidelity\r\n    <ol>\r\n      <li>The Velvet Underground - Oh! Sweet Nuttin\\\'</li>\r\n      <li>The Velvet Underground - Who Loves The Sun</li>\r\n    </ol>\r\n  </li>\r\n  <li>Joe Dirt\r\n    <ol>\r\n      <li>Unknown - Roller</li>\r\n      <li>Cheap Trick - If You Want My Love</li>\r\n      <li>Joe Walsh - Rocky Mountain High</li>\r\n      <li>Unknown - True Devotion</li>\r\n    </ol>\r\n  </li>\r\n  <li>Judgement Night\r\n    <ol>\r\n      <li>Unknown - Judgement Night</li>\r\n    </ol>\r\n  </li>\r\n  <li>Me, Myself, and Irene\r\n    <ol>\r\n      <li>Third Eye Blind - Deep Inside</li>\r\n      <li>Ellis Paul - The World Ain\\\'t Slowin\\\' Down</li>\r\n    </ol>\r\n  </li>\r\n  <li>Mission Impossible 2\r\n    <ol>\r\n      <li>Dream Theater - Mission Impossible Theme</li>\r\n      <li>Metallica - Mission Impossible Theme (Heavy Metal remix)</li>\r\n    </ol>\r\n  </li>\r\n  <li>Sliver\r\n    <ol>\r\n      <li>The Young Gods - Skinflowers</li>\r\n    </ol>\r\n  </li>\r\n  <li>Titan AE\r\n    <ol>\r\n      <li>Fun Lovin\\\' Criminals - Everything Under The Stars</li>\r\n    </ol>\r\n  </li>\r\n  <li>True Romance\r\n    <ol>\r\n      <li>Hans Zimmer - You\\\'re So Cool</li>\r\n    </ol>\r\n  </li>\r\n</ul>'),
(6, 1, 'MP3', 'Office Space', 'Soundtrack', 'none.jpg', '<ol>\r\n  <li>Canibus & Biz Markie - Shove This Jay-Oh-Bee</li>\r\n  <li>The Geto Boys - Damn It Feels Good To Be A Gangsta</li>\r\n  <li>Prodigy - Smack My Bitch Up</li>\r\n  <li>Afroman - Because I Got High</li>\r\n  <li>Butthole Surfers - Pepper</li>\r\n  <li>Dinosaur Jr. - Feel The Pain</li>\r\n  <li>Guns N Roses - I Used To Love Her</li>\r\n  <li>Iggy Pop - Lust For Life</li>\r\n  <li>Liz Phair - Flower</li>\r\n  <li>Samir Swearing (dialogue)</li>\r\n  <li>Nirvana - Territorial Pissings</li>\r\n  <li>No Talent Ass Clown (dialogue)</li>\r\n  <li>Oh Face (dialogue)</li>\r\n  <li>Each Day Is The Worst Day of My Life (dialogue)</li>\r\n  <li>PC Load Letter (dialogue)</li>\r\n  <li>People Skills (dialogue)</li>\r\n  <li>Pearl Jam - Nothing As It Seems</li>\r\n  <li>Primus - Wynona\\\'s Big Brown Beaver</li>\r\n  <li>Soundgarden - Rusty Cage</li>\r\n  <li>Train - Drops of Jupiter</li>\r\n</ol>');
# --------------------------------------------------------

#
# Table structure for table `myMovies`
#

DROP TABLE IF EXISTS myMovies;
CREATE TABLE myMovies (
  id int(11) NOT NULL auto_increment,
  catId int(11) NOT NULL default '1',
  movieTitle text NOT NULL,
  movieLength text NOT NULL,
  ratingId int(11) NOT NULL default '1',
  movieStars text NOT NULL,
  active text NOT NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table `myMovies`
#

INSERT INTO myMovies (id, catId, movieTitle, movieLength, ratingId, movieStars, active) VALUES (1, 9, 'Boiler Room', '120', 1, 'Giovanni Ribisi, Vin Diesel, Nia Long, Nicky Katt', '1'),
(2, 7, 'Blade', '120', 1, 'Wesley Snipes, Stephen Dorff', '1'),
(3, 1, 'Bad Boys', '119', 1, 'Will Smith, Martin Lawrence', '1'),
(4, 9, 'Assassins', '133', 1, 'Sylvester Stallone, Antonio Banderas', '1'),
(5, 4, 'Stuart Saves His Family', '97', 3, 'Al Franken, Laura San Giacomo', '1'),
(6, 4, 'Big Momma\\\'s House', '98', 3, 'Martin Lawrence', '1'),
(7, 4, 'Big Daddy', '93', 3, 'Adam Sandler', '1'),
(8, 4, 'The Big Lebowski', '98', 1, 'Jeff Bridges, John Goodman, Julianne Moore, Steve Buscemi, John Turturro', '1'),
(9, 3, 'Bed Of Roses', '88', 4, 'Christian Slater, Mary Stuart Masterson', '1'),
(10, 5, 'American Beauty', '122', 1, 'Kevin Spacey, Annette Bening', '1'),
(11, 1, 'Bait', '119', 1, 'Jamie Foxx', '1'),
(12, 4, 'Austin Powers: International Man Of Mystery', '90', 3, 'Mike Meyers, Elizabeth Hurley', '1'),
(13, 4, 'Analyze This', '104', 1, 'Robert Deniro, Billy Crystal, Lisa Kudrow', '1'),
(14, 5, 'Any Given Sunday', '157', 1, 'Al Pacino, Dennis Quaid, Jamie Foxx, Cameron Diaz, James Woods, LL Cool J', '1'),
(15, 4, 'Austin Powers: The Spy Who Shagged Me', '*', 3, 'Mike Meyers, Heather Graham', '1'),
(16, 5, 'The Bonfire Of The Vanities', '126', 1, 'Tom Hanks, Bruce Willis, Melanie Griffith', '1'),
(17, 5, 'Almost Famous', '123', 1, 'Kate Hudson, Billy Crudup, Frances McDormand, Philip Seymour Hoffman', '1'),
(18, 5, 'Traffic', '147', 1, 'Michael Douglas, Don Cheadle, Benicio Del Toro, Dennis Quaid, Catherine Zeta-Jones', '1'),
(19, 5, 'Braveheart', '177', 1, 'Mel Gibson, Sophie Marceau', '1'),
(20, 4, 'Bowfinger', '97', 3, 'Eddie Murphy, Steve Martin', '1'),
(21, 5, 'The Basketball Diaries', '102', 1, 'Leonard DiCaprio, Mark Wahlberg, Bruno Kirby, Lorraine Bracco', '1'),
(22, 4, 'Beetlejuice', '92', 4, 'Michael Keaton, Geena Davis, Alec Baldwin, Winona Ryder, Sylvia Sidney', '1'),
(23, 5, 'The Beach', '*', 1, 'Leonardo DiCaprio, Virginie Ledoyen', '1'),
(24, 1, 'Blue Streak', '94', 3, 'Martin Lawrence, Luke Wilson, Dave Chappelle', '1'),
(25, 1, 'Batman', '126', 3, 'Jack Nicholson, Michael Keaton, Kim Basinger', '1'),
(26, 1, 'Batman Returns', '126', 3, 'Michael Keaton, Danny DeVito, Michelle Pfeiffer', '1'),
(27, 1, 'Batman Forever', '122', 3, 'Val Kilmer, Tommy Lee Jones, Jim Carrey, Nichole Kidman, Chris O\\\'Donnell', '1'),
(28, 1, 'Batman & Robin', '125', 3, 'Arnold Schwarzenegger, George Clooney, Chris O\\\'Donnell, Uma Thurman, Alicia Silverstone', '1'),
(29, 3, 'Down To You', '92', 3, 'Freddie Prinze Jr., Julia Stiles', '1'),
(30, 4, 'Drowning Mona', '96', 3, 'Danny DeVito, Bette Midler, Neve Campbell, Jamie Lee Curtis', '1'),
(31, 2, 'Dr. Seuss\\\'s How The Grinch Stole Christmas!', '60', 5, 'Grinch', '1'),
(32, 4, 'Dumb And Dumber', '106', 3, 'Jim Carrey, Jeff Daniels', '1'),
(33, 2, 'Frosty The Snowman', '70', 5, 'Frosty', '1'),
(34, 4, 'Dogma', '128', 1, 'Ben Affleck, Matt Damon, Linda Fiorentino, Salma Hayek, Jason Lee, Jason Mewes, Allan Rickman, Chris Rock, Kevin Smith', '1'),
(35, 5, 'As Good As It Gets', '139', 3, 'Jack Nicholson, Helen Hunt, Greg Kinnear', '1'),
(36, 9, 'Final Destination', '98', 1, 'Devon Sawa, Ali Larter, Kerr Smith', '1'),
(37, 9, 'The Firm', '154', 1, 'Tom Cruise, Jeanne Tripplehorn, Gene Hackman, Ed Harris, Holly Hunter', '1'),
(38, 4, 'Four Rooms', '98', 1, 'Tim Roth, Antonio Bandaras, Jennifer Beals, Paul Calderon, Sammi Davis, Madonna, Valeria Golino, David Proval, Ione Skye, Lilli Taylor, Marisa Tomei, Tamlyn Tomita', '1'),
(39, 6, 'From Dusk Till Dawn', '108', 1, 'Harvey Keitel, George Clooney, Quentin Tarantino, Juliette Lewis, Salma Hayek, Cheech Marin', '1'),
(40, 6, 'Fargo', '98', 1, 'Frances McDormand, William H Macy, Steve Buscemi, Harve Presnell', '1'),
(41, 5, 'The Fan', '116', 1, 'Robert DeNiro, Wesley Snipes', '1'),
(42, 1, 'Face / Off', '140', 1, 'John Travolta, Nicolas Cage, Joan Allen, Gina Gershon', '1'),
(43, 4, 'Ace Ventura: Pet Detective', '87', 3, 'Jim Carrey, Sean Young, Courtney Cox, Tone Loc, Dan Marino', '1'),
(44, 9, 'The Fugitive', '131', 3, 'Harrison Ford, Tommy Lee Jones, Sela Ward, Joe Pantoliano', '1'),
(45, 1, 'Full Metal Jacket', '116', 1, 'Matthew Modine, Adam Baldwin, Vincent D\\\'onofrio', '1'),
(46, 9, 'Enemy Of The State', '132', 1, 'Will Smith, Gene Hackman, John Voight, Regina King, Barry Pepper', '1'),
(47, 6, '8MM', '123', 1, 'Nicolas Cage, Joaquin Phoenix, James Gandolfini', '1'),
(48, 1, 'Eraser', '115', 1, 'Arnold Schwarzenegger, James Caan, Vanessa Williams', '1'),
(49, 5, 'Erin Brockovich', '132', 1, 'Julia Roberts, Albert Finney, Arron Eckhart', '1'),
(50, 1, 'Desperado', '103', 1, 'Antonio Bandaras, Salma Hayek, Steve Buscemi, Cheech Marin, Quentin Tartantino', '1'),
(51, 4, 'Deuce Bigalow Male Gigolo', '88', 1, 'Rob Schneider,William Forsythe, Eddie Griffin', '1'),
(52, 5, 'Corrina, Corrina', '115', 4, 'Whoopi Goldberg, Ray Liotta', '1'),
(53, 7, 'Contact', '150', 4, 'Jodie Foster, Matthew McConaughhey, James Woods, John Hurt', '1'),
(54, 5, 'Casino', '179', 1, 'Robert DiNiro, Sharon Stone, Joe Pesci, Don Rickles, Alan King, Kevin Pollak', '1'),
(55, 6, 'The Cell', '107', 1, 'Jennifer Lopez, Vince Vaughn, Vincent D\\\'Onfrio', '1'),
(56, 4, 'Clueless', '97', 3, 'Alicia Silverstone, Brittany Murphy, Justin Walker, Paul Rudd, Stacey Dash', '1'),
(57, 4, 'Clerks', '92', 1, 'Kevin Smith, Jason Mewes, Jeff Anderson, Scott Mosier, Marilyn Ghigliotti, Lisa Spoonhauer', '1'),
(58, 4, 'A Christmas Story', '98', 4, 'Melinda Dillon, Darren McGavin, Peter Billingsley', '1'),
(59, 4, 'Chasing Amy', '113', 1, 'Kevin Smith, Ben Affleck, Jason Lee, Jason Mewes, Joey Lauren Adams, Dwight Ewell', '1'),
(60, 1, 'Demolition Man', '115', 1, 'Sylvester Stallone, Wesley Snipes, Sandra Bullock, Nigel Hawthorne', '1'),
(61, 4, 'Dazed And Confused', '103', 1, 'Jason London, Joey Lauren Adams, Milla Jovovich, Rory Cochrane, Marissa Ribisi', '1'),
(62, 5, 'A Bronx Tale', '122', 1, 'Robert DeNiro, Chazz Palminteri', '1'),
(63, 4, 'Caddyshack', '99', 1, 'Chevy Chase, Rodney Dangerfield, Ted Knight, Michael O\\\'Keefe, Bill Murray', '1'),
(64, 5, 'Clockers', '129', 1, 'Harvey Keitel, John Turturro, Delroy Lindo, Mekhi Phifer, Isaiah Washington', '1'),
(65, 2, 'Charlie Brown: A Charlie Brown Christmas', '25', 5, 'Charlie Brown', '1'),
(66, 2, 'Charlie Brown: A Charlie Brown Thanksgiving', '30', 5, 'Charlie Brown', '1'),
(67, 2, 'Charlie Brown: It\\\'s The Great Pumpkin, Charlie Brown', '25', 5, 'Charlie Brown', '1'),
(68, 1, 'Die Hard: Die Hard', '132', 1, 'Bruce Willis, Alan Rickman, Bonnie Bedelia', '1'),
(69, 1, 'Die Hard: Die Hard 2', '124', 1, 'Bruce Willis, Bonnie Bedelia, William Atherton', '1'),
(70, 1, 'Die Hard: Die Hard With A Vengeance', '131', 1, 'Bruce Willis, Jeremy Irons, Samuel L. Jackson', '1'),
(71, 5, 'A Beautiful Mind', '136', 3, 'Russell Crowe, Jennifer Connelly, Paul Bettany, Adam Goldberg, Judd Hersch', '1'),
(72, 3, 'Sleepless in Seatle', '105', 4, 'Tom Hanks, Meg Ryan', '1'),
(73, 1, 'Spider-Man', '121', 3, 'Tobey Maguire, Willem Dafoe, Kristen Dunst, James Franco', '1'),
(74, 9, 'Minority Report', '146', 3, 'Tom Cruise, Colin Farrell, Samantha Morton, Max Von Sydow', '1'),
(75, 7, 'Harry Potter And The Sorcerer\\\'s Stone', '152', 4, 'Daniel Radcliffe, Rupert Grint, Emma Watson, John Cleese, Robbie Coltrane, Warwick Davis, Richard Griffiths, Richard Harris, Ian Hart, John Hurt, Alan Rickman, Fiona Shaw, Maggie Smith, Julie Walters', '1'),
(76, 4, 'Old School (Unrated And Out Of Control)', '92', 1, 'Luke Wilson, Will Ferrell, Vince Vaughn', '1'),
(77, 4, 'Money Talks', '95', 1, 'Chris Tucker, Charlie Sheen, Heather Locklear, Gerard Ismael, Paul Sorvino', '1'),
(78, 1, 'Charlie\\\'s Angels', '99', 3, 'Cameron Diaz, Drew Barrymore, Lucy Liu, Bill Murray, Sam Rockwell, Tim Curry, Kelly Lynch, Crispin Glover', '1'),
(79, 7, 'The Lord Of The Rings: The Two Towers', '179', 3, 'Elijah Wood, Ian McKellen, Liv Tyler, Viggo Mortensen, Sean Astin, Cate Blanchett', '1'),
(80, 9, 'Insomnia', '118', 1, 'Al Pacino, Robin Williams, Hilary Swank', '1'),
(81, 9, 'Phone Booth', '81', 1, 'Colin Ferrell, Forest Whitaker, Kiefer Sutherland, Katie Holmes', '1'),
(82, 6, 'Identity', '90', 1, 'John Cusack, Ray Liotta, Amanda Peet', '1'),
(83, 1, '007: Die Another Day', '132', 3, 'Pierce Brosnan, Halle Berry, Toby Stephens, John Cleese', '1'),
(84, 8, 'Sex And The City 1: The Complete First Season (2 Discs)', '300', 1, 'Sarah Jessica Parker, Cynthia Nixon, Kim Cattrall, Kristin Davis', '1'),
(85, 8, 'Sex And The City 2: The Complete Second Season (3 Discs)', '540', 1, 'Sarah Jessica Parker, Cynthia Nixon, Kim Cattrall, Kristin Davis', '1'),
(86, 8, 'Sex And The City 3: The Complete Third Season (3 Discs)', '540', 1, 'Sarah Jessica Parker, Cynthia Nixon, Kim Cattrall, Kristin Davis', '1'),
(87, 8, 'Sex And The City 4: The Complete Fourth Season (3 Discs)', '540', 1, 'Sarah Jessica Parker, Cynthia Nixon, Kim Cattrall, Kristin Davis', '1'),
(88, 8, '24: Season One (6 Discs)', '1152', 1, 'Kiefer Sutherland', '1'),
(89, 8, 'The Sopranos 1: The Complete First Season (3 Discs)', '680', 1, 'James Gandolfini, Lorraine Bracco, Edie Falco, Michael Imperioli, Dominic Chianese, Vincent Pastore', '1'),
(90, 8, 'The Sopranos 2: The Complete Second Season (4 Discs)', '696', 1, 'James Gandolfini, Lorraine Bracco, Edie Falco, Michael Imperioli, Dominic Chianese, Vincent Pastore', '1'),
(91, 8, 'The Sopranos 3: The Complete Third Season (4 Discs)', '780', 1, 'James Gandolfini, Lorraine Bracco, Edie Falco, Michael Imperioli, Dominic Chianese, Vincent Pastore', '1'),
(92, 8, 'The X-Files 1: The Complete First Season (6 Discs)', '*', 4, 'David Duchovny, Gillian Anderson, Robert Patrick', '1'),
(93, 8, 'The X-Files 2: The Complete Second Season (6 Discs)', '*', 4, 'David Duchovny, Gillian Anderson, Robert Patrick', '1'),
(94, 8, 'The X-Files 3: The Complete Third Season (6 Discs)', '*', 4, 'David Duchovny, Gillian Anderson, Robert Patrick', '1'),
(95, 8, 'The X-Files 4: The Complete Fourth Season (6 Discs)', '*', 4, 'David Duchovny, Gillian Anderson, Robert Patrick', '1'),
(96, 8, 'The X-Files 5: The Complete Fifth Season (5 Discs)', '*', 4, 'David Duchovny, Gillian Anderson, Robert Patrick', '1'),
(97, 8, 'The X-Files 6: The Complete Sixth Season (6 Discs)', '*', 4, 'David Duchovny, Gillian Anderson, Robert Patrick', '1'),
(98, 4, 'Austin Powers: Gold Member', '94', 3, 'Mike Myers, Beyonce Knowles, Michael Caine, Verne Troyer, Seth Green', '1'),
(99, 3, 'Grease', '110', 4, 'John Travolta, Oliva Newton-John', '1'),
(100, 7, 'Star Wars: Episode II - Attack Of The Clones', '142', 4, 'Ewan McGreggor, Natalie Portman, Hayden Christensen, Samuel L. Jackson', '1'),
(101, 4, 'Me, Myself & Irene', '116', 1, 'Jim Carrey, Renee Zellweger', '1'),
(102, 7, 'E.T. The Extra-Terrestrial ', '121', 4, 'Henry Thomas, Dee Wallace-Stone, Robert MacNaughton, Drew Barrymore, C. Thomas Howell', '1'),
(103, 2, 'Shrek', '93', 4, 'Mike Myers, Eddie Murphy, Cameron Diaz, John Lithgow', '1'),
(104, 5, 'Dr. Seuss\\\' How The Grinch Stole Christmas (Non-Animated)', '105', 4, 'Jim Carrey, Jeffrey Tambor, Christine Baranski, Molly Shannon', '1'),
(105, 1, 'Lara Croft Tomb Raider', '100', 3, 'Angelina Jolie, Jon Voight, Ian Glen, Noah Taylor', '1'),
(106, 4, 'The Rocky Horror Picture Show', '100', 1, 'Tim Curry, Susan Sarandon, Barry Bostwick', '1'),
(107, 4, 'American Pie 2 (Unrated)', '111', 1, 'Jason Biggs, Shannon Elizabeth, Alyson Hannigan, Chris Klein, Seann William Scott', '1'),
(108, 5, 'Lord Of The Flies', '90', 1, 'Balthazar Getty, Chris Furrh', '1'),
(109, 4, 'Drawing Flies', '76', 1, 'Jason Lee, Jason Mewes, Joey Lauren Adams, Ren&eacute;e Humphrey, Carmen Lee', '1'),
(110, 6, 'The Hitcher', '98', 1, 'Rutger Hauer, C. Thomas Howell, Jennifer Jason Leigh', '1'),
(111, 4, 'Ocean\\\'s Eleven', '117', 3, 'George Clooney, Bernie Mac, Brad Pitt, Elliot Gould, Casey Affleck, Julia Roberts, Andy Garcia, Matt Damon, Carl Reiner', '1'),
(112, 4, 'Zoolander', '89', 3, 'Will Ferrell, Ben Stiller, Owen Wilson, Christine Taylor', '1'),
(113, 1, 'Swordfish', '99', 1, 'John Travolta, Hugh Jackman, Halle Berry, Don Cheadle, Sam Shepard', '1'),
(114, 4, 'Scary Movie 2', '82', 1, 'Shawn Wayans, Marlon Wayans, Regina Hall, Tori Spelling, Tim Curry, David Cross, Chris Elliot, James Woods', '1'),
(115, 4, 'Shallow Hal', '113', 3, 'Jack Black, Gwyneth Paltrow, Jason Alexander', '1'),
(116, 2, 'Osmosis Jones', '95', 4, 'Bill Murray, Laurence Fishburne, Chris Rock, David Hyde Pierce, Chris Elliot', '1'),
(117, 1, 'The Score', '124', 1, 'Robert DeNiro, Edward Norton, Angela Bassett, Marlon Brando', '1'),
(118, 5, 'Training Day', '120', 1, 'Denzel Washington, Ethan Hawke, Scott Glenn, Tom Berenger, Dr. Dre, Snoop Dogg, Macy Gray', '1'),
(119, 5, 'Rock Star', '105', 1, 'Mark Wahlberg, Jennifer Aniston', '1'),
(120, 4, 'Orange County', '82', 3, 'Jack Black, Colin Hanks, Schuyler Fisk, Catherine O\\\'Hara, John Lithgow, Harold Ramis, Lily Tomlin', '1'),
(121, 4, 'Death To Smoochy', '109', 1, 'Robin Williams, Edward Norton, Danny DeVito', '1'),
(122, 4, 'Jay And Silent Bob Strike Back', '104', 1, 'Ben Affleck, Shannon Elizabeth, Will Ferrell, Jason Lee, Jason Mewes, Chris Rock', '1'),
(123, 9, 'The Sum Of All Fears', '123', 3, 'Ben Affleck, Morgan Freeman', '1'),
(124, 1, 'Spy Game', '126', 1, 'Robert Redford, Brad Pitt, Catherine McCormack', '1'),
(125, 5, 'Changing Lanes', '99', 1, 'Ben Affleck, Samuel L. Jackson', '1'),
(126, 1, 'The Fast And The Furious', '106', 3, 'Paul Walker, Vin Diesel, Michelle Rodriguez, Jordana Brewster, Ja Rule', '1'),
(127, 5, 'Vanilla Sky', '135', 1, 'Tom Cruise, Pen&eacute;lope Cruz, Cameron Diaz, Kurt Russell, Jason Lee, Noah Taylor', '1'),
(128, 5, 'Artificial Intelligence: AI', '146', 3, 'Haley Joel Osment, Jude Law, William Hurt, Sam Robards, Jake Thomas', '1'),
(129, 8, 'The X-Files 7: The Complete Seventh Season', '*', 4, 'David Duchovny, Gillian Anderson, Robert Patrick', '1'),
(130, 3, 'Center Stage', '115', 3, 'Amanda Schull, Zoe Saldana, Peter Gallagher', '1'),
(131, 5, 'Hoosiers', '115', 4, 'Gene Hackman, Barbara Hershey, Dennis Hopper', '1'),
(132, 5, 'Midnight Express', '120', 1, 'Brad Davis, Randy Quaid', '1'),
(133, 1, 'Mercury Rising', '108', 1, 'Bruce Willis, Alec Baldwin, Miko Hughes', '1'),
(134, 4, 'Mr. Mom', '91', 4, 'Michael Keaton, Teri Garr, Martin Mull', '1'),
(135, 4, 'Crooklyn', '115', 3, 'Alfre Woodard, Delroy Lindo, Spike Lee', '1'),
(136, 3, 'Coyote Ugly', '101', 3, 'Piper Perabo, Adam Garcia, John Goodman, Tyra Banks', '1'),
(137, 4, 'Down To Earth', '87', 3, 'Chris Rock, Eugene Levy, John Cho', '1'),
(138, 4, 'Ace Ventura When Nature Calls', '94', 3, 'Jim Carrey, Ian McNeice, Simon Callow, Maynard Eziashi', '1'),
(139, 5, 'Cast Away', '143', 3, 'Tom Hanks, Helen Hunt, Nick Searcy', '1'),
(140, 3, 'Save The Last Dance', '112', 4, 'Julia Stiles, Sean Patrick Thomas, Terry Kinney, Fredro Starr', '1'),
(141, 5, 'Thirteen Days', '147', 3, 'Kevin Costner, Bruce Greenwood, Steven Culp, Dylan Baker', '1'),
(142, 4, 'American Pie', '96', 1, 'Jason Biggs, Chris Klein, Shannon Elizabeth, Seann William Scott, Tara Reid', '1'),
(143, 4, 'O Brother, Where Art Thou?', '103', 3, 'George Clooney, John Turturro, Tim Blake Nelson, John Goodman', '1'),
(144, 5, '61*', '129', 5, 'Thomas Jane, Barry Pepper', '1'),
(145, 5, 'JFK', '206', 1, 'Kevin Costner, Kevin Bacon, Tommy Lee Jones, Gary Oldman, Sissy Spacek', '1'),
(146, 6, 'The Sixth Sense', '107', 3, 'Bruce Willis, Haley Joel Osment, Toni Collette, Olivia Williams', '1'),
(147, 9, 'Murder In The First', '122', 1, 'Christian Slater, Kevin Bacon, Gary Oldman', '1'),
(148, 6, 'The Watcher', '97', 1, 'James Spader, Marisa Tomei, Keanu Reeves', '1'),
(149, 4, 'Empire Records', '91', 3, 'Anthony LaPaglia, Renee Zellweger, Liv Tyler, Debi Mazar, Rory Cochrane', '1'),
(150, 3, 'What Women Want', '126', 3, 'Mel Gibson, Helen Hunt, Marisa Tomei, Lauren Holly', '1'),
(151, 5, 'Permanent Midnight', '88', 1, 'Ben Stiller, Elizabeth Hurley, Janeane Garofalo, Owen Wilson', '1'),
(152, 5, 'Fight Club', '139', 1, 'Edward Norton, Brad Pitt, Helena Bonham Carter', '1'),
(153, 1, 'Mission Impossible 2', '123', 3, 'Tom Cruise, Dougray Scott, Thandie Newton, Ving Rhames', '1'),
(154, 2, 'Heavy Metal ', '90', 1, 'Harvey Atkin, John Candy, Eugene Levy', '1'),
(155, 9, 'AntiTrust', '108', 3, 'Ryan Phillippe, Racheal Leigh Cook, Claire Forlani, Tim Robbins', '1'),
(156, 1, 'Armageddon', '151', 3, 'Bruce Willis, Billy Bob Thornton, Liv Tyler, Ben Affleck, Will Patton, Steve Buscemi', '1'),
(157, 5, 'Forrest Gump', '141', 3, 'Tom Hanks, Robin Wright, Gary Sinise, Mykelti Williamson, Sally Field', '1'),
(158, 4, 'Snatch', '104', 1, 'Brad Pitt, Benicio Del Toro, Dennis Farina, Vinnie Jones, Rade Sherbedgia, Jason Statham', '1'),
(159, 9, 'Unbreakable', '107', 3, 'Bruce Willis, Samuel L. Jackson, Robin Wright Penn', '1'),
(160, 5, 'Memento', '113', 1, 'Guy Pearce, Carrie-Anne Moss, Joe Pantoliano', '1'),
(161, 5, 'The Usual Suspects', '106', 1, 'Stephen Baldwin, Gabriel Byrne, Chazz Palminteri, Kevin Pollak, Pete Postlethwaite, Kevin Spacey', '1'),
(162, 5, 'Malcolm X', '202', 3, 'Denzel Washington, Angela Bassett, Albert Hall, Spike Lee, James McDaniel', '1'),
(163, 6, 'The Ring', '115', 3, 'Naomi Watts, Martin Henderson, David Dorfman, Brian Cox', '1'),
(164, 5, 'Drugstore Cowboy', '104', 1, 'Matt Dillon, Kelly Lynch, James Remar, James Le Gros, Heather Graham, William Burroughs', '1'),
(165, 5, 'Finding Forrester', '136', 3, 'Sean Connery, Rob Brown, F. Murray Abraham, Anna Paquin, Busta Rhymes', '1'),
(166, 4, 'Meet The Parents', '108', 3, 'Robert DeNiro, Ben Stiller, Terri Polo', '1'),
(167, 6, 'Hannibal', '131', 1, 'Anthony Hopkins, Julianne Moore, Ray Liotta', '1'),
(168, 4, 'Do The Right Thing', '120', 1, 'Danny Aiello, Ossie Davis, Ruby Dee, Spike Lee, John Turturro, Rosie Perez, Samuel L. Jackson, Martin Lawrence', '1'),
(169, 1, 'Crouching Tiger Hidden Dragon', '120', 3, 'Chow Yun-Fat, Michelle Yeoh, Ziyi Zhang', '1'),
(170, 5, 'Pink Floyd The Wall', '95', 1, 'Bob Geldof, Christine Hargreaves, James Laurenson', '1'),
(171, 8, 'Mr. Show: The Complete First And Second Seasons', '288', 1, 'David Cross, Bob Odenkirk', '1'),
(172, 4, 'Wayne\\\'s World', '94', 3, 'Mike Myers, Dana Carvey, Rob Lowe, Tia Carrere, Donna Dixon', '1'),
(173, 4, 'Wayne\\\'s World 2', '94', 3, 'Mike Myers, Dana Carvey, Tia Carrere, Christopher Walken, Kim Basinger', '1'),
(174, 5, 'One Hour Photo', '96', 1, 'Robin Williams, Connie Nielsen, Michael Vartan, Dylan Smith, Erin Daniels, Gary Cole', '1'),
(175, 5, 'Basic', '98', 1, 'Samuel L. Jackson, John Travolta, Connie Nielsen, Timothy Daly', '1'),
(176, 7, 'Star Wars: Episode I - The Phantom Menace', '133', 4, 'Liam Neeson, Ewan McGregor, Natalie Portman, Jake Lloyd, Ian McDiarmid', '1'),
(177, 7, 'Harry Potter And The Chamber of Secrets', '161', 4, 'Daniel Radcliffe, Emma Watson, Rupert Grint, Richard Griffiths, Fiona Shaw', '1'),
(178, 1, '15 Minutes', '120', 1, 'Robert DeNiro, Edward Burns, Kelsey Grammer, Avery Brooks', '1'),
(179, 4, 'Barbarians At The Gate', '107', 1, 'James Garner, Jonathan Pryce, Peter Riegert', '1'),
(180, 8, 'The Young Ones: Every Stoopid Episode', '400', 3, 'Rik Mayall, Adrian Edmondson, Nigel Planer, Christopher Ryan, Alexei Sayle', '1'),
(181, 4, 'Men In Black II: Back In Black', '88', 3, 'Tommy Lee Jones, Will Smith, Lara Flynn Boyle, Johnny Knoxville, Rosario Dawson, Rip Torn', '1'),
(182, 5, '8 Mile', '111', 1, 'Eminem, Kim Basinger, Brittany Murphy, Mekhi Phifer', '1'),
(183, 5, 'Midnight In The Garden Of Good And Evil', '155', 1, 'John Cusack, Kevin Spacey, Jack Thompson, Irma P. Hall, Jude Law', '1'),
(184, 4, 'Men In Black', '98', 3, 'Tommy Lee Jones, Will Smith, Linda Fiorentino, Vincent D\\\'Onofrio, Rip Torn', '1'),
(185, 5, 'The Messenger', '158', 1, 'Milla Jovovich, John Malkovich, Dustin Hoffman, Faye Dunaway', '1'),
(186, 4, 'Love &amp; A .45', '101', 1, 'Gil Bellows, Renee Zellweger', '1'),
(187, 5, 'The Man In The Iron Mask', '132', 3, 'Leonardo Dicaprio, Jeremy Irons, John Malkovich, Gerard Depardieu, Gabriel Byrne', '1'),
(188, 1, 'The Matrix', '136', 1, 'Keanu Reeves, Laurence Fishburne, Carrie-Anne Moss, Hugo Weaving, Joe Pantoliano', '1'),
(189, 1, 'Heat', '172', 1, 'Al Pacino, Robert DeNiro, Val Kilmer, Jon Voight, Tom Sizemore, Ashley Judd', '1'),
(190, 4, 'Mallrats', '96', 1, 'Kevin Smith, Jason Mewes, Jason Lee, Jeremy London, Shannen Doherty, Claire Forlani', '1'),
(191, 5, 'Magnolia', '188', 1, 'Pat Healy, Genevieve Zweig, Mark Flannagan, Neil Flynn', '1'),
(192, 7, 'Lost In Space', '130', 3, 'William Hurt, Mimi Rogers, Lacey Chabert, Heather Graham, Matt LeBlanc', '1'),
(193, 5, 'Lord Of The Flies (1963 - B &amp; W)', '92', 1, 'James Aubrey, Tom Chapin, Hugh Edwards, Roger Elwin', '1'),
(194, 1, 'The Long Kiss Goodnight', '120', 1, 'Geena Davis, Samuel L. Jackson, Yvonne Zima', '1'),
(195, 5, 'Gotti', '104', 1, 'Armand Assante, William Forsythe, Anthony Quinn', '1'),
(196, 5, 'Goodfellas', '146', 1, 'Robert DeNiro, Ray Liotta, Joe Pesci, Lorraine Bracco, Paul Sorvino', '1'),
(197, 5, 'Good Will Hunting', '126', 1, 'Robin Williams, Matt Damon, Ben Affleck, Minie Driver', '1'),
(198, 4, 'Go', '103', 1, 'Scott Wolf, Taye Diggs, Desmond Askew', '1'),
(199, 1, 'Gladiator', '155', 1, 'Russell Crowe, Joaquin Phoenix, Connie Nielsen', '1'),
(200, 4, 'High Fidelity', '114', 1, 'John Cusack, Jack Black, Todd Louiso, Iben Hjejle, Lily Taylor, Lisa Bonet, Catherine Zeta-Jones', '1'),
(201, 4, 'Get Shorty', '105', 1, 'John Travolta, Gene Hackman, Rene Russo, Danny DeVito, Dennis Farina, Delroy Lindo, James Gandolfini', '1'),
(202, 9, 'The Game', '128', 1, 'Michael Douglas, Sean Penn', '1'),
(203, 7, 'Galaxy Quest', '102', 4, 'Tim Allen, Sigourney Weaver, Alan Rickman', '1'),
(204, 5, 'The Legend Of Bagger Vance', '126', 3, 'Will Smith, Matt Damon, Charlize Theron', '1'),
(205, 2, 'Lady And The Tramp', '76', 5, 'Lady, Tramp, Jock, Trusty, Peg', '1'),
(206, 5, 'L.A. Confidential', '138', 1, 'Kevin Spacey, Russell Crowe, Guy Pearce, Kim Basinger, Danny DeVito', '1'),
(207, 1, 'Lethal Weapon', '112', 1, 'Mel Gibson, Danny Glover, Gary Busey', '1'),
(208, 1, 'Lethal Weapon 2', '113', 1, 'Mel Gibson, Danny Glover, Joe Pesci', '1'),
(209, 1, 'Lethal Weapon 3', '118', 1, 'Mel Gibson, Danny Glover, Joe Pesci, Rene Russo', '1'),
(210, 1, 'Lethal Weapon 4', '127', 1, 'Mel Gibson, Danny Glover, Joe Pesci, Rene Russo, Chris Rock, Jet Li', '1'),
(211, 1, 'Gone In 60 Seconds', '117', 3, 'Nicolas Cage, Giovanni Ribisi, Angelina Jolie, Delroy Lindo, Will Patton, Robert Duvall', '1'),
(212, 4, 'Grosse Pointe Blank', '107', 1, 'John Cusack, Minnie Driver, Alan Arkin, Dan Aykroyd, Joan Cusack, Jeremy Piven', '1'),
(213, 5, 'The Green Mile', '188', 1, 'Tom Hanks, David Morse, Bonnie Hunt, Michael Clarke Duncan, James Cromwell, Sam Rockwell, Barry Pepper', '1'),
(214, 6, 'I Still Know What You Did Last Summer', '100', 1, 'Jennifer Love Hewitt, Freddie Prinze Jr., Brandy Norwood, Mekhi Phifer', '1'),
(215, 4, 'Happy Gilmore', '92', 3, 'Adam Sandler, Christopher McDonald, Carl Weathers, Bob Barker, Lee Trevino, Verne Lundquist', '1'),
(216, 6, 'I Know What You Did Last Summer', '100', 1, 'Jennifer Love Hewitt, Sarah Michelle Gellar, Ryan Phillippe, Freddie Prinze Jr., Anne Heche', '1'),
(217, 5, 'Hard Eight', '102', 1, 'Philip Baker Hall, John C. Reilly, Gwyneth Paltrow, Samuel L. Jackson, Philip Seymour Hoffman', '1'),
(218, 1, 'Mission Impossible', '110', 3, 'Tom Cruise, Jon Voight, Emmanuelle B&eacute;art, Ving Rhames, Kristin Scott Thomas, Vanessa Redgrave', '1'),
(219, 6, 'The Silence Of The Lambs', '118', 1, 'Jodie Foster, Anthony Hopkins, Scott Glenn', '1'),
(220, 4, 'Singles', '95', 3, 'Bridget Fonda, Campbell Scott, Kyra Sedgwick, Matt Dillon, Bill Pullman, James LeGros, Eric Stoltz, Jeremy Piven, Tom Skerritt', '1'),
(221, 5, 'Sleepers', '147', 1, 'Kevin Bacon, Billy Crudup, Robert DeNiro, Minnie Driver, Dustin Hoffman, Bruno Kirby, Brad Pitt', '1'),
(222, 6, 'Sleepy Hollow', '105', 1, 'Johnny Depp, Christina Ricci, Miranda Richardson, Christopher Walken', '1'),
(223, 1, 'The Negotiator', '139', 1, 'Samuel L. Jackson, Kevin Spacey, David Morse, Ron Rifkin, Regina Taylor', '1'),
(224, 1, 'Natural Born Killers', '118', 1, 'Woody Harrelson, Juliette Lewis, Rodney Dangerfield, Robert Downey Jr.', '1'),
(225, 4, 'National Lampoon\\\'s Christmas Vacation', '97', 3, 'Chevy Chase, Beverly D\\\'Angelo, Randy Quaid, Juliette Lewis, William Hickey', '1'),
(226, 4, 'National Lampoon\\\'s Vacation', '99', 1, 'Chevy Chase, Beverly D\\\'Angelo, Randy Quaid, Christine Brinkley', '1'),
(227, 1, 'Murder At 1600', '107', 1, 'Wesley Snipes, Diane Lane, Dennis Miller, Alan Alda, Tate Donovan', '1'),
(228, 4, 'Mystery Men', '122', 3, 'Hank Azaria, Claire Forlani, Janeane Garofalo, Eddie Izzard, Greg Kinnear, William H. Macy, Paul Rubens, Ben Stiller, Tom Waits', '1'),
(229, 4, 'A Night At The Roxbury', '81', 3, 'Will Ferrell, Chris Kattan, Molly Shannon, Richard Grieco', '1'),
(230, 9, 'The Net', '114', 3, 'Sandra Bullock, Jeremy Northam, Dennis Miller', '1'),
(231, 5, 'Payback', '100', 1, 'Mel Gibson, Gregg Henry, Maria Bello, David Paymer, Lucy Liu, Kris Kristofferson', '1'),
(232, 4, 'Patch Adams', '115', 3, 'Robin Williams, Daniel London, Monica Potter', '1'),
(233, 5, 'The Outsiders', '91', 4, 'Matt Dillon, Patrick Swayze, C. Thomas Howell, Tom Cruise, Ralph Macchio, Emilo Estevez, Rob Lowe', '1'),
(234, 5, '187', '119', 1, 'Samuel L. Jackson, Clifton Gonzalez Gonzalez', '1'),
(235, 4, 'Office Space', '90', 1, 'Ron Livinston, Stephen Root, Gary Cole, Jennifer Aniston', '1'),
(236, 4, 'The Nutty Professor II: The Klumps', '107', 3, 'Eddie Murphy, Janet Jackson, Larry Miller', '1'),
(237, 4, 'The Nutty Professor', '96', 3, 'Eddie Murphy, Jada Pinkett, James Coburn, Dave Chappelle', '1'),
(238, 3, 'Pretty Woman', '119', 1, 'Richard Gere, Julia Roberts, Ralph Bellamy, Jason Alexander, Hector Elizondo', '1'),
(239, 1, 'Platoon', '120', 1, 'Tom Berenger, Willem Dafoe, Charlie Sheen, Forest Whitaker, Kevin Dillon, Johnny Depp', '1'),
(240, 4, 'Planes, Trains and Automobiles', '92', 1, 'Steve Martin, John Candy', '1'),
(241, 7, 'Pitch Black', '112', 1, 'Vin Diesel, Radha Mitchell, Cole Hauser', '1'),
(242, 6, 'Pet Sematary', '102', 1, 'Fred Gwynne, Dale Midkiff, Denise Crosby', '1'),
(243, 5, 'A Perfect Murder', '108', 1, 'Michael Douglas, Gwyneth Paltrow, Viggo Mortensen', '1'),
(244, 5, 'Reservoir Dogs', '100', 1, 'Harvey Keitel, Tim Roth, Michael Madsen, Chris Penn, Steve Buscemi, Quentin Tarantino', '1'),
(245, 5, 'Revenge', '123', 1, 'Kevin Costner, Anthony Quinn, Madeleine Stowe', '1'),
(246, 5, 'The Right Stuff', '193', 4, 'Sam Shepard, Ed Harris, Dennis Quaid, Barbara Hershey, Fred Ward', '1'),
(247, 5, 'Pulp Fiction', '154', 1, 'John Travolta, Samuel L. Jackson, Uma Thurman, Harvey Keitel, Tim Roth, Amanda Plummer', '1'),
(248, 5, 'Pump Up The Volume', '102', 1, 'Christian Slater, Ellen Greene', '1'),
(249, 4, 'The Princess Bride', '98', 4, 'Cary Elwes, Robin Wright, Mandy Patinkin, Billy Crystal, Peter Falk, Fred Savage', '1'),
(250, 5, 'Saving Private Ryan', '169', 1, 'Tom Hanks, Edward Burns, Matt Damon, Tom Sizemore', '1'),
(251, 2, 'Rudolph The Red-Nosed Reindeer', '135', 5, 'Ruldolph', '1'),
(252, 9, 'Hollow Man', '113', 1, 'Kevin Bacon, Elisabeth Shue', '1'),
(253, 5, 'Rounders ', '121', 1, 'Matt Damon, Edward Norton, John Turturro, John Malkovich, Martin Landau', '1'),
(254, 3, 'Romeo &amp; Julliet', '120', 3, 'Leonardo DiCaprio, Claire Danes, John Leguizamo, Brian Demnehy, Paul Sorvino', '1'),
(255, 5, 'The Shawshank Redemption', '142', 1, 'Tim Robbins, Morgan Freeman, William Sadler, Gil Bellows, James Whitmore, Clancy Brown, Bob Gunton', '1'),
(256, 3, 'Shakespeare In Love', '122', 1, 'Gwyneth Paltrow, Joseph Fiennes, Geoffrey Rush, Colin Firth, Ben Affleck', '1'),
(257, 9, 'Seven', '127', 1, 'Brad Pitt, Morgan Freeman, Kevin Spacey, Gwyneth Paltrow', '1'),
(258, 6, 'Scream', '111', 1, 'David Arquette, Neve Campbell, Courteny Cox, Skeet Ulrich, Drew Barrymore', '1'),
(259, 6, 'Scream 2', '120', 1, 'David Arquette, Neve Campbell, Courteney Cox, Sarah Michelle Gellar, Jamie Kennedy, Jerry O\\\'Connell, Jada Pinkette', '1'),
(260, 6, 'Scream 3', '117', 1, 'David Arquette, Neve Campbell, Courteney Cox Arquette, Patrick Dempsey, Jenny McCarthy, Parker Posey', '1'),
(261, 4, 'Scary Movie', '88', 1, 'Shannon Elizabeth, Carmen Electra, Regina Hall, Sheri Oteri, Marlon Wayans', '1'),
(262, 1, 'Six Days Seven Nights', '102', 3, 'Harrison Ford, Anne Heche, David Schwimmer', '1'),
(263, 7, 'Stargate', '119', 3, 'Kurt Russell, James Spader', '1'),
(264, 5, 'Stand By Me', '88', 1, 'Wil Wheaton, River Phoenix, Corey Feldman, Jerry O\\\'Connell, Kiefer Sutherland', '1'),
(265, 3, 'Stepmom', '125', 3, 'Julia Roberts, Susan Sarandon, Ed Harris', '1'),
(266, 4, 'So I Married An Axe Murderer', '93', 3, 'Mike Myers, Nancy Travis, Anthony LaPaglia, Amanda Plummer', '1'),
(267, 5, 'Sneakers', '125', 3, 'Robert Redford, Dan Aykroyd, Ben Kingsley, Mary McDonnell, River Phoenix, Sidney Poitier, David Strathairn', '1'),
(268, 1, 'Snake Eyes', '98', 1, 'Nicolas Cage, Gary Sinise, John Heard, Carla Gugino', '1'),
(269, 5, 'Sling Blade', '135', 1, 'Billy Bob Thornton, John Ritter, Rober Duvall, Dwight Yoakam, J.T. Walsh', '1'),
(270, 4, 'Tommy Boy', '97', 3, 'Chris Farley, David Spade, Bo Derek, Brian Dennehy', '1'),
(271, 4, 'There\\\'s Something About Mary', '119', 1, 'Cameron Diaz, Ben Stiller, Matt Dillon, Chris Elliott', '1'),
(272, 4, 'Swingers', '96', 1, 'Jon Favreau, Vince Vaughn, Ron Livingston, Heather Graham', '1'),
(273, 4, 'Swimming With Sharks', '93', 1, 'Kevin Spacey, Frank Whaley, Michelle Forbs, Benicio Del Toro', '1'),
(274, 6, 'Stir Of Echos', '99', 1, 'Kevin Bacon, Kathryn Erbe, Illeana Douglas, Zachary David Cope', '1'),
(275, 9, 'Suicide Kings', '103', 1, 'Christopher Walken, Denis Leary, Sean Patrick Flanery', '1'),
(276, 9, 'Stigmata', '102', 1, 'Patricia Arquette, Gabriel Byrne, Jonathan Pryce, Nia Long', '1'),
(277, 9, '12 Monkeys', '130', 1, 'Bruce Willis, Madeleine Stowe, Brad Pitt, Christopher Plummer', '1'),
(278, 5, '2 Days In The Valley', '105', 1, 'Danny Aiello, Jeff Daniels, Teri Hatcher, Glenne Headly, Peter Horton, Marsha Mason, Paul Mazursky, James Spader, Eric Stoltz, Charlize Theron', '1'),
(279, 2, 'Toy Story', '81', 5, 'Tom Hanks, Tim Allen', '1'),
(280, 2, 'Toy Story 2', '92', 5, 'Tom Hanks, Tim Allen', '1'),
(281, 5, 'True Romance', '121', 1, 'Christian Slater, Patricia Arquette, Val Kilmer, Dennis Hopper, Gary Oldman, Brad Pitt', '1'),
(282, 1, 'Three Kings', '115', 1, 'George Clooney, Mark Wahlberg, Ice Cube', '1'),
(283, 5, 'A Time To Kill', '150', 1, 'Sandra Bullock, Samuel L. Jackson, Matthew McConaughey, Kevin Spacey', '1'),
(284, 5, 'Unforgiven', '127', 1, 'Clint Eastwood, Gene Hackman, Morgan Freeman, Richard Harris', '1'),
(285, 7, 'The X-Files: Fight The Future', '122', 3, 'David Duchovny, Gillian Anderson, Martin Landau, Blythe Danner', '1'),
(286, 9, 'What Lies Beneath', '130', 3, 'Harrison Ford, Michelle Pfeiffer, Diana Scarwid', '1'),
(287, 5, 'What Dreams May Come', '113', 3, 'Robin Williams, Cuba Gooding Jr., Annabella Sciorra, Max Von Sydow', '1'),
(288, 5, 'The Way Of The Gun', '119', 1, 'James Caan, Benicio Del Toro, Taye Diggs, Ryan Phillippe, Juliette Lewis', '1'),
(289, 5, 'Wall Street', '125', 1, 'Michael Douglas, Charlie Sheen, Daryl Hannah', '1'),
(290, 1, 'U.S. Marshals', '131', 3, 'Tommy Lee Jones, Wesley Snipes, Robert Downey Jr.', '1'),
(291, 5, 'The Untouchables', '119', 1, 'Kevin Costner, Robert DeNiro, Charles Martin Smith, Andy Garcia, Sean Connery', '1'),
(292, 3, 'Untamed Heart', '102', 3, 'Christian Slater, Marisa Tomei, Rosie Perez', '1'),
(293, 1, 'Young Guns', '102', 1, 'Emilio Estevez, Keifer Sutherland, Lou Diamond Phillips, Charlie Sheen, Dermot Mulroney, Casey Siemaszko', '1'),
(294, 2, 'The Year Without A Santa Claus', '125', 5, 'Mickey Rooney, Dick Shawn, George S. Irving', '1'),
(295, 1, 'X-Men', '104', 3, 'Hugh Jackman, Patrick Stewart, Ian McKellen, Famke Janssen, James Mardsen, Halle Berry, Anna Paquin, Rebecca Romijn-Stamos', '1'),
(296, 1, 'Vertical Limit', '124', 4, 'Chris O\\\'Donnell, Bill Paxton, Robin Tunney, Scott Glenn', '1'),
(297, 5, 'Blow', '124', 1, 'Johnny Depp, Penelope Cruz, Franka Potente, Rachel Griffiths, Paul Reubens, Ray Liotta, Jesse James', '1'),
(298, 9, 'Kalifornia', '117', 1, 'Brad Pitt, Juliette Lewis, David Duchovny, Michelle Forbes', '1'),
(299, 1, 'Judgment Night', '110', 1, 'Emilio Estevez, Cuba Gooding Jr., Denis Leary', '1'),
(300, 9, 'Instinct', '126', 1, 'Anthony Hopkins, Cuba Gooding Jr., Donald Sutherland, Maura Tierney', '1'),
(301, 1, 'Independence Day', '153', 3, 'Will Smith, Bill Pullman, Jeff Goldblum, Mary McDonnell, Judd Hirsch, Randy Quaid', '1'),
(302, 9, 'Misery', '108', 1, 'James Caan, Kathy Bates, Frances Sternhagen, Richard Farnsworth', '1'),
(303, 4, 'You\\\'ve Got Mail', '120', 4, 'Tom Hanks, Meg Ryan, Parker Posey, Jean Stapleton, Dave Chappelle, Greg Kinnear', '1'),
(304, 1, 'Harley Davidson And The Marlboro Man', '98', 1, 'Mickey Rourke, Don Johnson, Chelsea Field, Daniel Baldwin, Vanessa Williams, Tom Sizemore', '1'),
(305, 5, 'The Bodyguard', '130', 1, 'Kevin Costner, Whitney Houston, Gary Kemp, Bill Cobbs, Ralph Waite', '1'),
(306, 5, 'American History X', '119', 1, 'Edward Norton, Edward Furlong, Beverly D\\\'Angelo, Elliot Gould', '1'),
(307, 8, 'Band Of Brothers', '600', 1, 'Damian Lewis, Donnie Wahlberg, Ron Livingston', '1'),
(308, 8, 'My So Called Life', '1140', 4, 'Claire Danes, Bess Armstrong, Wilson Cruz', '1'),
(309, 1, 'The Matrix Reloaded', '138', 1, 'Laurence Fishburne, Carrie-Anne Moss, Jada Pinkett Smith, Keanu Reeves, Hugo Weaving', '1'),
(310, 8, 'South Park 1: The Complete First Season', '310', 2, 'Trey Parker, Matt Stone', '1');
# --------------------------------------------------------

#
# Table structure for table `myProjects`
#

DROP TABLE IF EXISTS myProjects;
CREATE TABLE myProjects (
  id int(11) NOT NULL auto_increment,
  orderId int(11) NOT NULL default '0',
  title text NOT NULL,
  url text NOT NULL,
  overview text NOT NULL,
  myRole text NOT NULL,
  image1 text NOT NULL,
  image2 text NOT NULL,
  image3 text NOT NULL,
  active int(4) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table `myProjects`
#

INSERT INTO myProjects (id, orderId, title, url, overview, myRole, image1, image2, image3, active) VALUES (1, 1, 'ZeaVision', 'www.zeavision.com', 'ZeaVision LLC is a company that patented a dietary supplement, called zeaxanthin, that helps maintain vision health and brings hope to those with macular degeneration.', 'My role was programming the designs for the web while complying with ADA / 508 / WAI basic guidelines. Another feature added is the ability to increase or decrease the text size on the site to make it easier to read while still maintaining a visual appeal. I also created several Flash pieces for the site that act as information guides and attention grabbers. Other features include: Tell a Friend, Shopping Cart, Flash detection, dynamic content, administration screens, and more.<br /><br />\r\nI also helped implement voice recognition software that allowed ZeaVision to use any telephone to get the latest information about sales, stock, and more.', 'zeavision_1.jpg', 'zeavision_2.jpg', 'zeavision_3.jpg', 1),
(2, 2, 'Wear-Dated', 'www.weardated.com', 'A <a href="http://www.solutia.com/" target="_blank">Solutia, Inc.</a> company, Wear-Dated Carpet Fiber and Wear-Dated Upholstery required a complete solution from the ground up, built from scratch. The project consists so far of 2 major phases.<br /><br />\r\nThe first major itteration included a complete re-design and programming of their entire public web site which included some administration screens as well.<br /><br />\r\nThe second major itteration includes another re-design and programming of their entire public web site with enhancements to include a room designer / planner, which will also interact with in-store kiosks that we are developing as well.', 'My role was to program the designs into a fully functioning site while meeting Solutia, Inc. IT teams strict standards and compliance initiatives. Key features include Flash detection and animations, Find a Retailer search, Find Carpet search, survey\'s, registration and contact forms, and much more.', 'weardated_1.jpg', 'weardated_2.jpg', 'weardated_3.jpg', 1),
(6, 3, 'TruSecure', 'www.trusecure.com', 'TruSecure is a leading provider of intelligent risk management products and services. TruSecure claims to dramatically improve security and reduce risk by helping organizations make better security decisions and maximize the effectiveness of their existing security people, processes, and products.', 'My role was to program the entire front-end of the website, meeting cross-browser, cross-platform, and usability standards. The site is also very heavily integrated with a content management system that was previously used, but needed to be completely re-done to accomidate the new features on the site. Coding, making graphics, scripting, and de-bugging were the major roles I played in this project.<br /><br />\r\nThe project itself was a daunting task as time, tools, and learning curves all play significant roles in the project life cycle and timeline. With all the obsticles in our path, essentially a 2 man team was able to met the project deadline and deliver the best possible solution with the project requirements and constraints.', 'trusecure_1.jpg', 'trusecure_2.jpg', 'trusecure_3.jpg', 1),
(7, 6, 'bitPimps Custom Modifications', 'bitpimps.lixlink.com', 'A community leading hobby web site, bitPimps Custom Modifications draws in large numbers of traffic and members by offering fresh information, articles, tutorials, entertainment, and contests related to the micro r/c hobby world.<br /><br />\r\nThe web site also allows visitors to join as members in a discussion forum for members who are seeking more specific information, want learn more, show off, and more.', 'From concept, through construction, then on to maintenance and administration &#8212; I am responsible for it all. In the beginning, I had some concept brain-storming sessions with a few close friends, that gave me the base of the concept. From there on out, I was the only person to design, develop, and maintain the web site.<br /><br />\r\nNow with over well over 400 members and steadily growing, I now over-see a team of forum moderators who help me keep the forums clean and members following the rules.<br /><br />\r\nI have implemented administration screens to help me out when updating content and image galleries on the site. Each page is dynamically created on the server from information entered into the content management system in the administration area.', 'bitpimps_1.jpg', 'bitpimps_2.jpg', 'bitpimps_3.jpg', 1),
(8, 4, 'e-Wireless (#333)', 'none', 'e-Wireless (#333) was a company using cell phone technology to offer consumers connection services, advertisements, information gathering, etc. Sponsors and advertisers could manage advertisements, when they were played, how often, review the ads exposure, results from the ads, and more. Managers could administer sponsors, review calls places, sponsors and advertisers account information and activity, and more.', 'In one of many roles, I helped with the web site architecture, some design and back-end programming. Most of my work was done on the front-end programming aspect where I translated all the designs into workable HTML pages that interfaced with back-end server technologies and applications.', '333_1.jpg', '333_2.jpg', '333_3.jpg', 1),
(10, 5, 'AXS Technologies', 'www.axs-tech.com', 'AXS Technologies is a world leader in developing software technologies that help speed the delivery of data, such as hi-res imaging, data mining, signal correlation, storage, and more.', 'My role was to program the designs in to functioning web pages, and integrating the companies &quot;EyeSpy&quot; technology in to the web site itself. Some features include EyeSpy image demo\'s, Tell a Friend and Contact forms, dynamically generated pages, Press Releases maintained by administration screens, and more.', 'axstech_1.jpg', 'axstech_2.jpg', 'axstech_3.jpg', 1),
(11, 7, 'IconProcess', 'www.iconprocess.com', 'IconProcess is a site based around e-development processes for web and software developers. The site itself, the name, branding, architecture, design, programming, etc. was all built from nothing but an idea. Visitors can request whitepaper downloads, review IconProcess training materials, subscribe to newsletters, and more.', 'My role was to program the entire site including most of the back-end functionality. Features like subscribing, news and press releases, tell a friend, download requests, contact forms, etc. are all maintained via an administration portal provided through an interface identical to that of the public site.', 'iconprocess_1.jpg', 'iconprocess_2.jpg', 'iconprocess_3.jpg', 1),
(12, 9, 'IconTraining', 'training.iconmedialab.com', 'IconTraining advertises and offers custom training solutions to businesses and individuals. The site announces the latest in training methods, key speakers, locations, and more. All of this information is stored in a database and the web site itself is dynamically data-driven and maintained through administration screens. Visitors can subscribe to newsletters, request more information on training, schedule and purchase training courses all via the web site.', 'My main role was to program the entire front-end of the web site as well as part of the back-end. I\'ve also maintained and updated the site regularly as well as adding on new features that tie in to more data-driven content.', 'icontraining_1.jpg', 'icontraining_2.jpg', 'icontraining_3.jpg', 1),
(13, 12, 'IAHP', 'www.iahp.com', 'IAHP, short for International Alliance of Healthcare Practitioners, offers information to visitors and a chance for healthcare professionals to join the IAHP alliance, get listed in the directory, and buy a templated micro-site. IAHP offers both patients and practitioners a chance to enhance their knowledge and network with others. All of this is managed through administration screens that handle transactions and automatically setup micro-sites, and more.', 'My main role was to program the entire front end of the web site, as well as support the project by coming up with new ideas to achieve certain goals such as attracting potential customers and providing current customers the ability to create and manage their own micro-site through an administration interface provided to members of the web site.', 'iahp_1.jpg', 'iahp_2.jpg', 'iahp_3.jpg', 1),
(14, 13, 'IAHE', 'www.iahe.com', 'IAHE (International Alliance of Healthcare Educators is a site dedicated to the presentation of high-quality educational programs for interested healthcare professionals from all disciplines.', 'My roles were to help program some of the front-end elements in to the site as well as help maintain and update the site per the client\'s requests. Frequent database updates and additions as well as code changes to functionality.', 'iahe_1.jpg', 'iahe_2.jpg', 'iahe_3.jpg', 1),
(15, 8, 'IconProject Site', 'none', 'This is an internal tool used by IconMedialab project managers, team members, and clients. The purpose of the tool is to help keep track of resources, schedules, tasks, files, communications, and more.<br /><br />\r\nThe site recognizes members and returns information based on their role, status, and project involvment.', 'I programmed the entire front-end of the web site, helped with middle-ware and back-end development. Conception, layout, and partial design were also a portion of my tasks. I also help maintain and package the site for re-installation, and more.', 'iconprojectsite_1.jpg', 'iconprojectsite_2.jpg', 'iconprojectsite_3.jpg', 1),
(16, 10, 'IconConsultants Db', 'none', 'This application allows users with the proper permissions to administer all consultants for the St. Louis and DC offices. Administrators can check availability, schedules, billing rates, as well as get an over all report on bench time, and more.', 'My role was to help conceptualize, layout, design, and program the entire front-end and middle-ware pieces of the web site. Maintenance and enhancements are an on-going task.', 'iconconsultantdb_1.jpg', 'iconconsultantdb_2.jpg', 'iconconsultantdb_3.jpg', 1),
(17, 14, 'Scott D. Lix (v.1.0)', 'none', 'This was my first version of my personal web site that contained a blog, portfolio, media archives, and a toolbox. I designed and programmed the entire site from front to back and added features like the ability to increase or decrease text sizes, tell a friend, perform searches, and more.', 'The site itself was completely data-driven and utilized a templating system, making updates quick and easy through administration screens I also provided to help maintain all aspects of content through-out the site.', 'lixlink_1.jpg', 'lixlink_2.jpg', 'lixlink_3.jpg', 1),
(18, 11, 'IconCampaign Tracker', 'none', 'The IconCampaign Tracker allows sales staff from all the IconMedialab offices to keep track of the campaigns they send out. The tracker keeps records of what campaigns were sent out, when they were sent out, which link was clicked on, and who clicked on what link.', 'My role was to complete the marketing tool in 1 day, have it functionable and usable � which I did. I was the main developer from inception to implementation, I designed and programmed the entire tool.', 'iconcampaigntracker_1.jpg', 'iconcampaigntracker_2.jpg', 'iconcampaigntracker_3.jpg', 1);
# --------------------------------------------------------

#
# Table structure for table `photogallery`
#

DROP TABLE IF EXISTS photogallery;
CREATE TABLE photogallery (
  photoEntryId int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  notes text NOT NULL,
  thumb varchar(30) NOT NULL default '',
  photo varchar(30) NOT NULL default '',
  PRIMARY KEY  (photoEntryId)
) TYPE=MyISAM;

#
# Dumping data for table `photogallery`
#

# --------------------------------------------------------

#
# Table structure for table `resume_metainformation`
#

DROP TABLE IF EXISTS resume_metainformation;
CREATE TABLE resume_metainformation (
  title text NOT NULL,
  keywords text NOT NULL,
  description text NOT NULL
) TYPE=MyISAM;

#
# Dumping data for table `resume_metainformation`
#

# --------------------------------------------------------

#
# Table structure for table `resume_projectinformation`
#

DROP TABLE IF EXISTS resume_projectinformation;
CREATE TABLE resume_projectinformation (
  projectEntryID int(11) NOT NULL auto_increment,
  publishFlag tinyint(4) NOT NULL default '0',
  project text NOT NULL,
  projectUrl text NOT NULL,
  projectOverview text NOT NULL,
  projectShot1 text NOT NULL,
  projectShot2 text NOT NULL,
  projectShot3 text NOT NULL,
  PRIMARY KEY  (projectEntryID)
) TYPE=MyISAM;

#
# Dumping data for table `resume_projectinformation`
#

INSERT INTO resume_projectinformation (projectEntryID, publishFlag, project, projectUrl, projectOverview, projectShot1, projectShot2, projectShot3) VALUES (1, 0, 'ZeaVision', 'www.zeavision.com', '', 'zeavision_1.jpg', 'zeavision_2.jpg', 'zeavision_3.jpg'),
(2, 0, 'Wear-Dated', 'www.wear-dated.com', '', 'weardated_1.jpg', 'weardated_2.jpg', 'weardated_3.jpg');

