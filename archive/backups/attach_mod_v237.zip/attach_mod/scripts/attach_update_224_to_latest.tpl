
<!-- BEGIN switch_migrate_mimes -->
<h1>Migrate Mime Types</h1>

<p>{L_EXPLAIN}</p>

<form method="post" action="{S_ACTION}">
  <table width="100%" align="center" cellpadding="4" cellspacing="1" border="0" class="forumline">
	<tr> 
	  <td class="catHead" colspan="5" align="center" height="28"><span class="cattitle">Migrate Mime Types</span> 
	  </td>
	</tr>
	<tr> 
	  <th class="thLeft">&nbsp;Mime Type&nbsp;</th>
	  <th>&nbsp;Extension (If empty, it will be not added)&nbsp;</th>
	  <th class="thRight">&nbsp;Comment (you don't have to fill this field)&nbsp;</th>
	</tr>
<!-- BEGIN extension_row -->
	<tr> 
	  <input type="hidden" name="group_id_list[]" value="{switch_migrate_mimes.extension_row.GROUP_ID}" />
	  <td class="row1" align="center" valign="middle"><span class="gen"><b>{switch_migrate_mimes.extension_row.MIMETYPE}</b></span></td>
	  <td class="row2" align="center" valign="middle"><input type="text" size="30" maxlength="100" name="extension_list[]" value="{switch_migrate_mimes.extension_row.EXTENSION}" /></td>
	  <td class="row1" align="center" valign="middle"><input type="text" size="30" maxlength="100" name="comment_list[]" value="" /></td>
	</tr>
<!-- END extension_row -->
	<tr align="right"> 
	  <td class="catBottom" colspan="3" height="29"> 
	  <input type="submit" name="submit" class="liteoption" value="Migrate Data" /></td>
	</tr>
</table>

</form>

<!-- END switch_migrate_mimes -->
