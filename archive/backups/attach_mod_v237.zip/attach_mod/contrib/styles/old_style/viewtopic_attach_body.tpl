
<!-- BEGIN attach -->
<br /><br /><hr><br />
	<!-- BEGIN denyrow -->
	<span class="postbody">[{postrow.attach.denyrow.L_DENIED}]</span><br /><br />
	<!-- END denyrow -->
	<!-- BEGIN cat_stream -->
	<span class="postbody">{postrow.attach.cat_stream.COMMENT}</span><br />
	<object id="wmp" classid="CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95" codebase="http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=6,0,0,0" standby="Loading Microsoft Windows Media Player components..." type="application/x-oleobject"> 
	<param name="FileName" value="{postrow.attach.cat_stream.U_DOWNLOAD_LINK}"> 
	<param name="ShowControls" value="1"> 
	<param name="ShowDisplay" value="0"> 
	<param name="ShowStatusBar" value="1"> 
	<param name="AutoSize" value="1"> 
	<param name="AutoStart" value="0"> 
	<param name="Visible" value="1"> 
	<param name="AnimationStart" value="0"> 
	<param name="Loop" value="0"> 
	<embed type="application/x-mplayer2" pluginspage="http://www.microsoft.com/windows95/downloads/contents/wurecommended/s_wufeatured/mediaplayer/default.asp" src="{postrow.attach.cat_stream.U_DOWNLOAD_LINK}" name=MediaPlayer2 showcontrols=1 showdisplay=0 showstatusbar=1 autosize=1 autostart=0 visible=1 animationatstart=0 loop=0></embed> 
	</object>
	<br /><span class="gensmall">{postrow.attach.cat_stream.DOWNLOAD_NAME} - {postrow.attach.cat_stream.L_DOWNLOAD_COUNT}</span><br /><br />
	<!-- END cat_stream -->
	<!-- BEGIN cat_swf -->
    <span class="postbody">{postrow.attach.cat_swf.COMMENT}<br />
	<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" WIDTH="{postrow.attach.cat_swf.WIDTH}" HEIGHT="{postrow.attach.cat_swf.HEIGHT}"> 
	<PARAM NAME=movie VALUE="{postrow.attach.cat_swf.U_DOWNLOAD_LINK}"> 
	<PARAM NAME=loop VALUE=1> 
	<PARAM NAME=quality VALUE=high> 
	<PARAM NAME=scale VALUE=noborder> 
	<PARAM NAME=wmode VALUE=transparent> 
	<PARAM NAME=bgcolor VALUE=#000000> 
	<EMBED src="{postrow.attach.cat_swf.U_DOWNLOAD_LINK}" loop=1 quality=high scale=noborder wmode=transparent bgcolor=#000000  WIDTH="{postrow.attach.cat_swf.WIDTH}" HEIGHT="{postrow.attach.cat_swf.HEIGHT}" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></EMBED> 
	</OBJECT> 
	<br /><span class="gensmall">{postrow.attach.cat_swf.DOWNLOAD_NAME} - {postrow.attach.cat_swf.L_DOWNLOAD_COUNT}</span><br /><br />
	<!-- END cat_swf -->
	<!-- BEGIN cat_images -->
	<span class="postbody">{postrow.attach.cat_images.COMMENT}<br />
	<img src="{postrow.attach.cat_images.IMG_SRC}" alt="{postrow.attach.cat_images.DOWNLOAD_NAME}" /></span><br />
	<span class="gensmall">{postrow.attach.cat_images.DOWNLOAD_NAME} - {postrow.attach.cat_images.L_DOWNLOAD_COUNT}</span><br /><br />
	<!-- END cat_images -->
	<!-- BEGIN cat_thumb_images -->
	<span class="postbody">{postrow.attach.cat_thumb_images.COMMENT}<br />
	<a href="{postrow.attach.cat_thumb_images.IMG_SRC}" target="_blank">
	<img src="{postrow.attach.cat_thumb_images.IMG_THUMB_SRC}" alt="{postrow.attach.cat_thumb_images.DOWNLOAD_NAME}" border="0" /></a></span><br />
	<span class="gensmall">{postrow.attach.cat_thumb_images.DOWNLOAD_NAME} - {postrow.attach.cat_thumb_images.L_DOWNLOAD_COUNT}</span><br /><br />
	<!-- END cat_thumb_images -->
	<!-- BEGIN attachrow -->
	<span class="postbody">{postrow.attach.attachrow.COMMENT}</span><br />
	<span class="postbody">{postrow.attach.attachrow.S_UPLOAD_IMAGE} 
	<a href="{postrow.attach.attachrow.U_DOWNLOAD_LINK}" {postrow.attach.attachrow.TARGET_BLANK}>{postrow.attach.attachrow.DOWNLOAD_NAME}</a> - {postrow.attach.attachrow.FILESIZE} {L_KILOBYTE}<br /></span>
	<span class="gensmall">{postrow.attach.attachrow.L_DOWNLOAD_COUNT}</span><br /><br />
	<!-- END attachrow -->
 <!-- END attach -->		  
