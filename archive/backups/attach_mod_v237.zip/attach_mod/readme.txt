Installation Instructions:

This is Version 2.3.7 of the Attachment Mod.

The File Attachment Mod only supports phpBB 2.0.x (up to Version 2.0.4).
The File Attachment Mod does not support *Nuke Portals.

Please read the Attachment Mod User Guide (docs/user_guide.html) to get familiar with the Attachment Mod.

For Installation Instructions, please read docs/install.txt.
If you want to update, you do not need to read docs/install.txt, instead read
the Documents at docs/update.

Upgrading Instructions:

Please read the Instructions in docs/update if you want to update.

For example, if you are upgrading from Version 2.2.2, 
please read: docs/update/update_222_to_latest.txt

---

Some Informations on the contrib and scripts directory.

For Informations what is placed into the contrib directory, please read: contrib/readme.txt

In the scripts directory you will find several needed update and install/uninstall scripts.
All these 'scripts' have to be uploaded to the phpBB2 Root Directory in order to work.
For additional Informations what is placed into the scripts directory, please read: scripts/readme.txt
