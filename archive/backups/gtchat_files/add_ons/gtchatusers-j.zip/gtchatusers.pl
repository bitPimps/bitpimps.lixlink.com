#!/usr/bin/perl

#########################################################
#             GT-ChatUsers 0.93 v1.04j                  #
#########################################################

#-> Copyright 2001 by Dominik Leibenger <-#


# Variablen anpassen! / Set up the variables!

# Text der Userliste / Text before the userlist
$starttext = "";

# Text nach der Userliste / Text after the userlist
$endtext = "";

# Text vor einem Raumnamen / Text before a room name
$roomtitlestart = "<br><br><u><b>";

# Text vor dem ersten Raum (falls 0 dann Standardname) /
# Text before the first rooms name (if 0 then the standard name)
$roomtitlefirstroomstart = 0;

# Text nach einem Raumnamen / Text after a room name
$roomtitleend = "</u></b><br>";

# Text vor einem Usernamen / Text before a username
$usernamestart = "";

# Text nach einem Usernamen / Text after a username
$usernameend = "";

# Text zwischen 2 Usernamen / Text between two usernames
$betweenusers = ", ";

# Private R�ume anzeigen / Show private rooms
$privaterooms = 0;

### Wenn privaterooms = 1 / If privaterooms = 1 ###

# Private R�ume werden gekennzeichnet / Private rooms will be tagged
$showprivatetag = 0;

#########################################################

require "Settings.dat";
require "Directories.dat";
require "$sourcedir/Subs.pl";
require "$language.lng";

$nousers = "<br>$text{login_nouseronline}";

if(($roomtitlefirstroomstart eq "0") || ($roomtitlefirstroomstart == 0))
{
  $roomtitlefirstroomstart = $roomtitlestart;
}

$output = $starttext;

print "Content-Type: application/x-javascript\n";
print "Pragma: no-cache\n";
print "Expires: now\n\n";
print "document.write('";

my %roomlist;

opendir(DIR,$vardir);

for (readdir(DIR))
{
  if (/^online\._/)
  {
    open(FILE,"$vardir/$_");
    readlock(FILE);
    my ($name,$id,$nick,$room,$pull) = split(/\|/,<FILE>);
    unlock(FILE);
    close(FILE);

    $roomlist{$room} .= " $nick";
  }
}

closedir(DIR);

$roomnumber = 0;
$countusers = 0;

foreach my $room (sort keys %roomlist)
{
  my %chatroominfo;
  if($showprivatetag)
  {
    %chatroominfo = getRoomInfo($room);
  }
  if(!$privaterooms)
  {
    if(!$showprivatetag)
    {
      %chatroominfo = getRoomInfo($room);
    }
    if($chatroominfo{'closed'})
    {
      next;
    }
  }

  ++$roomnumber;

  if($chatroominfo{'closed'})
  {
    if($roomnumber == 1)
    {
      $output .= "$roomtitlefirstroomstart$room ($text{roomlist_state_private})$roomtitleend";
    }
     else
    {
      $output .= "$roomtitlestart$room ($text{roomlist_state_private})$roomtitleend";
    }
  }
   else
  {
    if($roomnumber == 1)
    {
      $output .= "$roomtitlefirstroomstart$room$roomtitleend";
    }
     else
    {
      $output .= "$roomtitlestart$room$roomtitleend";
    }
  }

  $firstuser = 0;

  foreach $chatuser (sort split(/ /,$roomlist{$room}))
  {
    if($chatuser ne "")
    {
      ++$countusers;
      if($firstuser == 0)
      {
        $output .= "$usernamestart$chatuser$usernameend";
        $firstuser = 1;
      }
       else
      {
        $output .= "$betweenusers$usernamestart$chatuser$usernameend";
      }
    }
  }
}

if ($countusers <= 0)
{
  $output .= "$nousers";
}

$output .= "$endtext";
$output =~ s/\'/\\\'/g;

print "$output";
print "');";

exit;
