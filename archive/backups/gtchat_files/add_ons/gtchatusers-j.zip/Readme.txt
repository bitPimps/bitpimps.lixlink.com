GT-ChatUsers 0.93 v1.04j
========================
(Java script version)

--> Copyright 2001 by Dominik Leibenger

Short Info
----------

This Script shows the list with active users of the
chatscript GTChat from Wladimir Palant (www.gtchat.de).
This is the java script version. It's the same than the
SSI version, only with java script.

Data
----

- Version: 1.04j
- GTChat Version: 0.93

Author/Contact
--------------

Author: Dominik Leibenger

Homepage:       http://www.funsite2000.de
Email:          dominik@funsite2000.de
ICQ-Number:     50477052
MSN-Messenger:  derleibi@hotmail.com

I will be happy if you send me some feedback! :-)

Much thanks to Trevize (Wladimir Palant), who programmed this
chat!

And much thanks to Cane (Wolf M. Gerlach) and Kralle, too, because
they were the beta-testers of this script.

Installation
------------

The installation of this script is easy and fast.
You only have to load up this script with chmod 755 in the chat
directory.

Then you can include this script per java script in some html
pages. You only have to add
<script language="JavaScript" src="URL"></script>
at the place, where the list should be.

Changing the variables
----------------------

Normally, you don't have to change any variables.
But if you want, you can change them in gtchatusers.pl (there is
a short manual for that).

----------------------------------------------------------------------

That was all! Much Fun!
You can change the code of this script, but please send me an email
if you want to do that.

Well, and don't forget to send me some feedback!

The Copyright-Information in the gtchatusers.pl mustn't be changed
or deleted!

----------------------------------------------------------------------

...and the history:
(It's the same than the history of the SSI version.)

v1.04:
- $roomtitlestart can be defined seperately for the first room.

v1.03:
- The script is faster now!
- The text "closed" at private rooms (if activated), can be disabled now
- A little bug has been patched

v1.02:
- Now the bug has really been patched!

v1.01:
- A bug has been patched (now the script shows the nicknames and not the usernames)

v1.0:
- The first version of this script