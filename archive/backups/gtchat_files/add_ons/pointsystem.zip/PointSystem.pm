################################################################################
#                                                                              #
#  PointSystem.pm 0.95a40115                                                   #
#                                                                              #
#  GTChat 0.95 Alpha Plugin                                                    #
#  Written for release 20040112                                                #
#  Author: Norman Rath                                                         #
#  E-Mail: Norman.Rath@o2online.de                                             #
#                                                                              #
#  This plugin is a time PointSystem                                           #
#                                                                              #
################################################################################

package GTChat::Plugins::PointSystem;
use strict;

bless({
	template_var_handlers => {
		'pointsystem' => \&handler,
		'pointsystem_profil' => \&handlerProfil,
	},
});

sub handler
{
	my($self,$main) = @_;

	my @pointsystemusers=();

	my $users = $main->getAllUsers();

	for (my $i = 0; $i <= $#$users; $i++)
	{
		my($nickname,$username) = split(/\|/,$users->[$i]);
		my $user = $main->loadUser($username);
		next if($user->{group} eq '-1' || $user->{points} == 0);
		push @pointsystemusers, $user->{points}."|".$user->{name};
	}

	@pointsystemusers = sort({$b <=> $a} @pointsystemusers);

	my @ret=();
	my $user;
	my $count=0;

	foreach (@pointsystemusers)
	{
		$count++;
		$_ =~ s/[\n\r]//g;
		my($points,$name) = split(/\|/,$_);
		my $user = $main->loadUser($name);
		$user->{count} = $count;
		$user->{points} = sprintf "%.0f",$user->{points};
		$user->{seconds} = $user->{onlinetime} % 60;
		$user->{minutes} = $user->{onlinetime} / 60 % 60;
		$user->{hours} = $user->{onlinetime} / (60 * 60) % 24;
		$user->{days} = int($user->{onlinetime}  / (60 * 60 * 24));
		$user->{online} = ($main->loadOnlineInfo($user->{name},$user) ? 1 : 0);

		push @ret, $user;
		last if($count == $main->{input}{nr});
	}

	$main->{template_vars}{pointsystem} = \@ret;
}

sub handlerProfil
{
	my($self,$main) = @_;

        my $user = $main->{template_vars}{user_information};

	$user->{points} = sprintf "%.0f",$user->{points};
	$user->{points} = 0 if(!$user->{points});
	$user->{seconds} = $user->{onlinetime} % 60;
	$user->{minutes} = $user->{onlinetime} / 60 % 60;
	$user->{hours} = $user->{onlinetime} / (60 * 60) % 24;
	$user->{days} = int($user->{onlinetime}  / (60 * 60 * 24));

	$main->{template_vars}{user_information} = $user;
}

sub logoutPerformed
{
	my($self,$main) = @_;
	
	my $user = $main->{current_user};

	if($user->{group} ne '-1')
	{
		my $onlinetime = $main->{runtime}{now} - $user->{lastlogin};

		$user->{onlinetime} += +$onlinetime;

		my $timepoints = ($main->{runtime}{now} - $user->{lastlogin}) / 60;

		$timepoints -= 10 if(!$user->{points} && $user->{onlinetime} < 600);

		$timepoints = 0 if($timepoints < 0);

		$user->{points} += $timepoints;

		$main->saveUser($user) if($main->{current_user}{name});
	}
}
