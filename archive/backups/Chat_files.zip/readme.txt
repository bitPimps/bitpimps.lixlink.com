To install this ChatRoom on your personal Webpage you need:
1. Host must have Perl based CGI and it should be available to you.
2. From your user directory create directory ~/cgi-bin/chat
3. Copy MF,CF and chat.cgi files in this directory.
4. Change permission for MF and CF files to 666 (rw-rw-rw);
5. To do this just run "chmod 666 ~/cgi-bin/chat/MF" and "chmod 666 ~/cgi-bin/chat/CF"
6. Change permission for chat.cgi to 555 (rx-rx-rx), run "chmod 555 ~/cgi-bin/chat/MF.
7. Create ~/java directory and copy there Chat.jar file. 
8. Put your chat.html to your "~/" directory