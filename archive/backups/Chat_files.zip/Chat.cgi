#!/usr/bin/perl
if ($ENV{'REQUEST_METHOD'} eq "POST") {
read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
$RA=$ENV{'REMOTE_ADDR'};
@a=split(/:/,$buffer,2);
$com=$a[0]; 
$inrest=$a[1]."\n";
@r= split(/ /,$inrest,2);
%ndb=();
%mdata=();
@messages=();
@names=(); 
$sec_now=time();
@messages = &readFile("MF");
if(scalar(@messages)> 26 ) { shift  @messages; }
for(@messages ){  s/(.*?)://; if(length($_)>2){  $mdata{$1} =  $_; 
						 push(@m,$1);$last=$1;}} 
$new=1;
@n = &readFile("CF"); 
for(@n){
    s/(.*?):(.*?):(.*?)://;   $num=$1; $ip=$2; $lt=$3; $nrest=$_;   s/\W//;  
    if((length($nrest)) >1 ){      
	if ( $ip eq $RA ) { $mn= $num; $num=$last;  $lt=$sec_now;  $new=0; $nrest=$r[0]." \n"; }
	$ndb{$ip}[0]=$num; 
	$ndb{$ip}[1]=$lt; 
	$ndb{$ip}[2]=$nrest; 
	if (($sec_now - $lt) > 20)   {delete $ndb{$ip};}
         } } 
@names=keys %ndb; 


if( $new==1){
    $ndb {$RA}[0]= $last; $mn=0; 
    $ndb {$RA}[1]= $sec_now; 
    $ndb {$RA}[2]= $inrest;
    push  (@names, $RA); }

if ($com eq "s"){ push (@m, ($last + 1)) ; 
$mdata{($last + 1)}=$inrest; $ndb {$RA}[0]=  $last+1; &writeMsg; }
&write_name; 
print "Content-type:  text/html\n\nEGAssEM:";
for(@m){ 
if ($mn < $_ ) {print  "0:".$mdata{$_};}
}   
print "SemAN:";  for(@names){print  "0:".$ndb{$_}[2] ;}
exit(0);      
}
exit(0);

sub write_name{
    open (CLIENT_FILE,">CF" )|| &exit();
    flock(CLIENT_FILE,2) ;
    for(@names){
	print CLIENT_FILE $ndb{$_}[0].":".$_.":".$ndb{$_}[1].":".$ndb{$_}[2];}  
    flock( CLIENT_FILE, 8);
    close ( CLIENT_FILE);
}


sub writeMsg{
    open (MESSAGE_FILE,">MF" )|| &exit();
    flock(MESSAGE_FILE, 2); 
    for (@m){print MESSAGE_FILE   $_.":".$mdata{$_}; }
    flock(MESSAGE_FILE, 8);
    close (MESSAGE_FILE);
    
}

sub readFile		{
    my($file_to_read) = @_;
    my(@file_in);
    open(FILE_IN, "$file_to_read") ||  &exit();	
    @file_in = <FILE_IN>;
    close(FILE_IN);
    return @file_in;
    }


