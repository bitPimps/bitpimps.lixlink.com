<?php

//
// Italian Language File for Topics Anywhere
// Author: Antonio Mercurio (or Mercurio) < antonio.mercurio@progetto.sardegna.it >
//

$lang['Topics_anywhere'] = 'I tuoi forum ovunque';
$lang['Topics_anywhere_explain'] = 'Inserisci i titoli degli argomenti del vostro forum in qualunque pagina preferite. In questa parte potete selezionare le preferenze di visualizzazione.';
$lang['Lastpost_from'] = 'Ultimo messaggio di';
$lang['disc'] = 'disco';
$lang['circle'] = 'cerchio';
$lang['square'] = 'quadrato';
$lang['numbered'] = 'numerato';
$lang['Select_forum_explain'] = 'Seleziona il forum di cui vuoi visualizzare gli argomenti - tieni premuto CTRL per selezionare pi� forum';
$lang['Or'] = 'O';
$lang['Amount_topics'] = 'Quanti argomenti?';
$lang['Amount_topics_explain'] = 'Indica il numero di argomenti da mostrare';
$lang['Show_replies'] = 'Mostra risposte?';
$lang['Show_replies_explain'] = 'Verr� visualizzato il numero delle risposte se si seleziona si';
$lang['Show_replies_word'] = 'Mostra la parola \'Risposte\'?';
$lang['Show_replies_word_explain'] = 'Se si sceglie di mostrare il numero delle risposte, potete selezionare la forma breve (p.e. <b>45</b> selezionando NO) oppure la forma estesa (p.e. <b>45 Risposta</b> selezionando SI)';
$lang['Show_announce'] = 'Mostra argomenti <b>annuncio</b>?';
$lang['Show_sticky'] = 'Mostra argomenti <b>sticky</b>?';
$lang['Show_locked'] = 'Mostra argomenti <b>bloccati</b>?';
$lang['Show_moved'] = 'Mostra argomenti <b>spostati</b>?';
$lang['Bullet_type'] = 'Punti elenco?';
$lang['Bullet_type_explain'] = 'Seleziona un punto elenco (bullet) da mostrare prima di ciascun link';
$lang['Show_lastpostby'] = 'Mostra l\'user dell\'ultimo messaggio?';
$lang['Show_lastpostby_explain'] = 'Se si, verr� visualizzato l\'utente che ha scritto l\'ultimo messaggio';
$lang['Lastpostby_format'] = 'Formato utente ultimo messaggio';
$lang['Lastpostby_format_explain'] = 'Come si deve visualizzare l\'utente che ha scritto l\'ultimo messaggio?';
$lang['Show_lastpostdate'] = 'Visualizza data ultimo messaggio?';
$lang['Show_lastpostdate_explain'] = 'Se impostato a si, verr� visualizzata la data e l\'orario dell\'ultimo messaggio';
$lang['Lastpostdate_format'] = 'Formato data ultimo messaggio';
$lang['Lastpostdate_format_explain'] = 'Selezionare il formato in cui verr� visualizzata la data dell\'ultimo messaggio';
$lang['Show_lastposticon'] = 'Mostra icona "vai ad ultimo messaggio"?';
$lang['Show_lastposticon_explain'] = 'Se si seleziona SI, verr� mostrata un\'icona che condurr� all\'ultimo messaggio dell\'argomento selezionato';
$lang['CSS_link'] = 'CSS per i link';
$lang['CSS_link_explain'] = 'Definisce una classe CSS per usare per i link - lasciare in bianco se non si usa questa opzione';
$lang['CSS_text'] = 'CSS per il testo';
$lang['CSS_text_explain'] = 'Definisce una classe CSS per il testo escluso i link - lasciare in bianco se non si usa questa opzione';
$lang['Target_link'] = 'Frame di Destinazione del link';
$lang['Target_link_explain'] = 'Definisce il frame di destinazione del link, ovvero dove verr� aperta la nuova pagina (p.e. _top, parent, _blank) se non compilato il target sar� \'_self\'';
$lang['Pick_a_forum'] = 'Dovete selezionare un forum...';
$lang['Invalid_amount'] = 'Avete specificato un numero non valido di risposte da mostrare...';
$lang['Invalid_class'] = 'Avete specificato una classe invalida...';
$lang['Invalid_target'] = 'Frame di destinazione non valida...';
$lang['Click_return'] = 'Cliccate qui per ritornare';
$lang['Copy_paste'] = 'Codice HTML da copiare e incollare';
$lang['Copy_paste_explain'] = 'Copiate questo codice HTML ed incollatelo nella pagina in cui volete mostrare l\'elenco degli argomenti <b>non modificatelo in nessun modo</b>';
$lang['The_result'] = 'Anteprima';
$lang['Classes_remark'] = 'Se avete specificato un CSS per i link o per il testo, potrebbero non essere correttamente applicati';
$lang['No_topics'] = 'Non ci sono argomenti';
$lang['Topic_Locked'] = '<b>(Bloccato)</b>';
$lang['Reply'] = 'Risposta';
$lang['Select_forum'] = 'Seleziona forum';
$lang['In'] = 'in';
$lang['Show_forum_name'] = 'Mostra nome del forum';
$lang['Show_forum_name_explain'] = 'Se si seleziona si, verr� mostrato il nome del forum in cui si trova l\'argomento';
$lang['Link_forum_name'] = 'Assegna un link al nome del forum';
$lang['Link_forum_name_explain'] = 'Se l\'opzione precedente � attiva, allora il nome del forum sar� un link cliccabile';
$lang['Sorry_auth_topicsanywhere'] = 'Spiacente ma solo gli user con livello %s possono configurare Topics Anywhere';
$lang['Sort_order'] = 'Sort order';
$lang['Sort_order_explain'] = '\'Priority\' means show first announcements, then sticky topics, then normal topics, \'On date\' shows topics with most recent posts';
$lang['Priority'] = 'Priority';
$lang['On_date'] = 'On date';
$lang['Add_break'] = 'Add a break';
$lang['Add_break_explain'] = 'To improve readability you can use a line break to show topic title and last poster info on seperate lines';
$lang['Lastposticon_as_bullet'] = 'Use the jump to last post icon as bullet';
$lang['Lastposticon_as_bullet_explain'] = 'You can choose to use the jump to last post icon as a bullet - note that this will override any bullet selection above'

?>