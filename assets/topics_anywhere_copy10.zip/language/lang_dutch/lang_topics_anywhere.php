<?php

//
// Flemish Language File for Topics Anywhere
// Author: Dennis Heeren (or DtM) < dennis.heeren@advalvas.be >
//

$lang['Topics_anywhere_explain'] = 'Plaats links naar de onderwerpen uit eender welk forum van je phpBB op elke site die je wilt... Hier kun je je voorkeuren instellen over hoe die links moeten worden weergegeven.';
$lang['Lastpost_from'] = 'Laatste post door';
$lang['disc'] = 'schijf';
$lang['circle'] = 'cirkel';
$lang['square'] = 'vierkant';
$lang['numbered'] = 'genummerd';
$lang['Select_forum_explain'] = 'Kies hier uit welk forum de onderwerpen moeten komen - houdt de CTRL-toets ingedrukt om meerdere fora te selecteren';
$lang['Or'] = 'OF';
$lang['Amount_topics'] = 'Hoeveel onderwerpen?';
$lang['Amount_topics_explain'] = 'Stel het aantal te tonen onderwerpen in';
$lang['Show_replies'] = 'Toon antwoorden?';
$lang['Show_replies_explain'] = 'Het aantal antwoorden in het onderwerp wordt weergegeven indien ja geselecteerd is';
$lang['Show_replies_word'] = 'Toon het woord \'Antwoorden\'?';
$lang['Show_replies_word_explain'] = 'Indien bij de vorige optie ja geselecteerd is, kan hier gekozen worden om de lange vorm (bv. \'45 Antwoorden\' - selecteer ja) of de korte vorm (bv. \'(45)\' - selecteer nee) weer te geven voor het aantal antwoorden';
$lang['Show_announce'] = 'Toon aankondigen?';
$lang['Show_sticky'] = 'Toon sticky\'s?';
$lang['Show_locked'] = 'Toon gesloten onderwerpen?';
$lang['Show_moved'] = 'Toon verplaatste onderwerpen?';
$lang['Bullet_type'] = 'Lijstteken?';
$lang['Bullet_type_explain'] = 'Kies het soort lijstteken dat voor elke link zal staan';
$lang['Show_lastpostby'] = 'Toon laatste poster?';
$lang['Show_lastpostby_explain'] = 'Indien ja wordt de gebruikersnaam van de gebruiker die het laatste antwoord heeft gepost weergegeven';
$lang['Lastpostby_format'] = 'Laatste poster layout';
$lang['Lastpostby_format_explain'] = 'Kies hoe de laatste poster moet worden weergegeven';
$lang['Show_lastpostdate'] = 'Toon datum/tijd laatste antwoord?';
$lang['Show_lastpostdate_explain'] = 'Indien ja wordt de datum en/of tijd wanneer het laatste antwoord is gepost weergegeven';
$lang['Lastpostdate_format'] = 'Laatste post datum/tijd layout';
$lang['Lastpostdate_format_explain'] = 'Kies hoe de laatste post datum/tijd moet worden weergegeven';
$lang['Show_lastposticon'] = 'Toon icoontje laatste antwoord?';
$lang['Show_lastposticon_explain'] = 'Indien ja wordt een icoontje weergegeven die de gebruiker rechtstreeks naar het laatste antwoord in het onderwerp brengt';
$lang['CSS_link'] = 'CSS voor link';
$lang['CSS_link_explain'] = 'Bepaal een CSS class die gebruikt moet worden voor de links - blanco laten indien je geen CSS class wilt gebruiken';
$lang['CSS_text'] = 'CSS voor tekst';
$lang['CSS_text_explain'] = 'Bepaal een CSS class die gebruikt moet worden voor de andere tekst - blanco laten indien je geen CSS class wilt gebruiken';
$lang['Target_link'] = 'Target voor links';
$lang['Target_link_explain'] = 'Bepaal een doel voor de links - ieder geldig target volstaat, ook speciale (_top, _parent, _blank) - blanco laten om \'_self\' te gebruiken';
$lang['Pick_a_forum'] = 'Je moet een forum selecteren...';
$lang['Invalid_amount'] = 'Je hebt een ongeldig aantal opgegeven voor het aantal antwoorden dat getoond moet worden...';
$lang['Invalid_class'] = 'Je hebt een ongeldige class opgegeven...';
$lang['Invalid_target'] = 'Je hebt een ongeldige target opgegeven...';
$lang['Click_return'] = 'Klik hier om terug te keren';
$lang['Copy_paste'] = 'HTML code kopi�ren en plakken';
$lang['Copy_paste_explain'] = 'Kopi�er deze HTML code en plak die in de pagina waar je de topics wilt laten weergeven - enkel kopi�ren en plakken - op geen enkele manier aanpassen';
$lang['The_result'] = 'Zo zal het eruit zien';
$lang['Classes_remark'] = 'Als je CSS classes hebt opgegeven is het waarschijnlijk dat die hier niet goed worden weergegeven';
$lang['No_topics'] = 'Er zijn geen onderwerpen';
$lang['Topic_Locked'] = '<b>(Gesloten)</b>';
$lang['Reply'] = 'Antwoord';
$lang['Select_forum'] = 'Kies forum/fora';
$lang['In'] = 'in';
$lang['Show_forum_name'] = 'Toon forum naam';
$lang['Show_forum_name_explain'] = 'Indien ja wordt de naam van het forum waar het topic in staat weergegeven';
$lang['Link_forum_name'] = 'Forum naam is link';
$lang['Link_forum_name_explain'] = 'Als bij deze en de vorige optie ja geselecteerd worden, zal de forum naam een link naar dat forum worden';
$lang['Sorry_auth_topicsanywhere'] = 'Sorry, alleen %s kunnen Topics Anywhere gebruiken';
$lang['Sort_order'] = 'Sorteervolgorde';
$lang['Sort_order_explain'] = '\'Prioriteit\' toont eerst announcements, dan sticky onderwerpen en daarna de gewone onderwerpen, \'Op datum\' toont de onderwerpen met de recentste posts';
$lang['Priority'] = 'Prioriteit';
$lang['On_date'] = 'Op datum';
$lang['Add_break'] = 'Gebruik een enter';
$lang['Add_break_explain'] = 'Om de leesbaarheid te verhogen is het mogelijk de onderwerptitel en de info van de laatste poster op twee lijnen weer te geven';
$lang['Lastposticon_as_bullet'] = 'Gebruik het icoontje laaste antwoord als lijstteken';
$lang['Lastposticon_as_bullet_explain'] = 'Let op: dit zal elk lijstteken overbruggen dat hierboven werd geselecteerd'

?>