<?php

//
// French Language File for Topics Anywhere
// Author: Eric Fichot (or AideInfo) < phpbb@aideinfo.fr.fm >
//

$lang['Topics_anywhere_explain'] = 'Mettez les titres des sujets du ou des forums de phpBB que vous voulez sur la page que vous voulez... Ici, vous pouvez d�finir vos pr�f�rences sur l\'affichage de ces liens.';
$lang['Lastpost_from'] = 'Dernier message par';
$lang['disc'] = 'rond';
$lang['circle'] = 'cercle';
$lang['square'] = 'carr�';
$lang['numbered'] = 'num�ro';
$lang['Select_forum_explain'] = 'S�lectionnez les forums dont vous voulez afficher les sujets - maintenez la touche CTRL enfonc�e pour s�lectionner plusieurs forums';
$lang['Or'] = 'OU';
$lang['Amount_topics'] = 'Combien de sujets ?';
$lang['Amount_topics_explain'] = 'Sp�cifiez le nombre de sujets � afficher';
$lang['Show_replies'] = 'Afficher le nombre de r�ponses ?';
$lang['Show_replies_explain'] = 'Le nombre de r�ponses sera affich� si Oui est s�lectionn�';
$lang['Show_replies_word'] = 'Afficher le mot \'R�ponses\' ?';
$lang['Show_replies_word_explain'] = 'Si l\'option pr�c�dente est d�finie sur Oui, vous pouvez choisir d\'afficher le format court (i.e. \'(45)\' - cochez Non) ou le format long (i.e. \'(45 R�ponses)\' - cochez Oui)';
$lang['Show_announce'] = 'Afficher les annonces ?';
$lang['Show_sticky'] = 'Afficher les post-it ?';
$lang['Show_locked'] = 'Afficher les sujets verrouill�s ?';
$lang['Show_moved'] = 'Afficher les sujets d�plac�s ?';
$lang['Bullet_type'] = 'Puces ?';
$lang['Bullet_type_explain'] = 'Choisissez un type de puce � afficher devant chaque lien';
$lang['Show_lastpostby'] = 'Afficher le dernier posteur ?';
$lang['Show_lastpostby_explain'] = 'Si Oui, le nom d\'utilisateur du dernier posteur du topic sera affich�';
$lang['Lastpostby_format'] = 'Format d\'affichage du dernier posteur';
$lang['Lastpostby_format_explain'] = 'Comment le dernier posteur sera affich� ?';
$lang['Show_lastpostdate'] = 'Afficher la date du dernier message ?';
$lang['Show_lastpostdate_explain'] = 'Si Oui, la date et/ou l\'heure du dernier message sera(seront) affich�e(s)';
$lang['Lastpostdate_format'] = 'Format de la date du dernier message';
$lang['Lastpostdate_format_explain'] = 'S�lectionnez le format dans lequel vous voulez que la date du dernier message soit affich�e';
$lang['Show_lastposticon'] = 'Afficher l\'ic�ne Voir le dernier message ?';
$lang['Show_lastposticon_explain'] = 'Si Oui, une ic�ne qui vous permettra d\'atteindre le dernier message du sujet sera affich�e';
$lang['CSS_link'] = 'CSS des liens';
$lang['CSS_link_explain'] = 'D�finissez la classe CSS qui sera utilis�e pour les liens - laissez vide si vous ne voulez pas en utiliser';
$lang['CSS_text'] = 'CSS du texte';
$lang['CSS_text_explain'] = 'D�finissez la classe CSS qui sera utilis�e pour le texte - laissez vide si vous ne voulez pas en utiliser';
$lang['Target_link'] = 'Target des liens';
$lang['Target_link_explain'] = 'D�finissez un target pour les liens - tout target valid fonctionnera, y compris les sp�ciaux (_top, _parent, _blank, ...) - laissez vide pour utiliser le traget \'_self\'';
$lang['Pick_a_forum'] = 'Vous devez s�lectionner un forum...';
$lang['Invalid_amount'] = 'Le nombre de r�ponses � afficher sp�cifi� est invalide...';
$lang['Invalid_class'] = 'La classe CSS  sp�cifi�e est invalide...';
$lang['Invalid_target'] = 'le target  sp�cifi� est invalide...';
$lang['Click_return'] = 'Cliquez ici pour revenir';
$lang['Copy_paste'] = 'Code HTML � copier-coller';
$lang['Copy_paste_explain'] = 'Copiez ce code HTML et collez-le sur la page o� vous voulez que la liste des sujets soit affich�e - ne pas le modifier !';
$lang['The_result'] = 'Aper�u';
$lang['Classes_remark'] = 'Si vous sp�cifiez des classes CSS pour les liens ou le texte, ils n\'appara�tront peut-�tre pas correctement ici.';
$lang['No_topics'] = 'Il n\'y a pas de sujets';
$lang['Topic_Locked'] = '<b>(Verrouill�)</b>';
$lang['Reply'] = 'R�ponse';
$lang['Select_forum'] = 'S�lection des forums';
$lang['In'] = 'dans le forum';
$lang['Show_forum_name'] = 'Afficher le nom du forum';
$lang['Show_forum_name_explain'] = 'Si Oui, le nom du forum contenant le sujet sera affich�';
$lang['Link_forum_name'] = 'Afficher le nom du forum sous forme de lien';
$lang['Link_forum_name_explain'] = 'Si les deux derni�res options sont d�finies sur Oui, le nom du forum sera un lien vers ce dernier';
$lang['Sorry_auth_topicsanywhere'] = 'D�sol�, mais seul un %s peut configurer Topics Anywhere';
$lang['Sort_order'] = 'Ordre de tri';
$lang['Sort_order_explain'] = '\'Priorit�\' signifie que sont affich�s d\'abord les annonces, puis les posts-it, et enfin les sujets simples, \'Par date\' affiche les sujets avec les messages les plus r�cents';
$lang['Priority'] = 'Priorit�';
$lang['On_date'] = 'Par date';
$lang['Add_break'] = 'Ajouter un interligne';
$lang['Add_break_explain'] = 'Pour am�liorer la lisibilit�, vous pouvez utiliser un interligne pour afficher les info sur le posteur et le titre du sujet sur des lignes s�par�es';
$lang['Lastposticon_as_bullet'] = 'Utiliser l\'ic�ne Voir le dernier message en tant que puce';
$lang['Lastposticon_as_bullet_explain'] = 'Vous pouvez choisir d\'utiliser l\'ic�ne Voir le dernier message en tant que puce - notez que ceci remplacera toute s�lection de puce';

?>