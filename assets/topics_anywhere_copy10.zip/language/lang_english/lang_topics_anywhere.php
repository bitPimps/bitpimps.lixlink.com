<?php

//
// English Language File for Topics Anywhere
// Author: Dennis Heeren (or DtM) < dennis.heeren@advalvas.be >
//

$lang['Topics_anywhere_explain'] = 'Put the topic titles of any forum on your phpBB on any page you want... Here you can set your preferences on how to display those links.';
$lang['Lastpost_from'] = 'Last post by';
$lang['disc'] = 'disc';
$lang['circle'] = 'circle';
$lang['square'] = 'square';
$lang['numbered'] = 'numbered';
$lang['Select_forum_explain'] = 'Pick the forum of which you want to display the topics - hold CTRL down to select multiple forums';
$lang['Or'] = 'OR';
$lang['Amount_topics'] = 'How many topics?';
$lang['Amount_topics_explain'] = 'Set the amount of topics to be displayed';
$lang['Show_replies'] = 'Show replies?';
$lang['Show_replies_explain'] = 'The number of replies will be shown if yes is selected';
$lang['Show_replies_word'] = 'Show the word \'Replies\'?';
$lang['Show_replies_word_explain'] = 'If the previous option is set to yes, you can choose here to show the short form (e.g. \'(45)\' - select no) or the long form (e.g. \'(45 Replies)\' - select yes)';
$lang['Show_announce'] = 'Show announcement topics?';
$lang['Show_sticky'] = 'Show sticky topics?';
$lang['Show_locked'] = 'Show locked topics?';
$lang['Show_moved'] = 'Show moved topics?';
$lang['Bullet_type'] = 'Bullets?';
$lang['Bullet_type_explain'] = 'Pick a bullet type to be shown before each link';
$lang['Show_lastpostby'] = 'Show last poster?';
$lang['Show_lastpostby_explain'] = 'If yes, the username of the user who last posted in the topic will be shown';
$lang['Lastpostby_format'] = 'Last poster format';
$lang['Lastpostby_format_explain'] = 'How should the last poster be displayed?';
$lang['Show_lastpostdate'] = 'Show last post date?';
$lang['Show_lastpostdate_explain'] = 'If yes, the date and/or time when the last post was posted will be shown';
$lang['Lastpostdate_format'] = 'Last post date format';
$lang['Lastpostdate_format_explain'] = 'Pick the format in which you want the last post date to be displayed';
$lang['Show_lastposticon'] = 'Show jump to last post icon?';
$lang['Show_lastposticon_explain'] = 'If yes, an icon that will take you to the last post in the topic is shown';
$lang['CSS_link'] = 'CSS for link';
$lang['CSS_link_explain'] = 'Define a CSS class to be used for the links - leave blank if you don\'t want to use one';
$lang['CSS_text'] = 'CSS for text';
$lang['CSS_text_explain'] = 'Define a CSS class to be used for all the other text - leave blank if you don\'t want to use one';
$lang['Target_link'] = 'Target for link';
$lang['Target_link_explain'] = 'Define a target for the links - any valid target will do, also special ones (_top, _parent, _blank, ...) - leave blank to use \'_self\'';
$lang['Pick_a_forum'] = 'You have to select a forum...';
$lang['Invalid_amount'] = 'You have specified an invalid number of replies to be shown...';
$lang['Invalid_class'] = 'You have specified an invalid class name...';
$lang['Invalid_target'] = 'You have specified an invalid target name...';
$lang['Click_return'] = 'Click here to return';
$lang['Copy_paste'] = 'HTML code to copy and paste';
$lang['Copy_paste_explain'] = 'Just copy this HTML string an paste it on the page where you want the topics to be diplayed - do not edit in any way';
$lang['The_result'] = 'How it will look';
$lang['Classes_remark'] = 'If you specified CSS classes for your links or text, then they probably won\'t be applied properly here';
$lang['No_topics'] = 'There are no topics';
$lang['Topic_Locked'] = '<b>(Locked)</b>';
$lang['Reply'] = 'Reply';
$lang['Select_forum'] = 'Select forum';
$lang['In'] = 'in';
$lang['Show_forum_name'] = 'Show forum name';
$lang['Show_forum_name_explain'] = 'If yes, the name of the forum where the topic is in will be displayed';
$lang['Link_forum_name'] = 'Make forum name a link';
$lang['Link_forum_name_explain'] = 'If this and the previous option is set to yes, the forum name will be a link to that forum';
$lang['Sorry_auth_topicsanywhere'] = 'Sorry but only %s can set up Topics Anywhere';
$lang['Sort_order'] = 'Sort order';
$lang['Sort_order_explain'] = '\'Priority\' means show first announcements, then sticky topics, then normal topics, \'On date\' shows topics with most recent posts';
$lang['Priority'] = 'Priority';
$lang['On_date'] = 'On date';
$lang['Add_break'] = 'Add a break';
$lang['Add_break_explain'] = 'To improve readability you can use a line break to show topic title and last poster info on seperate lines';
$lang['Lastposticon_as_bullet'] = 'Use the jump to last post icon as bullet';
$lang['Lastposticon_as_bullet_explain'] = 'You can choose to use the jump to last post icon as a bullet - note that this will override any bullet selection above'

?>