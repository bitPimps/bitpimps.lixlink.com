<table>
  <tr>
    <td align="left" valign="middle" class="nav" width="100%">
      <span class="nav">&nbsp;&nbsp;&nbsp;<a href="{U_INDEX}" class="nav">{L_INDEX}</a>
        </span>
    </td>
  </tr>
</table>
<hr>

<form action="{S_FORM_ACTION}" method="post">
<input type="hidden" name="total_forums" value="{H_TOTAL_FORUMS}">
<table width="98%" cellspacing="1" cellpadding="4" border="0" align="center" class="forumline">
	<tr>
	  <th class="thHead" colspan="2">{L_TOPICS_ANYWHERE}</th>
	</tr>
	<tr>
	  <td class="row2" colspan="2"><span class="gensmall">{L_TOPICS_ANYWHERE_EXPLAIN}</span></td>
	</tr>
	<tr>
	  <td class="row1" width="45%"><span class="gen">{L_SELECT_FORUM}:</span><br /><span class="gensmall">{L_SELECT_FORUM_EXPLAIN}</span></td>
	  <td class="row2">
	    <span class="gen">{SELECT_FORUM_SELECT} &nbsp;&nbsp;<b>{L_OR}</b>&nbsp;&nbsp;<input type="checkbox" name="allfora">&nbsp;{L_CHECK_ALLFORA}</span>
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_AMOUNT_TOPICS}:</span><br /><span class="gensmall">{L_AMOUNT_TOPICS_EXPLAIN}</span></td>
	  <td class="row2">
		<input type="text" name="amount_topics" size="10" maxlength="2" value="10" />
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_SHOW_FORUM_NAME}:</span><br /><span class="gensmall">{L_SHOW_FORUM_NAME_EXPLAIN}</span></td>
	  <td class="row2">
		<input type="radio" name="show_forum_name" value="1" checked />
		<span class="gen">{L_YES}</span>&nbsp;&nbsp;
		<input type="radio" name="show_forum_name" value="0" />
		<span class="gen">{L_NO}</span>
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_LINK_FORUM_NAME}:</span><br /><span class="gensmall">{L_LINK_FORUM_NAME_EXPLAIN}</span></td>
	  <td class="row2">
		<input type="radio" name="link_forum_name" value="1" checked />
		<span class="gen">{L_YES}</span>&nbsp;&nbsp;
		<input type="radio" name="link_forum_name" value="0" />
		<span class="gen">{L_NO}</span>
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_SHOW_REPLIES}:</span><br /><span class="gensmall">{L_SHOW_REPLIES_EXPLAIN}</span></td>
	  <td class="row2">
		<input type="radio" name="show_replies" value="1" checked />
		<span class="gen">{L_YES}</span>&nbsp;&nbsp;
		<input type="radio" name="show_replies" value="0" />
		<span class="gen">{L_NO}</span>
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_SHOW_REPLIES_WORD}:</span><br /><span class="gensmall">{L_SHOW_REPLIES_WORD_EXPLAIN}</span></td>
	  <td class="row2">
		<input type="radio" name="show_replies_word" value="1" checked />
		<span class="gen">{L_YES}</span>&nbsp;&nbsp;
		<input type="radio" name="show_replies_word" value="0" />
		<span class="gen">{L_NO}</span>
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_SHOW_ANNOUNCEMENTS}:</span></td>
	  <td class="row2">
		<input type="radio" name="show_announce" value="1" />
		<span class="gen">{L_YES}</span>&nbsp;&nbsp;
		<input type="radio" name="show_announce" value="0" checked />
		<span class="gen">{L_NO}</span>
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_SHOW_STICKYS}:</span></td>
	  <td class="row2">
		<input type="radio" name="show_sticky" value="1" />
		<span class="gen">{L_YES}</span>&nbsp;&nbsp;
		<input type="radio" name="show_sticky" value="0" checked />
		<span class="gen">{L_NO}</span>
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_SHOW_LOCKED}:</span></td>
	  <td class="row2">
		<input type="radio" name="show_locked" value="1" />
		<span class="gen">{L_YES}</span>&nbsp;&nbsp;
		<input type="radio" name="show_locked" value="0" checked />
		<span class="gen">{L_NO}</span>
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_SHOW_MOVED}:</span></td>
	  <td class="row2">
		<input type="radio" name="show_moved" value="1" />
		<span class="gen">{L_YES}</span>&nbsp;&nbsp;
		<input type="radio" name="show_moved" value="0" checked />
		<span class="gen">{L_NO}</span>
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_SORT_ORDER}:</span><br /><span class="gensmall">{L_SORT_ORDER_EXPLAIN}</span></td>
	  <td class="row2">
		<select name="sort_order">
		<option value="priority">{O_PRIORITY}</option>
		<option value="ondate">{O_ON_DATE}</option>
		</select>
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_BULLET_TYPE}:</span><br /><span class="gensmall">{L_BULLET_TYPE_EXPLAIN}</span></td>
	  <td class="row2">
		{BULLET_TYPE_SELECT}
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_SHOW_LASTPOSTBY}:</span><br /><span class="gensmall">{L_SHOW_LASTPOSTBY_EXPLAIN}</span></td>
	  <td class="row2">
		<input type="radio" name="show_lastpostby" value="1" checked />
		<span class="gen">{L_YES}</span>&nbsp;&nbsp;
		<input type="radio" name="show_lastpostby" value="0" />
		<span class="gen">{L_NO}</span>
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_LASTPOSTBY_FORMAT}:</span><br /><span class="gensmall">{L_LASTPOSTBY_FORMAT_EXPLAIN}</span></td>
	  <td class="row2">
		{L_LASTPOSTBY_FORMAT_SELECT}
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_SHOW_LASTPOSTDATE}:</span><br /><span class="gensmall">{L_SHOW_LASTPOSTDATE_EXPLAIN}</span></td>
	  <td class="row2">
		<input type="radio" name="show_lastpostdate" value="1" checked />
		<span class="gen">{L_YES}</span>&nbsp;&nbsp;
		<input type="radio" name="show_lastpostdate" value="0" />
		<span class="gen">{L_NO}</span>
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_LASTPOSTDATE_FORMAT}:</span><br /><span class="gensmall">{L_LASTPOSTDATE_FORMAT_EXPLAIN}</span></td>
	  <td class="row2">
		{L_LASTPOSTDATE_FORMAT_SELECT}
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_SHOW_LASTPOSTICON}:</span><br /><span class="gensmall">{L_SHOW_LASTPOSTICON_EXPLAIN}</span></td>
	  <td class="row2">
		<input type="radio" name="show_lastposticon" value="1" checked />
		<span class="gen">{L_YES}</span>&nbsp;&nbsp;
		<input type="radio" name="show_lastposticon" value="0" />
		<span class="gen">{L_NO}</span>
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_LASTPOSTICON_AS_BULLET}:</span><br /><span class="gensmall">{L_LASTPOSTICON_AS_BULLET_EXPLAIN}</span></td>
	  <td class="row2">
		<input type="radio" name="lastposticon_bullet" value="1" />
		<span class="gen">{L_YES}</span>&nbsp;&nbsp;
		<input type="radio" name="lastposticon_bullet" value="0" checked/>
		<span class="gen">{L_NO}</span>
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_ADD_BREAK}:</span><br /><span class="gensmall">{L_ADD_BREAK_EXPLAIN}</span></td>
	  <td class="row2">
		<input type="radio" name="add_break" value="1" />
		<span class="gen">{L_YES}</span>&nbsp;&nbsp;
		<input type="radio" name="add_break" value="0" checked />
		<span class="gen">{L_NO}</span>
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_CSS_LINK}:</span><br /><span class="gensmall">{L_CSS_LINK_EXPLAIN}</span></td>
	  <td class="row2">
		<input type="text" name="css_link" size="35" maxlength="25" value="" />
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_CSS_TEXT}:</span><br /><span class="gensmall">{L_CSS_TEXT_EXPLAIN}</span></td>
	  <td class="row2">
		<input type="text" name="css_text" size="35" maxlength="25" value="" />
	  </td>
	</tr>
	<tr>
	  <td class="row1"><span class="gen">{L_TARGET_LINK}:</span><br /><span class="gensmall">{L_TARGET_LINK_EXPLAIN}</span></td>
	  <td class="row2">
		<input type="text" name="target_link" size="35" maxlength="10" value="" />
	  </td>
	</tr>
	<tr>
	  <td class="catBottom" colspan="2" align="center">
		<input type="submit" name="submit" value="{L_SUBMIT}" class="mainoption" />
		&nbsp;&nbsp;
		<input type="reset" value="{L_RESET}" class="liteoption" />
	  </td>
	</tr>
</table>
</form>
